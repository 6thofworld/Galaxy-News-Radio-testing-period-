Scriptname F34GNRGuard extends Quest
{GNR song-counter guard, v0.2 TEST BUILD.
Every PollSeconds it reads F3:RadioGNRScript.SongsPlayed. The song lines only accept 0 or 1,
so if the counter reads 2 or higher it is set back to 0 (the same value the game's own reset
fragments write). Everything is logged to Documents\My Games\Fallout4\Logs\Script\User\F34_GNR_Guard.0.log}

String Property LogName = "F34_GNR_Guard" AutoReadOnly
Int Property PollTimerID = 1 AutoReadOnly
Float Property PollSeconds = 5.0 AutoReadOnly
Int Property GNRQuestLocalID = 0x00022486 AutoReadOnly
String Property GNRPlugin = "Fallout34.esm" AutoReadOnly
String Property GNRScriptName = "F3:RadioGNRScript" AutoReadOnly

Int LastSeen = -999
Int ResetCount = 0
Bool UnresolvedLogged = False

Function Log(String asText)
	Debug.OpenUserLog(LogName)
	Debug.TraceUser(LogName, asText)
EndFunction

Event OnInit()
	Log("guard v0.2 (resets SongsPlayed >= 2 to 0) started")
	RegisterForRemoteEvent(Game.GetPlayer(), "OnPlayerLoadGame")
	StartTimer(PollSeconds, PollTimerID)
EndEvent

Event Actor.OnPlayerLoadGame(Actor akSender)
	Log("save loaded")
	LastSeen = -999
	UnresolvedLogged = False
	CancelTimer(PollTimerID)
	StartTimer(PollSeconds, PollTimerID)
EndEvent

Event OnTimer(Int aiTimerID)
	If aiTimerID != PollTimerID
		Return
	EndIf
	Poll()
	StartTimer(PollSeconds, PollTimerID)
EndEvent

Int Function ReadInt(ScriptObject akObj, String asName)
	Var v = akObj.GetPropertyValue(asName)
	Return v as Int
EndFunction

Function Poll()
	Quest gnrQuest = Game.GetFormFromFile(GNRQuestLocalID, GNRPlugin) as Quest
	If gnrQuest == None
		If !UnresolvedLogged
			Log("GNR quest not found (" + GNRPlugin + " local id " + GNRQuestLocalID + "); doing nothing")
			UnresolvedLogged = True
		EndIf
		Return
	EndIf
	ScriptObject gnr = gnrQuest.CastAs(GNRScriptName)
	If gnr == None
		If !UnresolvedLogged
			Log("quest found but script " + GNRScriptName + " not attached; doing nothing")
			UnresolvedLogged = True
		EndIf
		Return
	EndIf
	UnresolvedLogged = False

	Int played = ReadInt(gnr, "SongsPlayed")
	If played != LastSeen
		String msg = "SongsPlayed=" + played + " | SongIntro=" + ReadInt(gnr, "SongIntro")
		msg += " | history=" + ReadInt(gnr, "LastSongPlayed") + "," + ReadInt(gnr, "LastSongPlayed2")
		msg += "," + ReadInt(gnr, "LastSongPlayed3") + "," + ReadInt(gnr, "LastSongPlayed4")
		Log(msg)
		LastSeen = played
	EndIf

	If played >= 2
		gnr.SetPropertyValue("SongsPlayed", 0)
		ResetCount += 1
		Int after = ReadInt(gnr, "SongsPlayed")
		Log("RESET #" + ResetCount + ": SongsPlayed was " + played + ", set to 0, now reads " + after)
		LastSeen = after
	EndIf
EndFunction
