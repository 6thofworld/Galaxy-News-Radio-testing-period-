GNR_SongVolume Increases the volume of songs for GNR,
GNR_Everywhere_F34 Increases the range of radio station


NOTE: plz LOAD GNR_SongVolume very early in load order, ideally after Fallout34.esm


F34 GNR Guard v1.1
==============================
Galaxy News Radio only plays a song when its quest counter
"SongsPlayed" is 0 or 1. On some saves the counter ends up at another
value (for example 5, or a large number). Then no song is eligible and
Three Dog just keeps talking.

This plugin watches the counter every few seconds. If it is below 0 or
above 2 it sets it back to 0. A 2 that does not change for 30 seconds is also
treated as stuck (no song accepts 2). Values 0 and 1 are never touched.
If the counter keeps going bad (something is rewriting it), the guard stops
writing after 10 recoveries and only logs.

It does not edit Fallout34.esm and does not change any radio records.

Install
-------
1. Put F34_GNR_Guard.esp and Scripts\F34GNRGuard.pex in your mod
   (Mod Organizer 2: top level of the mod folder, no "Data" folder inside).
2. Load it AFTER Fallout4.esm and Fallout34.esm.
3. Make sure no other mod carries an older Scripts\F34GNRGuard.pex.
   (Older v0.2 builds reset the valid value 2 too. Replace them.)

Log (for bug reports)
-------------------------------
Add to Fallout4Custom.ini (or your MO2 profile copy):
  [Papyrus]
  bEnableLogging=1
  bEnableTrace=1
Log file:
  Documents\My Games\Fallout4\Logs\Script\User\F34_GNR_Guard.0.log

Lines you may see:
  started (...)    guard is running
  SongsPlayed=N    counter changed
  RECOVERY #n      counter was out of range and was set to 0
  BACKOFF          too many recoveries; guard stopped writing
  ... not found    Fallout34.esm / GNR script missing; guard does nothing
