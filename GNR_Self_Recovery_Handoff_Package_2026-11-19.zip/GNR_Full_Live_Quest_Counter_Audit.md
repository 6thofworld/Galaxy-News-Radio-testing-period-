# GNR Full Live Quest INFO Counter Audit

## Source and coverage
- Source: `GNR_Full_Live_Quest_INFO_Export_v2.txt`, exported from `Fallout34.esm`.
- Quest: `F34_Radio_RadioGalaxyNews` (`QUST:0AD0EE64`).
- DIAL topics: 164 total (82 in Scene A and 82 in Scene B; no overlap).
- INFO records: 1,732 unique INFO records.
- Scenes: 2; each has 505 phases and 505 actions.
- The 164 DIAL topics are exactly the union of the 82 topics referenced by each scene's Radio actions.

## Active-plugin scope
- Every INFO record in the export identifies `Fallout34.esm` as its source file; no ESP INFO override rows appear in this output.
- Therefore this audit verifies the master-plugin records. It does not establish the winning conditions from any experimental/test ESP that may have been active in Reliable 01 if that override was not present in this FO4Edit export.

## Counter-changing fragment coverage
Cross-checked the export's Papyrus topic-info fragment IDs against all 639 supplied GNR fragment source files:
- 120 increment fragments call `F34_Add_SongsPlayed(1)`.
- 52 reset fragments set `SongsPlayed = 0`.
- All 172 IDs are present in the full INFO export, with exactly 2 INFO records per fragment: one in Scene A and one in Scene B.
- The two scene-pair INFOs for each fragment have identical condition lists.
- Total counter-changing INFO records: 344 (240 increment INFOs + 104 reset INFOs).
- The earlier gap of 72 increment fragments is closed by this export.

## SongsPlayed gates
At INFO-record level:
- Increment INFOs requiring `SongsPlayed = 0`: 120.
- Increment INFOs requiring `SongsPlayed = 1`: 120.
- Reset INFOs requiring `SongsPlayed = 2`: 100.
- Two exceptional reset fragments each have two scene-pair INFOs requiring `SongsPlayed = 1`: 4 INFOs.
- Thus every one of the 344 counter-changing INFOs checks `SongsPlayed` against 0, 1, or 2. No counter-changing INFO in this export accepts 5.

By unique increment fragment:
- Each of the 20 song IDs has 6 increment fragments: 3 gated on 0 and 3 gated on 1.

## Confirmed condition anomalies
### Missing third recent-song check
Two separate increment fragments both write song ID 8 and shift all four history slots, but their INFO conditions omit `LastSongPlayed3`:
- Fragment `01057B29`: INFO `0AB73340` in DIAL `0AEAECDA` (Scene A); INFO `0AFF891F` in DIAL `0AC92CD7` (Scene B).
- Fragment `010752A7`: INFO `0AA24877` in DIAL `0AFC288C` (Scene A); INFO `0AC9F568` in DIAL `0AD702D2` (Scene B).
- This is 4 INFO records total, covering 2 distinct fragments. The previous partial song CSV export only exposed the first pair.

### Two reset-fragment history mismatches
Each has one INFO in each scene. All four history checks compare against song ID 2, but the fragment writes `LastSongPlayed = 1`. Both reset INFO pairs require `SongsPlayed = 1`:
- Fragment `01074EF3`: INFO `0AE757B1` / DIAL `0AB4CDB4` (Scene A); INFO `0AD3D631` / DIAL `0AFB2328` (Scene B).
- Fragment `010A870A`: INFO `0A95D0E8` / DIAL `0A942D8E` (Scene A); INFO `0AEE8959` / DIAL `0ACB5E3C` (Scene B).

The other reset fragments' recent-song checks match the song ID written by their fragment.

## Reset topics are present in both scene action trees
The scene actions call all eight reset-bearing DIAL topics:
- Scene A: `0AB4CDB4`, `0AB3D5A1`, `0A942D8E`, `0A9FDA06`.
- Scene B: `0AFB2328`, `0AAE163B`, `0ACB5E3C`, `0AC0A9D3`.
The reset-topic actions occur around phase groups `N5_0`, `N5_1`, `N5_r0`, `N66_0`, `N66_1`, and `N66_r0`. This verifies the topics are wired into both static scene trees; it does not prove which phase was active in Reliable 01 at runtime.

## Meaning for Reliable 01
The earlier save inspection reported `SongsPlayed = 5` (recent history 11, 8, 5, 3; `SongIntro = 2`). On the evidence of this complete INFO export, a value of 5 fails the counter condition on all 344 counter-changing INFOs, including the reset INFOs. This is stronger than the earlier partial-export result.

The export explains why the current value 5 blocks the known song/reset INFO paths. It does **not** explain how the counter reached 5. Under the exported INFO gates, the intended counter cycle is 0 -> 1 -> 2 -> reset to 0; value 5 is outside that cycle. The remaining investigation should focus on non-INFO writers or state restoration (particularly the main script's `F34_QSnap` / `F34_QRestore` route) and confirm whether a real external caller restores a nonzero snapshot into this GNR quest. The export alone does not prove that this restore function caused the value 5.

## Important limits
- This validates the live quest's two scene trees and every INFO record collected under its 164 DIAL topics.
- It does not prove runtime phase reachability or the exact state of transmitter references in Reliable 01.
- It does not rule out a separate external script or restore caller outside the supplied 639 GNR fragment source set.
- No game, save, plugin, or record was modified by this audit.
