;/ Decompiled by Champollion V1.0.6
PEX format v3.9 GameID: 2
Source   : RadioGNRScript.psc
Modified : 2020-09-13 17:56:40
Compiled : 2020-09-13 17:56:40
User     : f34
Computer : papyrus.py
/;
ScriptName F3:RadioGNRScript extends Quest conditional
{ Fallout 3 script RadioGNRScript (SCPT 00057B31, quest) translated by f34.geck. Fix the translator, not this file. }

;-- Properties --------------------------------------
int Property DashwoodVar Auto conditional
int Property PSAVar Auto conditional
int Property PSANum Auto conditional
int Property DadStoryVar Auto conditional
int Property NewsStoryVar Auto conditional
int Property TitleHopeVar Auto conditional
int Property TitleScourgeVar Auto conditional
int Property TitleParadigmVar Auto conditional
int Property ExploitVar Auto conditional
int Property SongIntro Auto conditional
int Property LastSongPlayed Auto conditional
int Property LastSongPlayed2 Auto conditional
int Property LastSongPlayed3 Auto conditional
int Property LastSongPlayed4 Auto conditional
int Property LastNews Auto conditional
int Property LastPSA Auto conditional
int Property LastGreeting Auto conditional
int Property LastGreeting2 Auto conditional
int Property SongsPlayed Auto conditional
int Property ThreeDogDead Auto conditional
int Property BadDoesGood Auto conditional
int Property GoodDoesBad Auto conditional
int Property DashwoodEp Auto conditional
float Property CG04Done Auto conditional
float Property MQ01Clear Auto conditional
float Property MQ02Clear Auto conditional
float Property MQ03Clear Auto conditional
float Property MQ04Clear Auto conditional
float Property MQ05Clear Auto conditional
float Property MQ06Clear Auto conditional
float Property MQ07Clear Auto conditional
float Property MQ08Clear Auto conditional
float Property MQ09Clear Auto conditional
float Property MS01Clear Auto conditional
float Property MS02Clear Auto conditional
float Property MS03Clear Auto conditional
float Property MS04Clear Auto conditional
float Property MS05Clear Auto conditional
float Property MS06Clear Auto conditional
float Property MS08Clear Auto conditional
float Property MS09Clear Auto conditional
float Property MS10Clear Auto conditional
float Property MS11Clear Auto conditional
float Property MS12Clear Auto conditional
float Property MS14Clear Auto conditional
float Property MS15Clear Auto conditional
float Property MS16Clear Auto conditional
float Property MS17Clear Auto conditional
float Property MS18Clear Auto conditional
int Property ExploitReady Auto conditional
float Property MQ11Clear Auto conditional
float Property DLC03BS1Clear Auto conditional
float Property DLC03BS2Clear Auto conditional
float Property DLC03BS3Clear Auto conditional
Quest Property MS08 Auto Const
Actor Property HarknessRef Auto Const
GlobalVariable Property GameDaysPassed Auto Const

;-- Variables ---------------------------------------
float F34_TickDelay = 5
float F34_SecondsPassed
float F34_LastTick
bool F34_Ticking
float F34_TickStart
bool F34_OwnWorld = True
float F34_OwnWorldAt
float F34_FragUntil

;-- Functions ---------------------------------------

Event OnQuestInit()
	Self.StartTimer(F34_TickDelay, 1)
EndEvent

Event OnQuestShutdown()
	Self.CancelTimer(1)
EndEvent

Event OnTimer(int aiTimerID)
	If (aiTimerID == 1)
		If (!Self.IsRunning())
			return 
		EndIf
		Self.StartTimer(F34_TickDelay, 1)
		If (!Self.F34_InOwnWorld())
			return 
		EndIf
		If (F34_FragUntil > 0)
			float F34_FragNow = Utility.GetCurrentRealTime()
			If (F34_FragNow < F34_FragUntil && F34_FragNow > F34_FragUntil - 5)
				return 
			EndIf
			F34_FragUntil = 0
		EndIf
		float F34_Now = Utility.GetCurrentRealTime()
		If (F34_Ticking && F34_Now - F34_TickStart > -1 && F34_Now - F34_TickStart < 10)
			return 
		EndIf
		F34_Ticking = True
		F34_TickStart = F34_Now
		F34_SecondsPassed = F34_TickDelay
		If (F34_TickDelay < 0.1 && F34_LastTick > 0 && F34_Now > F34_LastTick)
			F34_SecondsPassed = F34_Now - F34_LastTick
			If (F34_SecondsPassed > 1)
				F34_SecondsPassed = 1
			EndIf
		EndIf
		F34_LastTick = F34_Now
		Self.F34_GameModeTick()
		F34_Ticking = False
	EndIf
EndEvent

int Function F34_Add_DadStoryVar(int afDelta)
{ GNR3: another script's 'set <this>.dadstoryvar to <this>.dadstoryvar + n' in one locked call (no lost steps) }
	DadStoryVar += afDelta
	return DadStoryVar
EndFunction

int Function F34_Add_DashwoodVar(int afDelta)
{ GNR3: another script's 'set <this>.dashwoodvar to <this>.dashwoodvar + n' in one locked call (no lost steps) }
	DashwoodVar += afDelta
	return DashwoodVar
EndFunction

int Function F34_Add_ExploitVar(int afDelta)
{ GNR3: another script's 'set <this>.exploitvar to <this>.exploitvar + n' in one locked call (no lost steps) }
	ExploitVar += afDelta
	return ExploitVar
EndFunction

int Function F34_Add_NewsStoryVar(int afDelta)
{ GNR3: another script's 'set <this>.newsstoryvar to <this>.newsstoryvar + n' in one locked call (no lost steps) }
	NewsStoryVar += afDelta
	return NewsStoryVar
EndFunction

int Function F34_Add_PSAVar(int afDelta)
{ GNR3: another script's 'set <this>.psavar to <this>.psavar + n' in one locked call (no lost steps) }
	PSAVar += afDelta
	return PSAVar
EndFunction

int Function F34_Add_SongsPlayed(int afDelta)
{ GNR3: another script's 'set <this>.songsplayed to <this>.songsplayed + n' in one locked call (no lost steps) }
	SongsPlayed += afDelta
	return SongsPlayed
EndFunction

int Function F34_Add_TitleHopeVar(int afDelta)
{ GNR3: another script's 'set <this>.titlehopevar to <this>.titlehopevar + n' in one locked call (no lost steps) }
	TitleHopeVar += afDelta
	return TitleHopeVar
EndFunction

int Function F34_Add_TitleParadigmVar(int afDelta)
{ GNR3: another script's 'set <this>.titleparadigmvar to <this>.titleparadigmvar + n' in one locked call (no lost steps) }
	TitleParadigmVar += afDelta
	return TitleParadigmVar
EndFunction

int Function F34_Add_TitleScourgeVar(int afDelta)
{ GNR3: another script's 'set <this>.titlescourgevar to <this>.titlescourgevar + n' in one locked call (no lost steps) }
	TitleScourgeVar += afDelta
	return TitleScourgeVar
EndFunction

var[] Function F34_QSnap()
{ T125: this quest's FO3 variables, read before the quest is started (a first start re-initialises them) }
	var[] F34_qa = new var[54]
	F34_qa[0] = DashwoodVar as var
	F34_qa[1] = PSAVar as var
	F34_qa[2] = PSANum as var
	F34_qa[3] = DadStoryVar as var
	F34_qa[4] = NewsStoryVar as var
	F34_qa[5] = TitleHopeVar as var
	F34_qa[6] = TitleScourgeVar as var
	F34_qa[7] = TitleParadigmVar as var
	F34_qa[8] = ExploitVar as var
	F34_qa[9] = SongIntro as var
	F34_qa[10] = LastSongPlayed as var
	F34_qa[11] = LastSongPlayed2 as var
	F34_qa[12] = LastSongPlayed3 as var
	F34_qa[13] = LastSongPlayed4 as var
	F34_qa[14] = LastNews as var
	F34_qa[15] = LastPSA as var
	F34_qa[16] = LastGreeting as var
	F34_qa[17] = LastGreeting2 as var
	F34_qa[18] = SongsPlayed as var
	F34_qa[19] = ThreeDogDead as var
	F34_qa[20] = BadDoesGood as var
	F34_qa[21] = GoodDoesBad as var
	F34_qa[22] = DashwoodEp as var
	F34_qa[23] = CG04Done as var
	F34_qa[24] = MQ01Clear as var
	F34_qa[25] = MQ02Clear as var
	F34_qa[26] = MQ03Clear as var
	F34_qa[27] = MQ04Clear as var
	F34_qa[28] = MQ05Clear as var
	F34_qa[29] = MQ06Clear as var
	F34_qa[30] = MQ07Clear as var
	F34_qa[31] = MQ08Clear as var
	F34_qa[32] = MQ09Clear as var
	F34_qa[33] = MS01Clear as var
	F34_qa[34] = MS02Clear as var
	F34_qa[35] = MS03Clear as var
	F34_qa[36] = MS04Clear as var
	F34_qa[37] = MS05Clear as var
	F34_qa[38] = MS06Clear as var
	F34_qa[39] = MS08Clear as var
	F34_qa[40] = MS09Clear as var
	F34_qa[41] = MS10Clear as var
	F34_qa[42] = MS11Clear as var
	F34_qa[43] = MS12Clear as var
	F34_qa[44] = MS14Clear as var
	F34_qa[45] = MS15Clear as var
	F34_qa[46] = MS16Clear as var
	F34_qa[47] = MS17Clear as var
	F34_qa[48] = MS18Clear as var
	F34_qa[49] = ExploitReady as var
	F34_qa[50] = MQ11Clear as var
	F34_qa[51] = DLC03BS1Clear as var
	F34_qa[52] = DLC03BS2Clear as var
	F34_qa[53] = DLC03BS3Clear as var
	return F34_qa
EndFunction

Function F34_QRestore(var[] F34_qa)
{ T125: after the quest start: a variable that was set before and is back to 0 gets its value again }
	int F34_qs0 = F34_qa[0] as int
	If (F34_qs0 != 0 && DashwoodVar == 0)
		DashwoodVar = F34_qs0
	EndIf
	int F34_qs1 = F34_qa[1] as int
	If (F34_qs1 != 0 && PSAVar == 0)
		PSAVar = F34_qs1
	EndIf
	int F34_qs2 = F34_qa[2] as int
	If (F34_qs2 != 0 && PSANum == 0)
		PSANum = F34_qs2
	EndIf
	int F34_qs3 = F34_qa[3] as int
	If (F34_qs3 != 0 && DadStoryVar == 0)
		DadStoryVar = F34_qs3
	EndIf
	int F34_qs4 = F34_qa[4] as int
	If (F34_qs4 != 0 && NewsStoryVar == 0)
		NewsStoryVar = F34_qs4
	EndIf
	int F34_qs5 = F34_qa[5] as int
	If (F34_qs5 != 0 && TitleHopeVar == 0)
		TitleHopeVar = F34_qs5
	EndIf
	int F34_qs6 = F34_qa[6] as int
	If (F34_qs6 != 0 && TitleScourgeVar == 0)
		TitleScourgeVar = F34_qs6
	EndIf
	int F34_qs7 = F34_qa[7] as int
	If (F34_qs7 != 0 && TitleParadigmVar == 0)
		TitleParadigmVar = F34_qs7
	EndIf
	int F34_qs8 = F34_qa[8] as int
	If (F34_qs8 != 0 && ExploitVar == 0)
		ExploitVar = F34_qs8
	EndIf
	int F34_qs9 = F34_qa[9] as int
	If (F34_qs9 != 0 && SongIntro == 0)
		SongIntro = F34_qs9
	EndIf
	int F34_qs10 = F34_qa[10] as int
	If (F34_qs10 != 0 && LastSongPlayed == 0)
		LastSongPlayed = F34_qs10
	EndIf
	int F34_qs11 = F34_qa[11] as int
	If (F34_qs11 != 0 && LastSongPlayed2 == 0)
		LastSongPlayed2 = F34_qs11
	EndIf
	int F34_qs12 = F34_qa[12] as int
	If (F34_qs12 != 0 && LastSongPlayed3 == 0)
		LastSongPlayed3 = F34_qs12
	EndIf
	int F34_qs13 = F34_qa[13] as int
	If (F34_qs13 != 0 && LastSongPlayed4 == 0)
		LastSongPlayed4 = F34_qs13
	EndIf
	int F34_qs14 = F34_qa[14] as int
	If (F34_qs14 != 0 && LastNews == 0)
		LastNews = F34_qs14
	EndIf
	int F34_qs15 = F34_qa[15] as int
	If (F34_qs15 != 0 && LastPSA == 0)
		LastPSA = F34_qs15
	EndIf
	int F34_qs16 = F34_qa[16] as int
	If (F34_qs16 != 0 && LastGreeting == 0)
		LastGreeting = F34_qs16
	EndIf
	int F34_qs17 = F34_qa[17] as int
	If (F34_qs17 != 0 && LastGreeting2 == 0)
		LastGreeting2 = F34_qs17
	EndIf
	int F34_qs18 = F34_qa[18] as int
	If (F34_qs18 != 0 && SongsPlayed == 0)
		SongsPlayed = F34_qs18
	EndIf
	int F34_qs19 = F34_qa[19] as int
	If (F34_qs19 != 0 && ThreeDogDead == 0)
		ThreeDogDead = F34_qs19
	EndIf
	int F34_qs20 = F34_qa[20] as int
	If (F34_qs20 != 0 && BadDoesGood == 0)
		BadDoesGood = F34_qs20
	EndIf
	int F34_qs21 = F34_qa[21] as int
	If (F34_qs21 != 0 && GoodDoesBad == 0)
		GoodDoesBad = F34_qs21
	EndIf
	int F34_qs22 = F34_qa[22] as int
	If (F34_qs22 != 0 && DashwoodEp == 0)
		DashwoodEp = F34_qs22
	EndIf
	float F34_qs23 = F34_qa[23] as float
	If (F34_qs23 != 0 && CG04Done == 0)
		CG04Done = F34_qs23
	EndIf
	float F34_qs24 = F34_qa[24] as float
	If (F34_qs24 != 0 && MQ01Clear == 0)
		MQ01Clear = F34_qs24
	EndIf
	float F34_qs25 = F34_qa[25] as float
	If (F34_qs25 != 0 && MQ02Clear == 0)
		MQ02Clear = F34_qs25
	EndIf
	float F34_qs26 = F34_qa[26] as float
	If (F34_qs26 != 0 && MQ03Clear == 0)
		MQ03Clear = F34_qs26
	EndIf
	float F34_qs27 = F34_qa[27] as float
	If (F34_qs27 != 0 && MQ04Clear == 0)
		MQ04Clear = F34_qs27
	EndIf
	float F34_qs28 = F34_qa[28] as float
	If (F34_qs28 != 0 && MQ05Clear == 0)
		MQ05Clear = F34_qs28
	EndIf
	float F34_qs29 = F34_qa[29] as float
	If (F34_qs29 != 0 && MQ06Clear == 0)
		MQ06Clear = F34_qs29
	EndIf
	float F34_qs30 = F34_qa[30] as float
	If (F34_qs30 != 0 && MQ07Clear == 0)
		MQ07Clear = F34_qs30
	EndIf
	float F34_qs31 = F34_qa[31] as float
	If (F34_qs31 != 0 && MQ08Clear == 0)
		MQ08Clear = F34_qs31
	EndIf
	float F34_qs32 = F34_qa[32] as float
	If (F34_qs32 != 0 && MQ09Clear == 0)
		MQ09Clear = F34_qs32
	EndIf
	float F34_qs33 = F34_qa[33] as float
	If (F34_qs33 != 0 && MS01Clear == 0)
		MS01Clear = F34_qs33
	EndIf
	float F34_qs34 = F34_qa[34] as float
	If (F34_qs34 != 0 && MS02Clear == 0)
		MS02Clear = F34_qs34
	EndIf
	float F34_qs35 = F34_qa[35] as float
	If (F34_qs35 != 0 && MS03Clear == 0)
		MS03Clear = F34_qs35
	EndIf
	float F34_qs36 = F34_qa[36] as float
	If (F34_qs36 != 0 && MS04Clear == 0)
		MS04Clear = F34_qs36
	EndIf
	float F34_qs37 = F34_qa[37] as float
	If (F34_qs37 != 0 && MS05Clear == 0)
		MS05Clear = F34_qs37
	EndIf
	float F34_qs38 = F34_qa[38] as float
	If (F34_qs38 != 0 && MS06Clear == 0)
		MS06Clear = F34_qs38
	EndIf
	float F34_qs39 = F34_qa[3