;/ Decompiled by Champollion V1.0.6
PEX format v3.9 GameID: 2
Source   : TIF_F3_RadioGalaxyNewsQuest_0105C912.psc
Modified : 2020-09-13 17:56:40
Compiled : 2020-09-13 17:56:40
User     : f34
Computer : papyrus.py
/;
ScriptName Fragments:TopicInfos:TIF_F3_RadioGalaxyNewsQuest_0105C912 extends TopicInfo Const hidden
{ Fallout 3 result scripts of INFO 0005C912 (RadioGalaxyNewsQuest) translated by f34.geck. }

;-- Properties --------------------------------------
F3:RadioGNRScript Property RadioGalaxyNewsQuest Auto Const

;-- Variables ---------------------------------------

;-- Functions ---------------------------------------

Function Fragment_End(ObjectReference akSpeakerRef)
	Actor akSpeaker = akSpeakerRef as Actor
	RadioGalaxyNewsQuest.F34_FragBegin()
	RadioGalaxyNewsQuest.F34_Add_ExploitVar(1)
	RadioGalaxyNewsQuest.F34_FragEnd()
EndFunction
