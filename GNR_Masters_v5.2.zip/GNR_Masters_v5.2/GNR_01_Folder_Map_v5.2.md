# GNR folder map (compact index of tree.txt + post-20 Nov files) · v5.2 · 21 Nov 2026

**Use.** Locator built from `tree.txt` (`tree /F` of the user's working folder: 13 MB, 162,949 files, 1,334 folders) **as it stood on 20 Nov**, plus (Part 3) the files attached on 21 Nov. Decide from this which file to ask the user for; never ask for or load the tree. Bulk dumps are counts + a name pattern. Path shorthands: `LEAN` = `Fallout34_GNR_V3.1/Fallout34_GNR_Claude_B_Package_v3.1.1/Fallout34_GNR_Lean`; `HANDOFF/EVIDENCE` = `GNR_Self_Recovery_Handoff_Package_2026-11-19/GNR_Session_Evidence_Package_2026-11-19`; `RUN` = `decomp_runs/run_20261118_052131`.

**Naming rules.** Fragment scripts: `tif_f3_radiogalaxynewsquest_<8-hex>.psc/.pex/.txt` (hex = original INFO FormID with load-order byte `01`; compare the last six digits). Voice: `<INFO FormID>_<n>.wav/.lip` in `sound/voice/fallout34.esm/<voicetype>/`. A file not listed here was not in the folder when the tree was made — say so instead of assuming. The same file often exists in several folders (e.g. the audit CSV, `radiognrscript.pas`, the 639 fragments); the copy under `HANDOFF/EVIDENCE` is the one the v5.0 numbers were re-checked from.

**Not in the folder (per M2-B1):** `Fallout34.esm`/`Fallout34old.esm`, `scripts.zip`, `radiofix.rar`/`radiofix.py`, the new-save and user v0.2 logs. Saves present: `Save10` and `Save11` (`.fos` + `.f4se`, F3_Wasteland, 18 Nov 2026 ~10:56/10:59) — Save 11 is Reliable 01 per M1 §5.3. ▲v5.2: also the 18 Nov `New_save` (Part 3) — location in the user's folder not stated.

**▲v5.2 — what the tree cannot tell you:** the 20 Nov tree predates guard v0.3 (built 20 Nov) and v1.1 (21 Nov), so their folders may exist on the user's PC but are **not** indexed here. Ask the user for a fresh listing of just those folders (not the whole tree), or for the specific file.

## Part 1 — Evidence and working folders (every file named; as of 20 Nov)
- `F34Radio Reports` — `F34 GNR NEW.pdf`; `F34 GNR songsmerged(NEW).pdf`; `Fallout34_GNR_Session_Memory_2026-11-17.md`
- `F34Radio Reports/Reports(logs,csv,txt)` — `F34_RadioScene_RadioGalaxyNews_0A93BF68.txt`; `F34_RadioScene_RadioGalaxyNews_B_0AC0FA30.txt`; `FullInfo_Export.txt`; `FullInfo_Summary.csv`; `NoEditorID_0AED5399.txt`; `SongInfoExport(for0AC92CD7).csv`; `SongInfoExport(for0AEAECDA).csv`; `ba2_gnr_report.txt`; `ba2_radio_report.txt`; `ba2_voice_report.txt`; `fo4_radio_lookup.txt`; `radio_dump.txt`; `radio_sound_dump.txt`
- `F34Radio Reports/scripts(py,pex,pas)` — `ExportRecordList.pas`; `ba2_extract_gnr_script.py`; `ba2_extract_script.py`; `ba2_find.py`; `ba2_gnr_check.py`; `ba2_voice_check.py`; `fo4_radio_lookup.py`; `make_radio_volume_patch.py` *(▲v5.2: possible generator of the volume plugin — unverified, not opened)*; `radio_dump.py`; `radio_sound_dump.py`; `radiognrscript.pex`; `tif_f3_radiogalaxynewsquest_0105a55a.pex`
- `F34_GNR_Guard` — `F34_GNR_Guard.esp`; `HOWTO_compile_and_test.md`; `README.txt`; `compile_guard.bat`; `pexdump.py` *(v0.2 era; ▲v5.2: contents on the user's PC may have changed since — not re-listed)*
- `F34_GNR_Guard/Scripts` — `F34GNRGuard.pex`
- `F34_GNR_Guard/Scripts/Source/User` — `F34GNRGuard.psc`
- `F34_GNR_Guard/tester_logs` — `F34GNRGuard.psc`; `F34_GNR_Guard.0 (1).log`; `F34_GNR_Guard.0.log`; `F34_GNR_Guard.1.log`; `F34_GNR_Guard.2.log`
- `Fallout34_GNR_V3.1` — `GNR_Master_Session_Memory_v3.1.1.md`
- `LEAN` — `00_START_HERE.md`; `01_FILE_INDEX.md`; `MANIFEST_SHA256.txt`
- `LEAN/1_Scripts/decompile_run` — `report.txt`; `summary.csv`
- `LEAN/1_Scripts/decompile_run/logs` — `champollion_help.txt`; `main_asm.out.txt`; `main_champollion.err.txt`; `main_champollion.out.txt`; `main_comment.out.txt`
- `LEAN/1_Scripts/decompile_run/psc_main_comment` — `radiognrscript.psc`
- `LEAN/1_Scripts/decompile_run/strings` — `radiognrscript.strings.txt`
- `LEAN/1_Scripts/fragments_639` — 639 files (psc:639); `tif_f3_radiogalaxynewsquest_0101e52c.psc` … `tif_f3_radiogalaxynewsquest_011895be.psc`
- `LEAN/1_Scripts/main_script` — `radiognrscript.pas`; `radiognrscript.pex`; `radiognrscript.psc`
- `LEAN/2_Patches` — `F34_GNR_TestA.esp`; `F34_GNR_TestA0_AllThree_control.esp`; `F34_GNR_TestA1_SongsPlayed.esp`; `F34_GNR_TestA2_LastSongPlayed.esp`; `F34_GNR_TestA3_SongIntro.esp`; `F34_GNR_TestB.esp`; `GNR No Static_F34.esp`; `GNR_Everywhere_F34.esp`
- `LEAN/3_Exports_F34` — `F34_RadioScene_RadioGalaxyNews_0A93BF68.txt`; `F34_RadioScene_RadioGalaxyNews_B_0AC0FA30.txt`; `FullInfo_Export.txt`; `NoEditorID_0AED5399.txt`; `SongInfoExport(for0AC92CD7).csv`; `SongInfoExport(for0AEAECDA).csv`; `ba2_gnr_report.txt`; `radio_sound_dump.txt`
- `LEAN/4_Reference_Only/Fallout4_comparison` — `fo4_radio_lookup.txt`; `gistfile1.txt`
- `LEAN/4_Reference_Only/New_Vegas_NOT_F34_EVIDENCE` — `ba2_radio_report.txt`; `ba2_voice_report.txt`; `radio_dump.txt`
- `LEAN/5_Tools` — `Decompile-F34.ps1`
- `LEAN/6_Session_Updates` — `Claude_A_Session_2026-11-18_to_19.pdf`; `Claude_A_Session_2026-11-18_to_19_text.txt`; `Claude_A_Session_Addendum_2026-11-19.md`; `Package_Review_Notes_v3.1.1.md`; `Package_Review_Notes_v3.1.md`
- `LEAN/9_Archive_Superseded` — `F34 GNR NEW.pdf`; `F34 GNR NEW__text.txt`; `Fallout34_GNR_Session_Memory_2026-11-17.md`; `Fallout34_GNR_Session_Memory_2026-11-18_Continued.pdf`; `Fallout34_GNR_Session_Memory_2026-11-18_Continued__text.txt`; `GNR_Master_Session_Memory_v1.md`; `GNR_Master_Session_Memory_v2_2026-11-18.md`; `GNR_Master_Session_Memory_v3.1.md`; `GNR_Master_Session_Memory_v3_previous.md`; `README_F34_GNR__archive_root.md`; `README_F34_GNR__nested_revised.md`; `README_GNR_Papyrus_Archives.txt`; `README_Project_Bundle.txt`; `tree.txt`
- `GNR_Self_Recovery_Handoff_Package_2026-11-19` — `GNR_Counter_Fragment_Crosscheck_Audit.txt`; `GNR_Full_Live_Quest_Counter_Audit.csv`; `GNR_Full_Live_Quest_Counter_Audit.md`; `GNR_Full_Live_Quest_INFO_Export_v2.pas`; `GNR_Full_Live_Quest_INFO_Export_v2.txt`; `GNR_Master_Session_Memory_v3.1.1.md`; `GNR_Self_Recovery_Session_Memory_2026-11-19.md`; `GNR_Self_Recovery_Session_Memory_2026-11-19.pdf`; `GNR_Session_Handoff_2026-11-19.md`; `GNR_Session_Handoff_2026-11-19.pdf`; `GNR_SongsPlayed_172_Fragment_CrossReference_2.csv`; `README_F34_GNR__nested_revised.md`; `README_START_HERE.txt`; `radiognrscript.pas`; `radiognrscript.psc`
- `HANDOFF/EVIDENCE` — `README.txt`
- `HANDOFF/EVIDENCE/00_START_HERE` — `GNR_Session_Handoff_2026-11-19.md`; `GNR_Session_Handoff_2026-11-19.pdf`
- `HANDOFF/EVIDENCE/01_Audits` — `GNR_Counter_Fragment_Crosscheck_Audit.txt`; `GNR_Full_Live_Quest_Counter_Audit.csv`; `GNR_Full_Live_Quest_Counter_Audit.md`; `GNR_SongsPlayed_172_Fragment_CrossReference.csv`
- `HANDOFF/EVIDENCE/02_FO4Edit_Exports` — `GNR_Full_Live_Quest_INFO_Export_v2.pas`; `GNR_Full_Live_Quest_INFO_Export_v2.txt`; `GNR_ResetInfoExport.txt`; `GNR_Target_INFO_Conditions_v3.txt`
- `HANDOFF/EVIDENCE/03_Reference` — `GNR_Master_Session_Memory_v3.1.1.md`; `README_F34_GNR__nested_revised.md`
- `HANDOFF/EVIDENCE/03_Reference/Main_Script` — `radiognrscript.pas`; `radiognrscript.psc`
- `Save_file` — `Save10_984B9A86_4E6F6C616E20436861636861_F3_Wasteland_000744_20261118105621_7_2.f4se`; `Save10_984B9A86_4E6F6C616E20436861636861_F3_Wasteland_000744_20261118105621_7_2.fos`; `Save11_984B9A86_4E6F6C616E20436861636861_F3_Wasteland_000834_20261118105922_7_2.f4se`; `Save11_984B9A86_4E6F6C616E20436861636861_F3_Wasteland_000834_20261118105922_7_2.fos`
- `decomp_runs/RUN/gnr_psc` — 639 files (psc:639); `tif_f3_radiogalaxynewsquest_0101e52c.psc` … `tif_f3_radiogalaxynewsquest_011895be.psc`
- `decomp_runs/RUN/upload_me` — `report.txt`; `summary.csv`
- `decomp_runs/RUN/upload_me/asm` — `radiognrscript.pas`
- `decomp_runs/RUN/upload_me/logs` — `champollion_help.txt`; `main_asm.out.txt`; `main_champollion.err.txt`; `main_champollion.out.txt`; `main_comment.out.txt`
- `decomp_runs/RUN/upload_me/psc_frag` — 639 files (psc:639); `tif_f3_radiogalaxynewsquest_0101e52c.psc` … `tif_f3_radiogalaxynewsquest_011895be.psc`
- `decomp_runs/RUN/upload_me/psc_main` — `radiognrscript.psc`
- `decomp_runs/RUN/upload_me/psc_main_comment` — `radiognrscript.psc`
- `decomp_runs/RUN/upload_me/strings` — `radiognrscript.strings.txt`
- `esp_bundles` — `F34_GNR_TestA.esp`; `F34_GNR_TestA0_AllThree_control.esp`; `F34_GNR_TestA1_SongsPlayed.esp`; `F34_GNR_TestA2_LastSongPlayed.esp`; `F34_GNR_TestA3_SongIntro.esp`; `F34_GNR_TestB.esp`; `GNR No Static_F34.esp`; `GNR_Everywhere_F34.esp`

## Part 2 — `F34 radio extracion/` (game-data extraction; counts only)
- `meshes/terrain` — 879 files (btr:516, bto:363); `f3_wasteland.16.-16.-16.bto` … `f3_wasteland.8.8.8.btr`
- `music/f3` — 63 files (wav:63); `base_01.wav` … `tension_01.wav`
- `scripts` — 1 files (pex:1)
- `scripts/f3` — 2,783 files (pex:2783); `aacubeautosaveboxscript.pex` … `zimmerscript.pex`; GNR/radio-named: `radiognrscript.pex`, `threedogscript.pex`, `dialoguegnrquestscript.pex`, `gnrbroadcasteffectscript.pex`, `gnrbehemothtriggerscript.pex`, `gnrdoorintercomscript.pex`, `gnrentrancedoor01demoscript.pex`, `mq01gnrmutantscript.pex`, `mq02gnrbackdoorscript.pex`
- `scripts/f34` — 71 files (pex:71); `altstart.pex` … `worldtour.pex`; GNR/radio-named: `radiogate.pex`, `radiostation.pex`
- `scripts/f34pack` — 243 files (pex:243); `abrahamwashington.pex` … `zip_packend.pex`
- `scripts/f34patrol` — 11 files (pex:11); `pp_f3_0110b4bf.pex` … `pp_f3_0118cf4c.pex`
- `scripts/f34talk` — 10 files (pex:10); `dlc03margot.pex` … `rivetcitybridgeintercom.pex`
- `scripts/fragments` — 11,353 files (pex:6182, txt:5170, py:1); `pexdump.py` … `tif_f3_waterbeggars_01182781.txt`; subfolders: topicinfos (tif_* `.pex`+`.txt` pairs; `tif_f3_radiogalaxynewsquest_*` = 1278 files, i.e. 639 fragments with .pex and .txt), packages, quests, terminals; GNR-named fragments elsewhere: `term_f3_mq02gnrlockterminal02_01027973.pex`, `term_f3_mq02gnrlockterminal03_0106d85a.pex`
- `sound/f3` — 3,283 files (wav:3282, lip:1); `amb_airconditionervault_01_lp.wav` … `xxx_radiostatictestsmall.wav`
- `sound/voice` — 142,184 files (wav:83394, lip:58790); `00000a75_1.lip` … `00fffc00_1.wav`; 128 voice-type folders under `sound/voice/fallout34.esm/`; Three Dog = `f3_maleuniquethreedog` (1,640 files); largest: `playervoicefemale01` 11,826, `playervoicemale01` 11,826, `f3_maleadult01default` 9,467, `f3_femaleadult01default` 8,691

## Part 3 — ▲v5.2 Files attached on 21 Nov (not in the 20 Nov tree; location on the user's PC not stated)

| File | Size | SHA-256 (start) | In v5.2 zip? | Detail |
|---|---:|---|---|---|
| `F34_GNR_Guardv1.1.zip` | 6,199 B | `3ff65e8d…` | contents yes (`Guard_v1.1/`) | M2-B13 |
| &nbsp;&nbsp;`ReadMe.txt` | 1,640 B | `81b2221c…` | yes | |
| &nbsp;&nbsp;`F34_GNR_Guard.esp` | 263 B | `b0f31855…` | yes | same as the earlier guard ESP |
| &nbsp;&nbsp;`Scripts/F34GNRGuard.pex` | 5,213 B | `a82608be…` | yes | |
| &nbsp;&nbsp;`Scripts/Source/User/F34GNRGuard.psc` | 3,754 B | `74b72a4b…` | yes | |
| `F34_GNR_Guard.0.log` (v1.1 run, 21 Nov 03:19–03:33) | 670 B | `f1e5a6d2…` | yes, renamed `logs/F34_GNR_Guard.0_v1.1_run_2026-11-21.log` | M2-B13.3 |
| `GNR_SongVolumehigh_volume.esp` | 4,020 B | `9ba6a61b…` | **no** (third-party plugin) | M2-B14 |
| `Save1_22AA1324_4E65775F73617665_F3_Wasteland_000002_20261118215740_2_2.fos` | 15,190,242 B | `5533d484…` | **no** (large, personal) | M2-B15 |
| `Save1_22AA1324_4E65775F73617665_F3_Wasteland_000002_20261118215740_2_2.f4se` | 2,390 B | `977524c5…` | **no** | M2-B15 |

**Still not seen by anyone in this chain (ask only when the question needs it):** guard v0.3 source/PEX/log · the user's v0.2 log · the "virgin save" of the v0.3 report (filename) · `make_radio_volume_patch.py` · a parsed quest-variable block of any save.
