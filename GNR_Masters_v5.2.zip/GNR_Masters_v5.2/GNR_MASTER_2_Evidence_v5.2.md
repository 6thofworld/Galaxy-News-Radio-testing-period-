# Fallout 34 – Galaxy News Radio (GNR)
## MASTER 2 of 2 — Evidence and Appendices — **v5.2** · 21 Nov 2026

Companion to `GNR_MASTER_1_Story_and_Status_v5.2.md` (read that first). **v5.2 = v5.1 (lean, trimmed from v5.0) + new appendices B13–B15 and marked "▲v5.2" additions** (B1, B7, B8.5, B10, B11.3). Findings of B1–B12 are otherwise unchanged. Four bulk blocks (**B5.3** all-52-reset listing, **B5.4** 172-row fragment table, **B7.2** guard v0.2 source, **B8.2** full 85-line old-save log) are in `GNR_ARCHIVE_v5.0_full_and_bulk.zip` (outside the project) because each is reproducible from a source file named below. Labels as in Master 1.

## Contents
B1 File inventory · B2 Plugin inventories · B3 Early notes · B4 Scenes/INFO/builds · B5 Fragments, gates, anomalies, song map · B6 Main script · B7 Guard (v0.1/v0.2) · B8 Logs · B9 Dev's radio fix · B10 Tools · B11 Self-recovery design · B12 v3.1 package · **B13 Guard v0.3 and v1.1 ▲** · **B14 Volume plugin ▲** · **B15 The 21 Nov test save ▲**

---

## B1. File inventory (compact)

Received in the v5.0 merge: `files.zip` (master v4.1 latest + v4.0 + `espdump.py`, `pexdump.py`, `song_fragment_map.py`); `GNR_Self_Recovery_Handoff_Package_2026-11-19.zip` (ChatGPT-session package); `F34_GNR_Guardlogs.zip` (guard ESP/PEX/source/README/3 tester logs); `GNR_Master_Session_Memory_v3.1.1.md`; two PDFs (text identical to the handoff `.md`s).

Key members of the handoff zip: `GNR_Full_Live_Quest_INFO_Export_v2.txt` (5.9 MB) + `.pas` exporter · **`GNR_Full_Live_Quest_Counter_Audit.csv`/`.md` (344 counter-changing INFO rows; source of every gate count here; SHA-256 begins `844e66b18f97c6bf`)** · `GNR_SongsPlayed_172_Fragment_CrossReference_2.csv` (statuses **stale**) · `GNR_Counter_Fragment_Crosscheck_Audit.txt` · `radiognrscript.pas` (60,094 B bytecode listing; `.psc` truncated) · `README_F34_GNR__nested_revised.md` · inner evidence zip (`GNR_ResetInfoExport.txt`, `GNR_Target_INFO_Conditions_v3.txt`, audits).

Guard zip (v0.2 era): `F34_GNR_Guard.esp` (263 B, SHA-256 `b0f31855…`), `Scripts/F34GNRGuard.pex` (4,213 B, `128aee12…`), `Scripts/Source/User/F34GNRGuard.psc` (v0.2), `compile_guard.bat`, `HOWTO_compile_and_test.md` (v0.1 text), `README.txt`, `logs&scripts/` (`.0.log` = `.2.log` old save; `.1.log` reload; v0.2 and v0.1 `.psc`; `pexdump.py`).

▲v5.2 — received on 21 Nov (S9), all attached to the chat; details B13–B15:
- `F34_GNR_Guardv1.1.zip` (6,199 B, SHA-256 `3ff65e8d…`): `ReadMe.txt`, `F34_GNR_Guard.esp`, `Scripts/F34GNRGuard.pex`, `Scripts/Source/User/F34GNRGuard.psc`. Copy in the v5.2 zip: `Guard_v1.1/`.
- `F34_GNR_Guard.0.log` — the v1.1 run of 21 Nov (670 B, SHA-256 `f1e5a6d2…`). Copy: `Guard_v1.1/logs/F34_GNR_Guard.0_v1.1_run_2026-11-21.log`.
- `GNR_SongVolumehigh_volume.esp` (4,020 B, SHA-256 `9ba6a61b…`) — third-party; **not** in the v5.2 zip.
- `Save1_22AA1324_4E65775F73617665_F3_Wasteland_000002_20261118215740_2_2.fos` (15,190,242 B, SHA-256 `5533d484…`) and `.f4se` (2,390 B, SHA-256 `977524c5…`) — the test save; **not** in the v5.2 zip (large, personal).

Original project archive (v3.1.1): `Fallout34_GNR_Actual_Project.rar` (695 entries; 639 fragment `.psc`, `upload_me.zip` of 12 files, `Reference/` PDFs). Two READMEs exist (root 10,328 B; nested 9,494 B, the more complete).

**Not available to anyone:** `Fallout34.esm` (363,354,547 B, SHA-256 `16F35D6C23B9BD82E3BE3C3E7CC791DF2FFFAA29D9FF31806E7186D2FFECF7E9`), `Fallout34old.esm` (hash begins `53e89bfbc7df6d17323f`), `scripts.zip`, **any parsed save quest-variable block**, `radiofix.rar`, `tools/radiofix.py`, user's v0.2 log, tester's plugin list, **guard v0.3 files/log (▲v5.2)**, the `Fallout34_GNR_V3.1` package (B12).

---

## B2. Plugin inventories

### B2.1 Diagnostic test plugins (structural counts from binary inspection by earlier sessions; not runtime tests)

All six override the same 96 song INFOs (the two song topics `0AC92CD7` and `0AEAECDA`, 48 each). Added variable checks use CTDA function ID 629 with CIS2 metadata such as `::SongsPlayed_var`.

| Plugin | Structure | CTDA count |
|---|---|---:|
| `F34_GNR_TestA.esp` | two transmitter checks + `GetQuestRunning` on the 96 INFOs | 288 |
| `F34_GNR_TestB.esp` | two transmitter checks only | 192 |
| `F34_GNR_TestA0_AllThree_control.esp` | base + `SongsPlayed` + `LastSongPlayed` + `SongIntro` groups | 814 |
| `F34_GNR_TestA1_SongsPlayed.esp` | base + `SongsPlayed` (96) | 384 |
| `F34_GNR_TestA2_LastSongPlayed.esp` | base + `LastSongPlayed` (382: 94 INFOs × 4, 2 INFOs × 3) | 670 |
| `F34_GNR_TestA3_SongIntro.esp` | base + `SongIntro` on 48 INFOs | 336 |

A0 holds all three groups (526 added conditions). The bundle's `Patches/` folder held all eight ESPs (`GNR No Static_F34.esp` has a space in its name, which breaks some command-line tools). Test ESPs are diagnostics, not release patches; they overwrite another F34 version of those INFOs.

### B2.2 `GNR_Everywhere_F34.esp` and `GNR No Static_F34.esp`

| Detail | Everywhere | No Static |
|---|---|---|
| Description | "Fallout 34 GNR everywhere"; raises range of the two GNR transmitters in `F3_Wasteland` | "Fallout 34 mod converter"; converted for `Fallout34.esm` |
| Masters | `Fallout4.esm`, `Fallout34.esm` | same |
| Records | WRLD `F3_Wasteland`, CELL `01002DB4`, REFR `01FDDC93` and `01D7D651` (`F34_RadioTx_RadioGalaxyNews_0/_1`, base `0001FA5A`, flags 0xC00 = Persistent + Initially Disabled) | WRLD, CELL, REFR `01022488` (`F3_RadioGalaxyNewsRef01`, base `01022487`, flags 0x400 = Persistent), **no radio data** |
| Radio data `XRDO` | `(99.3, 1,000,000.0, 1,200,000.0, 0.0)` on each | none |
| Screenshot reading (Claude A) | tx0 `48,000 / 80,000` → `1,000,000 / 1,200,000`; tx1 `0 / 0` + "Ignores Distance Checks" → `1,000,000 / 1,200,000` without that flag (tx0 numbers flagged for a second look) | position + persistent flag only |
| Unknown | which of the four values are range values; real in-game effect | whether it removed static in the FO3 original |

Neither changes sound, quest, scene, INFO, script or the counter. The two plugins touch different references and do not override each other. ▲v5.2: the 18 Nov test save's plugin list contains both (B15); the **volume** plugin is a third, separate plugin (B14).

### B2.3 Master-file safety

The inspected ESPs supply overrides only while enabled; they do not rewrite `Fallout34.esm`. A running game can still write quest and scene state into a save — which is separate from editing a master. This covers the inspected ESPs only.

---

---

## B3. Early (17 Nov) notes

**Ruled out on paper (as of 17 Nov):**

| Suspect | Evidence | Status |
|---|---|---|
| Missing scripts / variables | `radiognrscript`, `radiostation`, `radiogate` and 639 fragments in the archive; variable names match the conditions; no GNR errors in the log | Cleared |
| Missing song files | All 20 `.wav` under `sound\f3\songs\radio\licensed\`; every descriptor matches one | Cleared |
| Sound settings | All 20 descriptors: `AudioCategoryRadio`, `SOMStereo`, 12.78 attenuation, no looping; loudness unchecked | Cleared on paper |
| Transmitter state | Both Persistent + Initially Disabled in the master; A2/A3 imply at least one satisfied the condition | **Not resolved**; enabler unknown |
| Scene phase missing/silent | B has S73 (Ink Spots), A has S96 (Cole Porter) | Cleared |
| Voice files for song INFOs | Not needed; "0 voice files" lines concern Radio New Vegas | Not a problem |
| Modder's `.fuz`/speaker theory | Contradicted how songs are built *as understood then* | **Now contested** (M1-7) |
| Wrong worldspace | Still failed in the Capital Wasteland | Weakened |

**Other 17 Nov observations:** 12 of the 20 song descriptors are also referenced by the House radio scenes (`HD00HouseRadio`); the other 8 ("Generic") are GNR-only. A third party's `F34_RadioFix` log (779 DJ lines, 225 song INFOs fixed across several stations) did not include any of the 96 GNR trigger INFOs among its 87 unmatched songs, and was truncated, so it proved little (note the 225 matches the INFO count of the developer's plugin, B9).

**Test-outcome decision table (from the original plan):**

| Result | Meaning / next step |
|---|---|
| Test A plays songs | Audio, scenes, INFOs fine; a variable condition blocks → re-add condition groups to find which |
| A silent, B plays | The quest-running check is the blocker |
| Both silent | Song topics probably never reached → read the N34 talk INFOs (topic `0AB326D6`) and topics `0AE97EDA`, `0AD68B0C` |
| Song starts, no sound | Audio side → Papyrus log, descriptor paths, test one song as a `.fuz` |

Use several fresh loads per test because the INFO is picked at random.

---

---

## B4. Scenes, INFO structure and builds

- **Scene A** (`F34_RadioScene_RadioGalaxyNews`, FormID in the user's load order `0A93BF68`) and **scene B** (`0AC0FA30`): 505 phases, 505 actions each (the old single scene had 435 phases). 70 wait phases `N#_W` (~0.75 s) precede talk phases.
- **Song topics:** scene A → `0AEAECDA`; scene B → `0AC92CD7`. Reset-bearing topics: scene A `0AB4CDB4`, `0AB3D5A1`, `0A942D8E`, `0A9FDA06`; scene B `0AFB2328`, `0AAE163B`, `0ACB5E3C`, `0AC0A9D3`; called around phases `N5_0`, `N5_1`, `N5_r0`, `N66_0`, `N66_1`, `N66_r0`. Counter-changing INFOs sit in nine topics per scene (**re-checked** from the audit CSV): scene A `0A942D8E`, `0A9FDA06`, `0AAFECBC`, `0AB3D5A1`, `0AB4CDB4`, `0ABB5C62`, `0AD68B0C`, `0AD702D2`, `0AEAECDA`; scene B `0A9E2AE6`, `0AAE163B`, `0AB24C30`, `0AC0A9D3`, `0AC92CD7`, `0ACB5E3C`, `0AD86F19`, `0AFB2328`, `0AFC288C`.
- **Actions in the scene export (earlier sessions):** 113 "Play Sound" actions per scene naming the song descriptors (`F34_RadioSnd_MUSLicensed…`) and 135 Radio-type actions with null sound (topic-based).
- **S61 maps to `LastSongPlayed`/`SongIntro` 12 and S72 maps to 1** in all three groups (whether this matches Three Dog's spoken intro lines is unverified).
- **INFO `0AED5399`** (song 1, scene A, fragment `01057B30`): flags Start Scene on End, Random, Random End, End Running Scene; empty text; null sound file; its single fragment is named `Fragment_End` but flagged OnBegin. From a screenshot: conditions #4–#7 "Not equal to 1" on the four history variables; `SongsPlayed` Equal to 0; flag decode (this INFO only): `10000000` = Equal to, `00000000` = Not equal to, `10010000` = Equal to / Or.
- **Build differences (earlier comparison):** current build retargets 172 INFOs, 468 of 640 shared GNR INFOs byte-identical; quests identical between builds; non-GNR differences not investigated. `F34MUSIC` clears the music stack on every load.
- The song CSVs duplicate every row twice (814 physical / 407 unique rows each); the two CSVs cover the same 48 increment fragments, in two contiguous families `01057B19–01057B30` and `0105A54E–0105A565` (24 each). For each song topic: 24 INFOs gated at counter 0, 24 at 1, 24 with a `SongIntro` gate; all with the two transmitter checks and `GetQuestRunning`.

---

---

## B5. Fragments, gates, anomalies and the song map

### B5.1 Totals (**re-checked** from the audit CSV)

- 172 counter-changing fragments: **120 increment** (60 gated at counter 0, 60 gated at 1) and **52 reset** (50 gated at 2, **2 gated at 1**). 344 INFO records (each fragment: one INFO in scene A, one in scene B, identical conditions).
- INFO-level gates: increments 120 × `=0`, 120 × `=1`; resets 100 × `=2`, 4 × `=1`. **No INFO accepts 3, 5 or any other value.**
- Every one of the 172 fragments shifts `LastSongPlayed4←3←2←1` then assigns `LastSongPlayed`; 36 also reset `SongIntro` to 0.
- 12 reset INFOs (topic `0A942D8E`, fragments `010A870B`–`010A8716`) also require `SongIntro` equal to the same 1–12 song number and reset `SongIntro` to 0.

### B5.2 Per-song summary (generated from the audit CSV)

Songs 1–12: 6 increments (3 + 3) and 3 resets each; songs 13–20: 6 increments (3 + 3) and 2 resets each. Resets are gated at 2 except song 1's `01074EF3` and `010A870A` (gate 1).

| Song | Incr gated 0 | Incr gated 1 | Resets (fragment:gate) |
|---:|---:|---:|---|
| 1 | 3 | 3 | `010A870A`:1, `010A8716`:2, `01074EF3`:1 |
| 2 | 3 | 3 | `010A8715`:2, `010A8709`:2, `01074EF2`:2 |
| 3 | 3 | 3 | `010A8708`:2, `010A8714`:2, `01074EF1`:2 |
| 4 | 3 | 3 | `01074EF0`:2, `010A8707`:2, `010A8713`:2 |
| 5 | 3 | 3 | `010A8712`:2, `010A8706`:2, `01074EEB`:2 |
| 6 | 3 | 3 | `010A8705`:2, `01074EE9`:2, `010A8711`:2 |
| 7 | 3 | 3 | `01074EE8`:2, `010A8710`:2, `010A8704`:2 |
| 8 | 3 | 3 | `01074EE7`:2, `010A870F`:2, `010A8703`:2 |
| 9 | 3 | 3 | `01074EE6`:2, `010A8702`:2, `010A870E`:2 |
| 10 | 3 | 3 | `010A870D`:2, `01074EE5`:2, `010A8701`:2 |
| 11 | 3 | 3 | `01074EE4`:2, `010A870C`:2, `010A8700`:2 |
| 12 | 3 | 3 | `01074EC4`:2, `010A870B`:2, `010A86FF`:2 |
| 13 | 3 | 3 | `010657E7`:2, `01065757`:2 |
| 14 | 3 | 3 | `01065759`:2, `010657E9`:2 |
| 15 | 3 | 3 | `0106575B`:2, `010657EE`:2 |
| 16 | 3 | 3 | `010657EF`:2, `0106575C`:2 |
| 17 | 3 | 3 | `010657F8`:2, `0106575E`:2 |
| 18 | 3 | 3 | `01065767`:2, `01065951`:2 |
| 19 | 3 | 3 | `01065769`:2, `01065983`:2 |
| 20 | 3 | 3 | `01065985`:2, `0106576A`:2 |

### B5.3 / B5.4 — moved to archive

*B5.3* (all 52 reset fragments with scene-A INFO) and *B5.4* (all 172 fragments → scene A/B DIAL+INFO, gates, SongIntro gate) are in the archive file and are **regenerable from `GNR_Full_Live_Quest_Counter_Audit.csv`** (columns: fragment, type, song, gates, scene A/B DIAL/INFO). Structure to remember: scene-A increments sit in `0AEAECDA` (songs 1–12, groups 1–3 incl. SongIntro-gated) and `0AD702D2` (songs 1–12); songs 13–20 sit in `0AD68B0C`, `0ABB5C62`, `0AAFECBC`; scene B mirrors with `0AC92CD7`, `0AFC288C`, `0AB24C30`, `0AD86F19`, `0A9E2AE6`. Reset topics: A `0AB4CDB4` (12, songs 1–12), `0AB3D5A1` (8, songs 13–20), `0A942D8E` (24: 12 + 12 SongIntro-gated), `0A9FDA06` (8); B `0AFB2328`, `0AAE163B`, `0ACB5E3C`, `0AC0A9D3`. All 52 reset TIF IDs match `.psc` files assigning `SongsPlayed = 0` (none missing/extra). Two reset exceptions gated at 1: `01074EF3` (A `0AE757B1`/`0AB4CDB4`; B `0AD3D631`/`0AFB2328`) and `010A870A` (A `0A95D0E8`/`0A942D8E`; B `0AEE8959`/`0ACB5E3C`). 12 reset INFOs (topic `0A942D8E`, fragments `010A870B`–`010A8716`) also require `SongIntro` = the song number.

### B5.5 Anomalies (VERIFIED-FILE; mismatches, not proven causes)

1. **Song 8, missing `LastSongPlayed3` check** — `01057B29` (A: INFO `0AB73340`, DIAL `0AEAECDA`; B: `0AFF891F`, `0AC92CD7`) and `010752A7` (A: `0AC9F568`, `0AD702D2`; B: `0AA24877`, `0AFC288C`). **Re-checked:** those four INFO rows have no `LastSongPlayed3` condition in the CSV. Effect: song 8 may be selected even when it sits in the third history slot.
2. **Two resets write song 1 but check song 2** — `01074EF3` (A: `0AE757B1`/`0AB4CDB4`; B: `0AD3D631`/`0AFB2328`) and `010A870A` (A: `0A95D0E8`/`0A942D8E`; B: `0AEE8959`/`0ACB5E3C`). Conditions compare all four slots to song 2, the fragment writes `LastSongPlayed = 1`, and the gate is `SongsPlayed == 1`. (The CSV rows show a history-condition type `00000000` = Not equal; **re-checked** gate = 1.)

### B5.6 Song ID map (record-derived by Claude C; spot-check in FO4Edit)

Method: fragment sources give `LastSongPlayed = N`; `SongInfoExport(for0AEAECDA).csv` gives each INFO's phase and fragment; the scene export (505 phases/actions) gives the "Play Sound" descriptor at that phase (or its `_GO` phase). Agrees with the S61 → 12, S72 → 1 mapping. **None of those three source files was available to this merge.**

| Song ID | Song (descriptor suffix) | Phases in the main song topic (scene A) |
|---|---|---|
| 1 | Cole Porter — Anything Goes (`ColePorterAnythingGoes`) | S72, S84, S96 |
| 2 | Tex Beneke — Guy (`TexBenekeGuy`) | S71, S83, S95 |
| 3 | Ella Fitzgerald — Into Each Life (`EllaFitzgeraldIntoEachLife`) | S70, S82, S94 |
| 4 | Danny Kaye — Civilization (`DannyKayeCivilization`) | S69, S81, S93 |
| 5 | Billie Holiday — Easy Living (`BillieHolidayEasyLiving`) | S68, S80, S92 |
| 6 | Billie Holiday — Crazy He Calls Me (`BillieHolidayCrazyHeCallsMe`) | S67, S79, S91 |
| 7 | Roy Brown — Mighty (`RoyBrownMighty`) | S66, S78, S90 |
| 8 | Roy Brown — Butcher (`RoyBrownButcher`) | S65, S77, S89 |
| 9 | Bob Crosby — Way Back Home (`BobCrosbyWayBackHome`) | S64, S76, S88 |
| 10 | Bob Crosby — Happy Times (`BobCrosbyHappyTimes`) | S63, S75, S87 |
| 11 | Ink Spots — Maybe (`InkSpotsMaybe`) | S62, S74, S86 |
| 12 | Ink Spots — I Don't Want to Set the World on Fire (`InkSpotsIDontWant`) | S61, S73, S85 |
| 13–20 | not mapped (other topics) | — |

▲v5.2 cross-check: the 20 descriptors in the volume plugin (B14) are the 12 named songs above plus 8 "Generic" (Boogie Man, Fox Boogie, I'm Tickled Pink, Jazzy Interlude, Jolly Days, Let's Go Sunning, Rhythm For You, Swing Doors); the 8 Generic ones are the likely songs 13–20 but **the ID↔descriptor link for 13–20 is not established**.

Fragments of the songs named in the logs (**re-checked**): song 5 increments `01057B20`, `01057B2C`, `0105A555`, `0105A561`, `010750E6`, `010752AA`; resets `01074EEB`, `010A8706`, `010A8712` (all gate 2). Song 9 increments `01057B1C`, `01057B28`, `0105A551`, `0105A55D`, `01074F2A`, `01075256`; resets `01074EE6`, `010A8702`, `010A870E`. Song 1 resets `01074EF3` (gate 1), `010A870A` (gate 1), `010A8716` (gate 2, `SongIntro == 1`).

---

---

## B6. Main script and bytecode findings

**Two independent readings agree.** Claude A read `radiognrscript.pas` (complete bytecode listing, 60,094 B; the `.psc` is truncated because Champollion crashes; 275 identifiers in the strings extraction). Claude C wrote `pexdump.py` for Fallout 4 PEX v3.9 (little-endian), parsed `radiognrscript.pex` to the last byte (16,677 of 16,677) and fragment `.pex` files fully (897 of 897; 890 and 924 for others). Opcode argument counts were written from memory, **not validated against Champollion**. The `.pex` files carry the header `Fix the translator, not this file` and were made by `f34.geck` / `papyrus.py` (user `f34`, compiled timestamp 1600000000).

- `SongsPlayed`: auto property (flags 7) on a plain Int variable; initial value 0; no cap or reset in the script.
- `F34_Add_SongsPlayed(afDelta)`: `::SongsPlayed_var += afDelta`, returns it. (`radiognrscript.pas` lines ~807–823: `iadd SongsPlayed_var, SongsPlayed_var, afDelta`.)
- `F34_QSnap`: before quest start, copies quest variables into snapshot slots `F34_qsN`; `SongsPlayed` = slot 18. `F34_QRestore`: after quest start, for each variable, if the snapshot value is nonzero **and** the current value is 0, assign the snapshot value.
- `F34_FragBegin`: `F34_FragUntil = GetCurrentRealTime + 2.0`; `F34_FragEnd`: `= 0.0`. 172 fragments call Begin then End.
- `F34_GameModeTick`: MS08/Harkness exploit logic only.
- `OnQuestInit` starts timer 1 with `F34_TickDelay`; `OnTimer` runs the tick with real-time guards.
- Fragments read individually by Claude C: `01057B30` (records song 1, then `F34_Add_SongsPlayed(1)`), `0105A55A` (song 12, same), `01065757` (song 13: shifts history, sets `SongsPlayed = 0`, does **not** touch `SongIntro`), `010A870B` (sets `SongIntro = 0` and `SongsPlayed = 0`, shifts history, records song 12), `010A8716` (records song 1, sets `SongIntro = 0` and `SongsPlayed = 0`). **Reset fragments also update the history**, so "set the counter to 0" is not equivalent to a normal reset. The user's `findstr` runs across the extracted fragments found 52 with `propset SongsPlayed` and about 120 calling `F34_Add_SongsPlayed(1)`, matching the audit; the assigned value in 49 of the 52 resets was not individually read.
- **Callers:** 56 `QSnap`/`QRestore` callers in CG02/CG03 fragments (older README, acting on their own quests); none in the main GNR script or the 639 GNR fragments (Claude A); 1,786 `scripts.zip` files merely *mention* `F34_QSnap` (unclassified).

---

---

## B7. The guard (v0.1/v0.2): package and parse (source moved to archive)

*▲v5.2: v0.3 and v1.1 are in B13.*

### B7.1 Version differences (v0.1 vs v0.2, **diff re-checked** from the package's two `.psc` files)

v0.2 changes: poll 30 s → 5 s; `InvalidStreak` replaced by `ResetCount`; logs on every `SongsPlayed` change (the "valid/INVALID" labelling removed); adds the write `gnr.SetPropertyValue("SongsPlayed", 0)` when `played >= 2`, then logs `RESET #n: SongsPlayed was X, set to 0, now reads Y`; `OnPlayerLoadGame` no longer resets `InvalidStreak`. v0.1's header: "MONITOR ONLY … never writes to the GNR script".

### B7.2 v0.2 source — moved to archive (also `Scripts/Source/User/F34GNRGuard.psc` in the older guard zip)

Behaviour in brief: `F34GNRGuard extends Quest`; `OnInit` logs "guard v0.2 (resets SongsPlayed >= 2 to 0) started", registers `OnPlayerLoadGame`, starts a 5 s timer; `Poll()` gets the quest via `Game.GetFormFromFile(0x00022486, "Fallout34.esm")`, casts with `CastAs("F3:RadioGNRScript")`, reads `SongsPlayed`/`SongIntro`/`LastSongPlayed…4` with `GetPropertyValue`, logs on `SongsPlayed` change, and **if `played >= 2` calls `SetPropertyValue("SongsPlayed", 0)`**, increments `ResetCount`, logs `RESET #n: … now reads Y`. Does nothing and logs once if quest or script is missing. Log path: `Documents\My Games\Fallout4\Logs\Script\User\F34_GNR_Guard.0.log`. **Unsafe; do not distribute.**

### B7.3 Build and test notes

`compile_guard.bat` (put next to `Fallout4.exe`): `cd` to `Data\Scripts\Source\Base`, run `Papyrus Compiler\PapyrusCompiler.exe` on `Data\Scripts\Source\User\F34GNRGuard.psc` with flags file `Institute_Papyrus_Flags.flg`, import path `User;Base`, output `Data\Scripts`; it prints "F34GNRGuard.pex exists" on success. Quest setup (user-reported): new `F34_GNR_Guard.esp` with one quest, Start Game Enabled on, Run Once off, no stages/aliases, script attached, after `Fallout34.esm`. The CK Papyrus Manager listed the script (Compiled Yes, Has Source Yes) though the Add Script dialog initially did not; `CreationKit.ini` has `sScriptSourceFolder = ".\Data\Scripts\Source\User"`; `creationkitcustom.ini` only has `bAllowMultipleMasterLoads=1`. Papyrus logging needs `[Papyrus]` `bEnableLogging=1` `bEnableTrace=1` in `Fallout4Custom.ini` (profile copy under MO2).

### B7.4 ESP raw parse (my own)

`F34_GNR_Guard.esp`, 263 bytes: `TES4` (masters `Fallout4.esm`, `Fallout34.esm`), one `GRUP` with one `QUST` (FormID `020032D2`, record size 82): `EDID "F34_GNR_Guard"`, `VMAD` (22 bytes: version 6, object format 2, **script count 1**, name `F34GNRGuard`, status 0, property count 0), `DNAM` (12 bytes: `11 00 00 0E 00 00 00 00 00 00 00 00`), empty `NEXT`, `ANAM` = 0. No stages, aliases or conditions. ▲v5.2: the v1.1 package's ESP has the same SHA-256 (`b0f31855…`), so this parse applies to it unchanged.

---

---

## B8. Logs (key lines; full old-save log in archive)

All timestamps as written; tester logs on the tester's clock (11/18/2026 evening); user's on 11/19/2026 and 11/21/2026.

### B8.1 User's own v0.1 log (19 Nov 2026, user's clock)
```
[11/19/2026 - 07:56:56AM] F34_GNR_Guard log opened (PC-64)
[11/19/2026 - 07:56:56AM] guard v0.1 (monitor only) started
[11/19/2026 - 07:56:56AM] guard v0.1 (monitor only) started
[11/19/2026 - 07:57:37AM] SongsPlayed=2 valid | SongIntro=1 | history=8,2,0,0
```

### B8.2 Tester, existing save, guard v0.2 — first non-RESET lines + last line (the 35 RESET lines, #1–#35 from 10:19:13PM to 10:48:42PM, are in the archive; identical to `.0.log`/`.2.log` in the guard zip)
```
[11/18/2026 - 10:19:02PM] F34_GNR_Guard log opened (PC-64)
[11/18/2026 - 10:19:02PM] guard v0.2 (resets SongsPlayed >= 2 to 0) started
[11/18/2026 - 10:19:02PM] guard v0.2 (resets SongsPlayed >= 2 to 0) started
[11/18/2026 - 10:19:13PM] SongsPlayed=1596 | SongIntro=0 | history=9,9,9,9
[11/18/2026 - 10:20:27PM] SongsPlayed=1 | SongIntro=0 | history=5,9,9,9
[11/18/2026 - 10:25:00PM] SongsPlayed=0 | SongIntro=0 | history=1,5,9,9
[11/18/2026 - 10:29:50PM] SongsPlayed=1 | SongIntro=0 | history=5,1,5,9
[11/18/2026 - 10:34:04PM] SongsPlayed=0 | SongIntro=0 | history=1,5,1,5
[11/18/2026 - 10:40:03PM] SongsPlayed=1 | SongIntro=0 | history=5,1,5,1
[11/18/2026 - 10:43:34PM] SongsPlayed=0 | SongIntro=0 | history=1,5,1,5
... (further non-reset readings omitted; see archive)
[11/18/2026 - 10:50:56PM] SongsPlayed=1 | SongIntro=0 | history=9,1,5,18
```
Stats (**re-checked**): 85 lines, 35 RESET lines. Two resets read back 1 right after being set to 0: #4 and #25.

### B8.3 Tester, same save reloaded, guard v0.2 (identical to `F34_GNR_Guard.1.log` in the guard zip)
```
[11/18/2026 - 11:16:54PM] F34_GNR_Guard log opened (PC-64)
[11/18/2026 - 11:16:54PM] save loaded
[11/18/2026 - 11:16:59PM] SongsPlayed=1 | SongIntro=0 | history=9,1,5,18
[11/18/2026 - 11:17:41PM] SongsPlayed=2 | SongIntro=0 | history=9,9,1,5
[11/18/2026 - 11:17:41PM] RESET #36: SongsPlayed was 2, set to 0, now reads 0
[11/18/2026 - 11:18:07PM] Log closed
```

### B8.4 Tester, new save, guard v0.2 (gist `gistfile1`; not in the guard zip)
```
[11/18/2026 - 11:18:20PM] F34_GNR_Guard log opened (PC-64)
[11/18/2026 - 11:18:20PM] guard v0.2 (resets SongsPlayed >= 2 to 0) started
[11/18/2026 - 11:18:33PM] guard v0.2 (resets SongsPlayed >= 2 to 0) started
[11/18/2026 - 11:18:45PM] SongsPlayed=0 | SongIntro=0 | history=0,0,0,0
[11/18/2026 - 11:20:02PM] SongsPlayed=67 | SongIntro=0 | history=9,9,9,9
[11/18/2026 - 11:20:02PM] RESET #1: SongsPlayed was 67, set to 0, now reads 0
[11/18/2026 - 11:22:24PM] SongsPlayed=1 | SongIntro=0 | history=5,1,5,16
[11/18/2026 - 11:25:53PM] SongsPlayed=0 | SongIntro=0 | history=1,5,1,5
[11/18/2026 - 11:30:43PM] SongsPlayed=1 | SongIntro=0 | history=9,1,5,1
[11/18/2026 - 11:35:12PM] SongsPlayed=2 | SongIntro=0 | history=19,9,1,5
[11/18/2026 - 11:35:12PM] RESET #2: SongsPlayed was 2, set to 0, now reads 0
[11/18/2026 - 11:40:00PM] SongsPlayed=1 | SongIntro=0 | history=13,19,9,1
[11/18/2026 - 11:44:21PM] SongsPlayed=2 | SongIntro=0 | history=5,13,19,9
[11/18/2026 - 11:44:21PM] RESET #3: SongsPlayed was 2, set to 0, now reads 0
```

### B8.5 ▲v5.2 — user's guard v1.1 run, 21 Nov 2026 (user's clock) — see B13.3 for the full log and timing table.

---

## B9. The developer's radio fix (details carried from v4.1; archive not re-opened)

Provenance: given to the user by a main F34 developer. Opened by Claude C with libarchive (no unrar) and the plugins parsed with `espdump.py`. **`Fallout34.esm` was not available, so what the original records contain was not compared.**

- Contents (344,224,012 bytes uncompressed): `F34_RadioFix.esp` (163,064 B), `F34_RadioFixNV.esp` (51,990 B); `Sound/Voice/Fallout34.esm/`: `F34R_RadioMusic` 225 `.fuz`, `F3_MaleUniqueThreeDog` 524, `F3_MaleUniquePresident` 140, `F3_UniqueRadioPlay` 89, `F3_MaleUniqueVault101PA` 14, `F3_MaleUniqueOverseer` 6, `F3_MaleUniqueAutumn` 4, `F3_RobotProtectron` 2; `Sound/Voice/FalloutNV34.esm/`: `F34R_RadioMusic` 88, `FNV_NVDLC01MaleUniqueElijah` 73, `FNV_NVDLC01MaleUniqueDean` 49, `FNV_RobotProtectron` 1. File names are INFO form IDs (e.g. `009021CB_1.fuz`).
- `F34_RadioFix.esp`: masters `Fallout4.esm`, `Fallout34.esm`; description "Fallout 34 radio fix (FO3): songs and missing DJ lines for the Capital Wasteland radio stations, from your own Fallout 3 install. Built by tools/radiofix.py." Records: 225 INFO, 15 DIAL, 5 QUST (`F34_Radio_RadioEnclave` 01DE8CB7, `F34_Radio_RadioGalaxyNews` 01D0EE64, `F34_Radio_RadioVault101` 019715B9, `F34_Radio_MS17AgathasRadio` 01E7CBE2, `F34_Radio_HD00HouseRadio` 01B67042), 1 VTYP (`F34R_RadioMusic`, 02000800), 1 NPC_ (`F34R_RadioMusicVoice`, 02000801). All 225 INFOs name speaker 02000801 and a Start-Scene-on-End target; conditions use the same variables as the originals (`SongsPlayed` 172 uses, `LastSongPlayed` 1–4 170–178, `SongIntro` 36, plus other stations' `AlreadyPlayed`, `LastSong`, `LastSong2`, `LastSong3`).
- Overlap with the GNR exports: all 48 INFOs of `SongInfoExport(for0AEAECDA).csv` are in the fix; none of the 48 of `…(for0AC92CD7).csv`; 177 of the 225 are other INFOs. Sample: INFO `0ADBA880` (local `DBA880`, phase S96): speaker 02000801, start-scene target `0193BF68` (= scene A), conditions on `SongsPlayed` and all four history slots, a fragment script, name `S96`.
- `F34_RadioFixNV.esp`: masters `Fallout4.esm`, `FalloutNV34.esm`; 88 INFO, 9 DIAL, 7 QUST, same VTYP/NPC pair and pattern; NV INFOs check three history slots, not four. New Vegas stations only (Black Mountain, Christine, New Vegas TA, Casino Tops, Gomorrah, Ultra-Luxe, Country, …). Not GNR evidence.
- Not known: whether scene B's 48 were skipped deliberately; the originals' content; whether the matching `.fuz` exists for each of the 48; which of the 225 beyond the 48 are GNR.
- **Copyright:** converted game audio built from the user's own install; do not redistribute.

---

---

## B10. Tools and scripts

| Tool | Purpose | Status |
|---|---|---|
| `pexdump.py` (SHA `7056908e…`) | Reads Fallout 4 PEX v3.9: header, strings, debug info, objects, variables, properties, states, functions, instructions | Written by Claude C; opcode arg counts from memory; used on the main script, fragments and the guard PEX (v0.2). ▲v5.2: **not** run on the v1.1 PEX — only its strings were read |
| `espdump.py` (SHA `5f506e28…`) | Reads TES4 header, groups, zlib records, subrecords; prints masters and record counts | Used on Everywhere/NoStatic, dev's plugins, the guard ESP |
| `song_fragment_map.py` (SHA `511d3698…`) | Maps fragment dumps to song IDs and counter actions | Tested only on five dumps |
| `compile_guard.bat`, `HOWTO_compile_and_test.md` | Guard compile/test | from the user's earlier session |
| Earlier tools mentioned (not in these zips): `ExportRecordList.pas`, `ExportSongInfos.pas`, an ExportFullInfo script, `ba2_gnr_check.py`, `ba2_extract_script.py`, `ba2_extract_gnr_script.py`, `MakeTestA.pas`, `MakeTestB.pas`, and the ChatGPT session's `GNR_Full_Live_Quest_INFO_Export_v2.pas` (present in the handoff zip) | Export/inspection | — |
| ▲v5.2 ad-hoc one-off Python (not saved): parse of the volume plugin's `SNDR` group (B14) and of the save header/plugin list (B15) | read-only inspection | the save-header parse printed garbage once (field layout guessed) before plugin names were taken with `strings`; **the plugin order in B15 is not a reliable load order** |

Run any of the Python scripts with `python3 -I` and keep untrusted inputs in their own folder.

---

---

## B11. Self-recovery design and work plan

### B11.1 Design requirements (from the ChatGPT-session objective; unchanged)

| Requirement | Expected behaviour |
|---|---|
| Valid-state no-op | Leave 0, 1, 2 unchanged *(▲v5.2: 2 only for up to 30 s in v1.1 — M1 §9 item 23)* |
| Invalid-state detection | Detect values < 0 and > 2; verify no intentional transient values exist |
| Safe recovery | Use vetted normal-reset semantics where possible |
| History integrity | Preserve the four history slots unless the chosen reset intentionally updates them; do not invent a history policy |
| Intro integrity | Do not alter `SongIntro` without proof it is required |
| Idempotence | Do not repeat repairs or fight normal fragments |
| Timing safety | Avoid racing partial fragment writes and INFO evaluation |
| Isolation | Do not alter unrelated quests, radios, scenes, transmitters or master records |
| Observability | Diagnostic mode logs old value, decision, action and resulting state *(▲v5.2: v1.1 does not log `SongIntro`/history)* |
| Failure safety | If the GNR quest/script cannot be resolved: do nothing, report |
| Diagnostic first | Monitor-only mode before any write |
| Compatibility | Check load order, overrides, persistence, property access |

### B11.2 Recommended work sequence (original six steps, retained)

A inspect exact source (property type, `F34_Add_SongsPlayed`, each fragment's write set, whether reset fragments are interchangeable, periodic behaviour) → B define invariants and legal transitions (valid states, triggers, counter/history relation, what a normal reset changes, whether 2 is a waiting state, any transient/negative values) → C choose the safest repair point (helper-quest timer vs event/scene boundary vs controlled recovery function; races with INFO conditions and `F34_FragBegin/End`) → D diagnostic prototype first (log without modifying; prove property resolution; prove monitor reliability) → E repair only after the transition is approved, in a separate ESP, no `Fallout34.esm` edits → F test on disposable saves and report compile success separately from in-game success.

### B11.3–B11.4
The monitor-only spec and the repair test matrix are in Master 1 §10 (not duplicated). ▲v5.2: **v0.3 was built on 20 Nov** (REPORTED; files unseen) and **v1.1 on 21 Nov** (B13); the six-step sequence is at step D–E (a repair candidate exists, the diagnostic baseline does not).

---

## B12. The not-uploaded `Fallout34_GNR_V3.1` package (summary)

`Fallout34_GNR_Claude_B_Package_v3.1.1.zip` → `Fallout34_GNR_Lean/` (696 files, 695 SHA-256 entries all matched): `1_Scripts/` (639 fragment `.psc`, main script `.pas`/truncated `.psc`, decompile run), `2_Patches/` (the eight ESPs), `3_Exports_F34/` (scene A `0A93BF68` / B `0AC0FA30` exports, the two `SongInfoExport` CSVs, `FullInfo_Export.txt`, `NoEditorID_0AED5399.txt`), `4_Reference_Only/` (NV/FO4 comparison material — never GNR evidence), `6_Session_Updates/` (Claude A transcript), `9_Archive_Superseded/`. Evidence map: fragment behaviour → `1_Scripts/fragments_639/`; scene hand-offs → the two scene exports; song INFO conditions → song CSVs + `FullInfo_Export.txt` + `NoEditorID_0AED5399.txt`; Claude A's matrix → `6_Session_Updates/`.

---

---

## B13. ▲v5.2 — Guard v0.3 (reported) and guard v1.1 (inspected)

### B13.1 Guard v0.3 (REPORTED only)
Built 20 Nov per the user's session notes. Monitor-only. Poll interval, fields logged and hashes UNKNOWN (files not seen). Reported run: virgin save, ~5 min ×2, no songs; log `SongsPlayed=2`, `SongIntro=1`, history `8,2,0,0` for the whole run (~170 polls); disabling the guard ESP did not help; v0.2 on the same → songs. Same tuple as B8.1 (19 Nov, v0.1) — INFERENCE that both runs came from the same stored state.

### B13.2 Guard v1.1 package (VERIFIED-FILE; not compiled or run by me)

| File | Size | SHA-256 |
|---|---:|---|
| `ReadMe.txt` | 1,640 B | `81b2221c…` |
| `F34_GNR_Guard.esp` | 263 B | `b0f31855…` (**same as the earlier guard ESP**) |
| `Scripts/F34GNRGuard.pex` | 5,213 B | `a82608be…` (strings read; bytecode not parsed; its identifier list matches the PSC: `LogName`, `PollSeconds`, `TimerID`, `MaxValid`, `RecoveryValue`, `MaxResetsPerSession`, `MaxLogLines`, `StuckSeconds`, `StartGuard`, `Resolve`, `Check`, `stuckSince`, `lastSeen`, `resetsThisSession`, `backedOff`, `missingLogged`, `initCalls`, `logLines`) |
| `Scripts/Source/User/F34GNRGuard.psc` | 3,754 B | `74b72a4b…` |
| `logs/F34_GNR_Guard.0_v1.1_run_2026-11-21.log` | 670 B | `f1e5a6d2…` |

Constants (all `AutoReadOnly Hidden`): `PollSeconds 3.0`, `TimerID 1`, `MaxValid 2`, `RecoveryValue 0`, `MaxResetsPerSession 10`, `MaxLogLines 300`, `StuckSeconds 30.0`. Header text: "F34 GNR Guard v1.1 (candidate)".

Logic of `Check()` (from the PSC):
1. `Resolve()`: `Game.GetFormFromFile(0x00022486, "Fallout34.esm") as Quest`, then `CastAs("F3:RadioGNRScript")`; if it fails, log once "GNR quest or F3:RadioGNRScript not found - doing nothing" and return.
2. `played = GetPropertyValue("SongsPlayed")`; if it differs from `lastSeen`, log `SongsPlayed=<n> (was <old>)`, update `lastSeen`, clear `stuckSince`.
3. `0 <= played < 2` → clear `stuckSince`, return (never touched).
4. `played == 2` → start `stuckSince` (real time); return until `now - stuckSince >= 30 s`; then log "SongsPlayed has stayed at 2 for 30.0s - treating as stuck" and continue.
5. If `backedOff` → return. If `resetsThisSession >= 10` → set `backedOff`, log `BACKOFF …`, return.
6. `SetPropertyValue("SongsPlayed", 0)`; `resetsThisSession += 1`; read back; log `RECOVERY #n: SongsPlayed <old> -> 0 (reads back <x>)`; `lastSeen = x`.

`StartGuard(reason)` (called from `OnInit` and from `Actor.OnPlayerLoadGame`): cancels the timer, opens the user log, clears `gnr`, `lastSeen`, `resetsThisSession`, `backedOff`, `missingLogged`, registers `OnPlayerLoadGame`, logs `started (<reason>)`, starts the 3 s timer. `OnInit` increments `initCalls` and logs `OnInit #<n>`.

Differences that matter: v1.1 does **not** log `SongIntro`/history or read them. The stuck timer uses real time (`Utility.GetCurrentRealTime`); whether menu/loading pauses advance it was not tested. After a `StartGuard`, `lastSeen` is reset to −999, so the next poll logs the counter again and clears `stuckSince` (read from the source; not run).

`ReadMe.txt` (clean): what it fixes (counter outside 0/1; "2 that does not change for 30 seconds"), install (ESP + PEX at the mod top level, after `Fallout4.esm` and `Fallout34.esm`; no older PEX; "Older v0.2 builds reset the valid value 2 too"), log enablement and log-line key.

### B13.3 The v1.1 run log (VERIFIED-FILE; user's clock)

```
[11/21/2026 - 03:19:36AM] F34_GNR_Guard log opened (PC-64)
[11/21/2026 - 03:19:36AM] started (OnInit #1)
[11/21/2026 - 03:19:39AM] started (OnInit #1)
[11/21/2026 - 03:19:44AM] SongsPlayed=2 (was -999)
[11/21/2026 - 03:20:16AM] SongsPlayed has stayed at 2 for 30.000000s - treating as stuck
[11/21/2026 - 03:20:16AM] RECOVERY #1: SongsPlayed 2 -> 0 (reads back 0)
[11/21/2026 - 03:21:19AM] SongsPlayed=1 (was 0)
[11/21/2026 - 03:27:35AM] SongsPlayed=2 (was 1)
[11/21/2026 - 03:28:06AM] SongsPlayed has stayed at 2 for 30.000000s - treating as stuck
[11/21/2026 - 03:28:06AM] RECOVERY #2: SongsPlayed 2 -> 0 (reads back 0)
[11/21/2026 - 03:33:00AM] SongsPlayed=1 (was 0)
```

| Event | Time | Gap |
|---|---|---|
| guard started (×2) | 03:19:36 / 03:19:39 | 3 s |
| first reading: 2 | 03:19:44 | 8 s after first start |
| recovery #1 (2→0) | 03:20:16 | 32 s after first reading |
| 0→1 (a song) | 03:21:19 | 63 s after recovery |
| 1→2 (a song) | 03:27:35 | 6 min 16 s |
| recovery #2 (2→0) | 03:28:06 | 31 s |
| 0→1 (a song) | 03:33:00 | 4 min 54 s after recovery |

User report: 3 songs heard (matches the three increments). Songs by name not recorded. The log ends at 03:33:00; the session length beyond that is not recorded (only counter *changes* are logged).

### B13.4 Reading notes
(a) Two `started (OnInit #1)` lines: if one object's `OnInit` ran twice the second line would read `#2`; two instances should also have logged the first reading twice — they did not. Cause UNKNOWN. (b) `SongsPlayed=2 (was -999)` is the first poll after a start, so the 2 was already present ≤ ~8 s after the guard started (stored state or generated at load — UNKNOWN). (c) The 1→2 step at 03:27:35 is a normal increment: the cycle reached 2 naturally, which v0.2 would have reset at once.

---

## B14. ▲v5.2 — `GNR_SongVolumehigh_volume.esp` (VERIFIED-FILE, my own parse)

- 4,020 B, SHA-256 `9ba6a61b99aed4607e4bcc3b0448909030ac91237a63aaf10c6938784310e124`. `TES4` flags 0; author (CNAM) "cloakarx"; description (SNAM) "Fixes quiet songs on Galaxy News Radio"; masters `Fallout4.esm`, `Fallout34.esm`.
- Content: one `GRUP` of type `SNDR` with **20 records**, nothing else. Each record's FormID has load-order byte `01` (= `Fallout34.esm`), i.e. these are **overrides of the master's sound descriptors**, not new records. All 20 share identical `ONAM` `caed0700`, `BNAM` `000080000000`, `LNAM` `00000000`, `GNAM` `161b0200`, `CNAM` `0a54ef1e`, and each points at `data\sound\f3\songs\radio\licensed\<name>.wav`.
- Which of these values differs from the master (i.e. what "high volume" means) **cannot be told** without `Fallout34.esm`. No quest, scene, INFO, script, condition or counter record is present, so it cannot change `SongsPlayed`.
- It must load after `Fallout34.esm`; the user says it must be very early (REPORTED). A later plugin overriding the same 20 descriptors would win — not checked. It was **not** in the save's plugin list (B15), so it was added after the save was made.

| FormID (low 6 hex after `01`) | Descriptor (`F34_RadioSnd_MUSLicensed…`) | wav |
|---|---|---|
| `BE27BF` | InkSpotsIDontWant | mus_inkspots_idont |
| `92B91F` | InkSpotsMaybe | mus_inkspots_maybe |
| `D9A387` | BobCrosbyHappyTimes | mus_bobcrosby_happy |
| `F50467` | BobCrosbyWayBackHome | mus_bobcrosby_way |
| `E3E4A1` | RoyBrownButcher | mus_roybrown_butcher |
| `FE1393` | RoyBrownMighty | mus_roybrown_mighty |
| `FA5B79` | BillieHolidayCrazyHeCallsMe | mus_billieholiday_crazy |
| `A8C52D` | BillieHolidayEasyLiving | mus_billieholiday_easy |
| `FD1653` | DannyKayeCivilization | mus_dannykaye_civilization |
| `F685CA` | EllaFitzgeraldIntoEachLife | mus_ellafitzgerald_into |
| `FA5208` | TexBenekeGuy | mus_texbeneke_guy |
| `A0A7ED` | ColePorterAnythingGoes | mus_coleporter_anything |
| `FDDBA1` | GenericBoogieMan | mus_generic_boogie |
| `9DD7D5` | GenericFoxBoogie | mus_generic_fox |
| `91913D` | GenericImTickledPink | mus_generic_pink |
| `DC90A7` | GenericJazzyInterlude | mus_generic_jazzy |
| `E9F4D5` | GenericJollyDays | mus_generic_jolly |
| `DD27A7` | GenericLetsGoSunning | mus_generic_sunning |
| `F1B5AC` | GenericRhythmForYou | mus_generic_rhythmforyou |
| `E20085` | GenericSwingDoors | mus_generic_swingdoors |

(FormIDs shown are the low three bytes of the 32-bit value printed by my parser as e.g. `0x1be27bf`; the leading `01` is the master byte. Spot-check one or two in FO4Edit before relying on them.)

Lead (unverified): the folder map lists `make_radio_volume_patch.py` in `F34Radio Reports/scripts/`; whether it generated this plugin is a guess from the name — file not opened.

---

## B15. ▲v5.2 — The 21 Nov test save

- File: `Save1_22AA1324_4E65775F73617665_F3_Wasteland_000002_20261118215740_2_2.fos` (15,190,242 B, SHA-256 `5533d484082c002fab7a875980e8e28ad38842b167d02921945daa3f3454d279`) + `.f4se` (2,390 B, SHA-256 `977524c56e1236a688e2e88b3b63ad76765ac57df6585b879340df5fb5da74d5`). Name decode: save slot 1; the hex `4E65775F73617665` = "New_save"; worldspace `F3_Wasteland`; playtime stamp `000002`; timestamp `20261118215740` = **18 Nov 2026 21:57:40**.
- Header (VERIFIED-FILE, partial): magic `FO4_SAVEGAME`, header version field 15, save number 1, player `New_save`, location text ending "…asteland", playtime text "0d.0h.2m" (≈2 minutes), race `HumanRace`. The rest of the header parse failed after the race field (my field layout was wrong) — treat nothing beyond these items as verified. I did **not** read the quest-variable block, so the stored `SongsPlayed`, `SongIntro` and history of this save are **unknown**.
- Plugin names found in the save's plugin list (taken with `strings`; **order is not the load order**): `Fallout4.esm`, DLC masters, `Unofficial Fallout 4 Patch.esp`, `XDI.esm`, `TrueStormsFO4.esm`, `Fallout34.esm`, `Fallout34_2/3/4.esl`, `FalloutNV34.esm`, `FalloutNV34_2…5.esl`, `HUDFramework.esm`, `TacticalReload.esm`, `F34_BugFixes.esp`, `F34_BugFixes_NV.esp`, `F34_CreatureFixes.esp`, `F34_ClassicPowerArmor*`, `F34Online.esp`, `F34_TravelingTraders.esp`, `F34_MojaveCrows.esp`, `F34_MojavePatrols.esp`, `GNR No Static_F34.esp`, `GNR_Everywhere_F34.esp`, **`Platinum Radio_FNV34.esp`**, **`PlatinumRadio_Patch.esp`**, plus many NV-ported cosmetic and cc plugins (76 names seen in total). **Not present:** `GNR_SongVolumehigh_volume.esp`, `F34_GNR_Guard.esp`, `F34_RadioFix.esp`, any `F34_GNR_Test*.esp`.
- Meaning: the save was made before the guard and the volume plugin existed in its load order; the first reading of 2 on 21 Nov may be a stored value (UNKNOWN). `Platinum Radio` is an NV-side radio plugin — whether it interacts with GNR is unknown.
- Different from `Save10`/`Save11` (Reliable 01 = Save 11; F3_Wasteland; 18 Nov ~10:56/10:59 per the folder map; player-name hex `4E6F6C616E20436861636861`; counter 5 reported for Save 11).

*End of Master 2.*
