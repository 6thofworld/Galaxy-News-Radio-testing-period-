# F34GNRGuard v0.1 (monitor only): compile and test

Nothing here has been compiled or run yet. I cannot compile Papyrus in my environment.
Paths below are taken from your tree.txt (verified present): `Papyrus Compiler\PapyrusCompiler.exe`,
`Data\Scripts\Source\Base\` (already extracted, includes Debug.psc, Game.psc, Quest.psc, Institute_Papyrus_Flags.flg),
`Data\Scripts\Source\User\` (exists).

## Compile
1. Copy `F34GNRGuard.psc` to `<Fallout 4 folder>\Data\Scripts\Source\User\`
2. Copy `compile_guard.bat` to `<Fallout 4 folder>\` (next to Fallout4.exe) and double-click it.
3. Success: window ends with "F34GNRGuard.pex exists" and the compiler printed 0 errors.
   Failure: send me the exact text in the window.

## Quest (next step, not done)
A new plugin F34_GNR_Guard.esp with one Quest: Start Game Enabled on, Run Once off, no stages/aliases,
script F34GNRGuard attached, loaded after Fallout34.esm. I can generate it with an FO4Edit script.

## Test (disposable save copy)
1. Papyrus logging must be on. File is in Documents (not in your tree):
   `Documents\My Games\Fallout4\Fallout4Custom.ini` must contain
   `[Papyrus]` / `bEnableLogging=1` / `bEnableTrace=1`. Tell me if it is missing and I'll say exactly what to add.
2. Load a save, wait about 1 minute, quit.
3. Open `Documents\My Games\Fallout4\Logs\Script\User\F34_GNR_Guard.0.log` and send it to me.
   Healthy save: `SongsPlayed=N valid | SongIntro=.. | history=..`.
   Save11 (Reliable 01): expect `SongsPlayed=5 INVALID`, history 11,8,5,3.
