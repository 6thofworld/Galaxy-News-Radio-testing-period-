Scriptname F34GNRGuard extends Quest
{GNR song-counter guard, v0.1 MONITOR ONLY.
Reads F3:RadioGNRScript.SongsPlayed (and the song history) every PollSeconds and writes
what it sees to Documents\My Games\Fallout4\Logs\Script\User\F34_GNR_Guard.0.log.
It never writes to the GNR script. No repair code exists in this version.}

String Property LogName = "F34_GNR_Guard" AutoReadOnly
Int Property PollTimerID = 1 AutoReadOnly
Float Property PollSeconds = 30.0 AutoReadOnly
Int Property GNRQuestLocalID = 0x00022486 AutoReadOnly
String Property GNRPlugin = "Fallout34.esm" AutoReadOnly
String Property GNRScriptName = "F3:RadioGNRScript" AutoReadOnly

Int LastSeen = -999
Int InvalidStreak = 0
Bool UnresolvedLogged = False

Function Log(String asText)
	Debug.OpenUserLog(LogName)
	Debug.TraceUser(LogName, asText)
EndFunction

Event OnInit()
	Log("guard v0.1 (monitor only) started")
	RegisterForRemoteEvent(Game.GetPlayer(), "OnPlayerLoadGame")
	StartTimer(PollSeconds, PollTimerID)
EndEvent

Event Actor.OnPlayerLoadGame(Actor akSender)
	Log("save loaded")
	LastSeen = -999
	InvalidStreak = 0
	UnresolvedLogged = False
	CancelTimer(PollTimerID)
	StartTimer(PollSeconds, PollTimerID)
EndEvent

Event OnTimer(Int aiTimerID)
	If aiTimerID != PollTimerID
		Return
	EndIf
	Poll()
	StartTimer(PollSeconds, PollTimerID)
EndEvent

Int Function ReadInt(ScriptObject akObj, String asName)
	Var v = akObj.GetPropertyValue(asName)
	Return v as Int
EndFunction

Function Poll()
	Quest gnrQuest = Game.GetFormFromFile(GNRQuestLocalID, GNRPlugin) as Quest
	If gnrQuest == None
		If !UnresolvedLogged
			Log("GNR quest not found (" + GNRPlugin + " local id " + GNRQuestLocalID + "); doing nothing")
			UnresolvedLogged = True
		EndIf
		Return
	EndIf
	ScriptObject gnr = gnrQuest.CastAs(GNRScriptName)
	If gnr == None
		If !UnresolvedLogged
			Log("quest found but script " + GNRScriptName + " not attached; doing nothing")
			UnresolvedLogged = True
		EndIf
		Return
	EndIf
	UnresolvedLogged = False

	Int played = ReadInt(gnr, "SongsPlayed")
	If played >= 0 && played <= 2
		InvalidStreak = 0
	Else
		InvalidStreak += 1
	EndIf

	If played != LastSeen || InvalidStreak > 0
		String state = "valid"
		If InvalidStreak > 0
			state = "INVALID (consecutive invalid polls: " + InvalidStreak + ")"
		EndIf
		Log("SongsPlayed=" + played + " " + state \
			+ " | SongIntro=" + ReadInt(gnr, "SongIntro") \
			+ " | history=" + ReadInt(gnr, "LastSongPlayed") + "," + ReadInt(gnr, "LastSongPlayed2") \
			+ "," + ReadInt(gnr, "LastSongPlayed3") + "," + ReadInt(gnr, "LastSongPlayed4"))
		LastSeen = played
	EndIf
EndFunction
