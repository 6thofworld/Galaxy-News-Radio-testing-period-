FUCK OFF, I have posted many things in forums, go see that.
BUT STILL
add [Papyrus], bEnableLogging=1, bEnableTrace=1 to Fallout4Custom.ini. If you use MO2’s profile INIs, it goes in the profile’s copy.
If songs don’t play, then send F34_GNR_Guard.0.log