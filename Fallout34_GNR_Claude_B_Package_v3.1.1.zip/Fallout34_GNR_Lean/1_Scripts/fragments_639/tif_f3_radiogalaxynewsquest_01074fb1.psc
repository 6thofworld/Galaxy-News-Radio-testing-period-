;/ Decompiled by Champollion V1.0.6
PEX format v3.9 GameID: 2
Source   : TIF_F3_RadioGalaxyNewsQuest_01074FB1.psc
Modified : 2020-09-13 17:56:40
Compiled : 2020-09-13 17:56:40
User     : f34
Computer : papyrus.py
/;
ScriptName Fragments:TopicInfos:TIF_F3_RadioGalaxyNewsQuest_01074FB1 extends TopicInfo Const hidden
{ Fallout 3 result scripts of INFO 00074FB1 (RadioGalaxyNewsQuest) translated by f34.geck. }

;-- Properties --------------------------------------
F3:RadioGNRScript Property RadioGalaxyNewsQuest Auto Const

;-- Variables ---------------------------------------

;-- Functions ---------------------------------------

Function Fragment_End(ObjectReference akSpeakerRef)
	Actor akSpeaker = akSpeakerRef as Actor
	RadioGalaxyNewsQuest.F34_FragBegin()
	RadioGalaxyNewsQuest.LastSongPlayed4 = RadioGalaxyNewsQuest.LastSongPlayed3
	RadioGalaxyNewsQuest.LastSongPlayed3 = RadioGalaxyNewsQuest.LastSongPlayed2
	RadioGalaxyNewsQuest.LastSongPlayed2 = RadioGalaxyNewsQuest.LastSongPlayed
	RadioGalaxyNewsQuest.LastSongPlayed = 6
	RadioGalaxyNewsQuest.F34_Add_SongsPlayed(1)
	RadioGalaxyNewsQuest.F34_FragEnd()
EndFunction
