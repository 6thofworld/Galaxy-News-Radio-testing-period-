import struct,sys,zlib
from collections import Counter
def parse(path):
    d=open(path,'rb').read()
    out={'masters':[],'records':[]}
    def rec(p):
        t=d[p:p+4].decode('latin1'); size=struct.unpack_from('<I',d,p+4)[0]
        flags,fid=struct.unpack_from('<II',d,p+8)
        return t,size,flags,fid
    def subrecs(data):
        q=0;res=[]
        ext=None
        while q+6<=len(data):
            st=data[q:q+4].decode('latin1'); sz=struct.unpack_from('<H',data,q+4)[0]; q+=6
            if st=='XXXX': ext=struct.unpack_from('<I',data,q)[0]; q+=4; continue
            if ext is not None: sz=ext; ext=None
            res.append((st,data[q:q+sz])); q+=sz
        return res
    def walk(p,end,grp=None):
        while p<end:
            t=d[p:p+4].decode('latin1')
            if t=='GRUP':
                size=struct.unpack_from('<I',d,p+4)[0]
                walk(p+24,p+size,d[p+8:p+12])
                p+=size
            else:
                t,size,flags,fid=rec(p)
                data=d[p+24:p+24+size]
                if flags&0x40000:
                    ds=struct.unpack_from('<I',data,0)[0]; data=zlib.decompress(data[4:])
                out['records'].append((t,fid,flags,subrecs(data)))
                p+=24+size
    walk(0,len(d))
    for t,fid,fl,subs in out['records']:
        if t=='TES4':
            out['masters']=[s[1].split(b'\0')[0].decode('latin1') for s in subs if s[0]=='MAST']
    return out
if __name__=='__main__':
    for path in sys.argv[1:]:
        o=parse(path)
        print('=====',path)
        print('masters:',o['masters'])
        c=Counter(r[0] for r in o['records'])
        print('record counts:',dict(c))
