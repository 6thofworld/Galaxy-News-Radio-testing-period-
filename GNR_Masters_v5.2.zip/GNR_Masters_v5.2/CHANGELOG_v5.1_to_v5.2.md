# Changelog v5.1 → v5.2 (21 Nov 2026)

Base: v5.1 (lean restructure of v5.0). The full v5.0 files were not available when v5.2 was built.

**Added**
- M1 §0A (post-v5.1 update), §5.5 (run table), §6.1 version table with v0.3/v1.1, H8 in §8.2, corrections 22–28 in §9, unknowns 25–30 in §11, status note in §10.
- M2 B13 (guard v0.3 report and v1.1 package, logic, log, timing), B14 (volume plugin, 20 descriptors), B15 (the 18 Nov test save), B8.5 pointer, B1 inventory of 21 Nov files.
- Folder map Part 3 (21 Nov files with sizes/hashes), START_HERE rewrite.
- `Guard_v1.1/` (ESP, PEX, PSC, readme, run log) and `MANIFEST_SHA256.txt`.

**Changed (marked ▲v5.2 in the text)**
- Guard v0.2 is no longer the "working candidate" (M1 §0 item 7, §9 #22); v1.1 is.
- The rule "leave 0, 1, 2 untouched" is provisionally relaxed to "a 2 is left alone up to 30 s" (§9 #23, §10 step 9, §12, B11.1).
- "v0.3 not yet written" is superseded (§9 #24–25).
- §2.2 item 4 and §9 #3 note H8 without reinstating the retracted "2 is stuck" claim.
- §13 test template: guard v1.1, load-order position of radio/volume plugins, "radio played before on this save?".
- §6.3/§6.4 and B7.4: same ESP in v1.1; the v1.1 readme is clean.

**Not changed:** all findings, numbers and labels of v5.0/v5.1 outside the lines above.

**Dropped / not included:** the volume plugin (third-party) and the 15 MB test save (personal, large) are described, not shipped.

**Known weak points of v5.2** (see M1 §0A item 9, §11): no stored-counter reading from any save; no guard-off baseline; v0.3 evidence is report-only; v1.1 was inspected but not compiled or run by the assistant; the save plugin list order in M2-B15 is not the load order.
