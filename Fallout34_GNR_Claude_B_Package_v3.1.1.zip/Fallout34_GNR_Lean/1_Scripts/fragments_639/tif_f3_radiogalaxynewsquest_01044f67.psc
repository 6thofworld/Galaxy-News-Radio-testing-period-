;/ Decompiled by Champollion V1.0.6
PEX format v3.9 GameID: 2
Source   : TIF_F3_RadioGalaxyNewsQuest_01044F67.psc
Modified : 2020-09-13 17:56:40
Compiled : 2020-09-13 17:56:40
User     : f34
Computer : papyrus.py
/;
ScriptName Fragments:TopicInfos:TIF_F3_RadioGalaxyNewsQuest_01044F67 extends TopicInfo Const hidden
{ Fallout 3 result scripts of INFO 00044F67 (RadioGalaxyNewsQuest) translated by f34.geck. }

;-- Properties --------------------------------------
F3:RadioGNRScript Property RadioGalaxyNewsQuest Auto Const

;-- Variables ---------------------------------------

;-- Functions ---------------------------------------

Function Fragment_End(ObjectReference akSpeakerRef)
	Actor akSpeaker = akSpeakerRef as Actor
	RadioGalaxyNewsQuest.F34_FragBegin()
	RadioGalaxyNewsQuest.DashwoodEp = 3
	RadioGalaxyNewsQuest.DashwoodVar = 0
	RadioGalaxyNewsQuest.F34_FragEnd()
EndFunction
