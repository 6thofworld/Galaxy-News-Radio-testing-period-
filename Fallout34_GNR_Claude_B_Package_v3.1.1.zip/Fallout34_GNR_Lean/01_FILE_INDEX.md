# File index — Fallout 34 GNR Claude B package v3.1.1

## Use the package in this order

1. Read `00_START_HERE.md` first. It is the current master memory.
2. Use this index to locate only the files needed for the question at hand.
3. Open `6_Session_Updates/Claude_A_Session_Addendum_2026-11-19.md` for the concise Claude A update; consult the original PDF and its text extraction when a screenshot or exact transcript detail matters.
4. Treat `9_Archive_Superseded/` as historical material, not the current instruction set.

"Evidence class" says what kind of source each file is and how far to trust it. The master and index should be kept synchronised. The external downloadable master and prompt should be byte-identical to their copies inside this ZIP.

| Path | What it is | Size | Evidence class |
|---|---|---:|---|
| `00_START_HERE.md` | Entry point: v3.1.1 master handoff | 50.7 KB | Notes (this is a synthesis; verify against raw files) |
| `CLAUDE_B_START_PROMPT.md` | Paste-ready instructions for starting Claude B | 7.5 KB | Session instructions; read with v3.1.1 master |
| `6_Session_Updates/Claude_A_Session_Addendum_2026-11-19.md` | Concise, structured findings from Claude A's 18–19 Nov session | 11.4 KB | Secondary summary; verify against the original transcript |
| `6_Session_Updates/Package_Review_Notes_v3.1.1.md` | Corrections made during the v3.1.1 pre-flight audit | 1.1 KB | Package review note; no new in-game findings |
| `6_Session_Updates/Package_Review_Notes_v3.1.md` | What changed in the v3.1 documentation/package refresh | 1.0 KB | Historical package change note; superseded by v3.1.1 |
| `6_Session_Updates/Claude_A_Session_2026-11-18_to_19.pdf` | Original 21-page Claude A session transcript with screenshots and embedded file cards | 1.42 MB | Primary session record |
| `6_Session_Updates/Claude_A_Session_2026-11-18_to_19_text.txt` | Searchable text extraction of the Claude A PDF | 52.9 KB | Convenience extraction; images/screenshots remain in PDF |
| `9_Archive_Superseded/GNR_Master_Session_Memory_v3.1.md` | Exact previous v3.1 master, preserved for audit/history | 50.1 KB | Superseded by v3.1.1; preserved unchanged |
| `9_Archive_Superseded/GNR_Master_Session_Memory_v3_previous.md` | Exact previous v3 master, kept for version comparison | 45.8 KB | Superseded by v3.1.1; preserved unchanged |
| `9_Archive_Superseded/GNR_Master_Session_Memory_v2_2026-11-18.md` | Exact previous v2 master, kept for history | 30.7 KB | Superseded; preserved unchanged |
| `1_Scripts/decompile_run/logs/champollion_help.txt` | Decompiler log (near-empty; the crash evidence is in report.txt) | 0.3 KB | Derived tool output |
| `1_Scripts/decompile_run/logs/main_asm.out.txt` | Decompiler log (near-empty; the crash evidence is in report.txt) | 0.0 KB | Derived tool output |
| `1_Scripts/decompile_run/logs/main_champollion.err.txt` | Decompiler log (near-empty; the crash evidence is in report.txt) | 0.0 KB | Derived tool output |
| `1_Scripts/decompile_run/logs/main_champollion.out.txt` | Decompiler log (near-empty; the crash evidence is in report.txt) | 0.0 KB | Derived tool output |
| `1_Scripts/decompile_run/logs/main_comment.out.txt` | Decompiler log (near-empty; the crash evidence is in report.txt) | 0.0 KB | Derived tool output |
| `1_Scripts/decompile_run/psc_main_comment/radiognrscript.psc` | Main script, commented decompile variant | 45.3 KB | Derived: still truncated |
| `1_Scripts/decompile_run/report.txt` | Decompile run report | 3.2 KB | Derived tool output |
| `1_Scripts/decompile_run/strings/radiognrscript.strings.txt` | Identifier strings from main script (275) | 4.9 KB | Derived: names only, not logic |
| `1_Scripts/decompile_run/summary.csv` | Per-fragment decompile summary | 39.3 KB | Derived tool output |
| `1_Scripts/main_script/radiognrscript.pas` | Main script, complete bytecode listing | 58.7 KB | Derived: most complete view of main script |
| `1_Scripts/main_script/radiognrscript.pex` | Main script, compiled | 16.3 KB | Original compiled script |
| `1_Scripts/main_script/radiognrscript.psc` | Main script `F3:RadioGNRScript`, source | 12.4 KB | Derived: TRUNCATED (Champollion crashed) |
| `2_Patches/F34_GNR_TestA.esp` | Test A: transmitter + quest-running only (288 CTDA) | 24.9 KB | Experimental plugin |
| `2_Patches/F34_GNR_TestA0_AllThree_control.esp` | A0 control: all three condition groups (814) | 74.8 KB | Experimental plugin |
| `2_Patches/F34_GNR_TestA1_SongsPlayed.esp` | A1: SongsPlayed checks added (384) | 47.4 KB | Experimental plugin |
| `2_Patches/F34_GNR_TestA2_LastSongPlayed.esp` | A2: LastSongPlayed checks added (670) | 66.1 KB | Experimental plugin |
| `2_Patches/F34_GNR_TestA3_SongIntro.esp` | A3: SongIntro checks added (336) | 44.4 KB | Experimental plugin |
| `2_Patches/F34_GNR_TestB.esp` | Test B: transmitter checks only (192 CTDA) | 23.9 KB | Experimental plugin |
| `2_Patches/GNR No Static_F34.esp` | Overrides F3_RadioGalaxyNewsRef01 | 0.8 KB | Third-party plugin; effect not independently verified |
| `2_Patches/GNR_Everywhere_F34.esp` | Increases range of two GNR transmitters (per description) | 1.0 KB | Third-party plugin; effect not independently verified |
| `3_Exports_F34/F34_RadioScene_RadioGalaxyNews_0A93BF68.txt` | Scene A export (SCEN:0A93BF68) | 288.5 KB | xEdit export; confirm against the plugin record |
| `3_Exports_F34/F34_RadioScene_RadioGalaxyNews_B_0AC0FA30.txt` | Scene B export (SCEN:0AC0FA30) | 288.8 KB | xEdit export |
| `3_Exports_F34/FullInfo_Export.txt` | Full INFO/record export (incl. sound descriptors) | 46.5 KB | xEdit export |
| `3_Exports_F34/NoEditorID_0AED5399.txt` | Focused export of INFO 0AED5399 | 5.8 KB | xEdit export |
| `3_Exports_F34/SongInfoExport(for0AC92CD7).csv` | Song INFO conditions, topic 0AC92CD7 (rows duplicated 2x; 407 unique) | 218.0 KB | xEdit export |
| `3_Exports_F34/SongInfoExport(for0AEAECDA).csv` | Song INFO conditions, topic 0AEAECDA (rows duplicated 2x; 407 unique) | 219.6 KB | xEdit export |
| `3_Exports_F34/ba2_gnr_report.txt` | Archive inventory of GNR scripts/fragments | 0.9 KB | Tool report; counts only |
| `3_Exports_F34/radio_sound_dump.txt` | GNR scene/topic/sound summary | 7.2 KB | Navigation aid; counts depend on the producing tool |
| `4_Reference_Only/Fallout4_comparison/fo4_radio_lookup.txt` | Fallout 4 radio lookup | 3.3 KB | Host-game comparison only |
| `4_Reference_Only/Fallout4_comparison/gistfile1.txt` | Fallout 4 audio category/output-model records | 3.2 KB | Host-game comparison only |
| `4_Reference_Only/New_Vegas_NOT_F34_EVIDENCE/ba2_radio_report.txt` | Radio archive report | 7.2 KB | NEW VEGAS material: do not use as F34 evidence |
| `4_Reference_Only/New_Vegas_NOT_F34_EVIDENCE/ba2_voice_report.txt` | Voice archive report | 9.2 KB | NEW VEGAS material: do not use as F34 evidence |
| `4_Reference_Only/New_Vegas_NOT_F34_EVIDENCE/radio_dump.txt` | Radio dump | 54.8 KB | NEW VEGAS material: do not use as F34 evidence |
| `5_Tools/Decompile-F34.ps1` | PowerShell decompile helper | 22.1 KB | Tool |
| `9_Archive_Superseded/F34 GNR NEW.pdf` | 17 Nov merged investigation notes (PDF) | 201.3 KB | Content merged into master 4B; older counter theory superseded |
| `9_Archive_Superseded/F34 GNR NEW__text.txt` | Text extraction of the PDF above | 11.5 KB | Convenience copy |
| `9_Archive_Superseded/Fallout34_GNR_Session_Memory_2026-11-17.md` | 17 Nov session memory | 12.3 KB | Superseded; same substance as v1 Appendix C |
| `9_Archive_Superseded/Fallout34_GNR_Session_Memory_2026-11-18_Continued.pdf` | 18 Nov session memory (PDF) | 82.5 KB | Content merged into master 4A |
| `9_Archive_Superseded/Fallout34_GNR_Session_Memory_2026-11-18_Continued__text.txt` | Text extraction of the PDF above | 16.8 KB | Convenience copy |
| `9_Archive_Superseded/GNR_Master_Session_Memory_v1.md` | Previous master (v1), includes verbatim READMEs + 17 Nov memory as appendices | 43.8 KB | Superseded by 00_START_HERE.md |
| `9_Archive_Superseded/README_F34_GNR__archive_root.md` | Archive-root README (earlier wording, earlier script interpretation) | 10.1 KB | Superseded; contains known errors (see master Section 5) |
| `9_Archive_Superseded/README_F34_GNR__nested_revised.md` | Nested README (revised; uses complete .pas listing) | 9.3 KB | Superseded; better than root README, still has corrected items |
| `9_Archive_Superseded/README_GNR_Papyrus_Archives.txt` | Expanded guide to the two Papyrus ZIPs | 16.9 KB | Superseded |
| `9_Archive_Superseded/README_Project_Bundle.txt` | Original bundle guide and scope rules | 27.3 KB | Superseded; scope rules carried into master Section 8 |
| `9_Archive_Superseded/tree.txt` | Directory listing of the ORIGINAL (pre-lean) bundle | 71.4 KB | Historical; paths do not match this bundle |
| `1_Scripts/fragments_639/tif_f3_radiogalaxynewsquest_<hex>.psc` (639 files) | Decompiled topic-info fragment scripts. Hex = original FO3 INFO FormID with load-order byte `01`, not the F34 FormID | 598.7 KB total | Derived decompile; spot-check against the INFO's Papyrus Fragments tab in FO4Edit |

## What was removed from the original zip, and why

| Removed | Reason |
|---|---|
| `Papyrus_Source/gnr_psc.zip` | Byte-identical to the extracted fragment folder (verified) |
| `Papyrus_Source/upload_me.zip` | Byte-identical to the extracted `upload_me/upload_me/` folder (verified) |
| Root `radiognrscript.psc`, `.pas` kept once; `psc_main/` and `asm/` copies dropped | Byte-identical duplicates (verified) |
| Nested `upload_me/.../README_F34_GNR.md` kept (renamed) alongside root README | Both kept in `9_Archive_Superseded/` because their wording differs |

Nothing else was deleted. The two PDFs and all READMEs are kept in `9_Archive_Superseded/`; the master now carries their substance.

## Package totals, integrity and limits

The v3.1.1 ZIP contains **696 files** under the single top-level folder `Fallout34_GNR_Lean/`. `MANIFEST_SHA256.txt` contains **695 entries** and covers every other file; it excludes itself. All 695 entries were checked against this package and matched. The external master and starter prompt are byte-identical to `00_START_HERE.md` and `CLAUDE_B_START_PROMPT.md` inside the ZIP.

From inside the `Fallout34_GNR_Lean/` folder, verify on Linux/macOS with `sha256sum -c MANIFEST_SHA256.txt`. The manifest paths are relative to that folder. Keep originals unchanged; work on copies.

The separate `scripts.zip` (9,301 compiled scripts) and the original `Fallout34.esm` / `Fallout34old.esm` binaries are not included. They must be supplied separately if an investigation needs them.


## Not included (do not assume available)

- `scripts.zip`: Claude A's transcript says this separate archive contained 9,301 compiled scripts and was used for a partial QSnap text search (1,786 hits). It is not in this Lean package. Obtain it or regenerate the compiled-script set before continuing the caller analysis.
- The original `Fallout34.esm` / `Fallout34old.esm` binaries: the current user's ESM size was reported in Claude A's transcript, but the master-file binary itself was not added to this package.
