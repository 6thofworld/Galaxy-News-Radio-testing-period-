.info
	.source "RadioGNRScript.psc"
	.modifyTime 1600000000 ;2020-09-13 17:56:40
	.compileTime 1600000000 ;2020-09-13 17:56:40
	.user "f34"
	.computer "papyrus.py"
.endInfo
.userFlagsRef
	.flag hidden 0 ;0x00000001
	.flag conditional 1 ;0x00000002
	.flag default 2 ;0x00000004
	.flag collapsedonref 3 ;0x00000008
	.flag collapsedonbase 4 ;0x00000010
	.flag mandatory 5 ;0x00000020
.endUserFlagsRef
.objectTable
	.object F3:RadioGNRScript Quest
		.userFlags 2 ;conditional 
		.docString "Fallout 3 script RadioGNRScript (SCPT 00057B31, quest) translated by f34.geck. Fix the translator, not this file."
		.autoState 
		.variableTable
			.variable ::DashwoodVar_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::PSAVar_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::PSANum_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::DadStoryVar_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::NewsStoryVar_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::TitleHopeVar_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::TitleScourgeVar_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::TitleParadigmVar_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::ExploitVar_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::SongIntro_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::LastSongPlayed_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::LastSongPlayed2_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::LastSongPlayed3_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::LastSongPlayed4_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::LastNews_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::LastPSA_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::LastGreeting_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::LastGreeting2_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::SongsPlayed_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::ThreeDogDead_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::BadDoesGood_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::GoodDoesBad_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::DashwoodEp_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::CG04Done_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ01Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ02Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ03Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ04Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ05Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ06Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ07Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ08Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ09Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS01Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS02Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS03Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS04Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS05Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS06Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS08Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS09Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS10Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS11Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS12Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS14Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS15Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS16Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS17Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS18Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::ExploitReady_var Int
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MQ11Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::DLC03BS1Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::DLC03BS2Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::DLC03BS3Clear_var Float
				.userFlags 2 ;conditional 
				.initialValue None
			.endVariable
			.variable ::MS08_var Quest
				.userFlags 0 ;none
				.initialValue None
			.endVariable
			.variable ::HarknessRef_var Actor
				.userFlags 0 ;none
				.initialValue None
			.endVariable
			.variable ::GameDaysPassed_var GlobalVariable
				.userFlags 0 ;none
				.initialValue None
			.endVariable
			.variable F34_TickDelay Float
				.userFlags 0 ;none
				.initialValue 5
			.endVariable
			.variable F34_SecondsPassed Float
				.userFlags 0 ;none
				.initialValue None
			.endVariable
			.variable F34_LastTick Float
				.userFlags 0 ;none
				.initialValue None
			.endVariable
			.variable F34_Ticking Bool
				.userFlags 0 ;none
				.initialValue None
			.endVariable
			.variable F34_TickStart Float
				.userFlags 0 ;none
				.initialValue None
			.endVariable
			.variable F34_OwnWorld Bool
				.userFlags 0 ;none
				.initialValue True
			.endVariable
			.variable F34_OwnWorldAt Float
				.userFlags 0 ;none
				.initialValue None
			.endVariable
			.variable F34_FragUntil Float
				.userFlags 0 ;none
				.initialValue None
			.endVariable
		.endVariableTable
		.propertyTable
			.property DashwoodVar Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::DashwoodVar_var
			.endProperty
			.property PSAVar Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::PSAVar_var
			.endProperty
			.property PSANum Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::PSANum_var
			.endProperty
			.property DadStoryVar Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::DadStoryVar_var
			.endProperty
			.property NewsStoryVar Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::NewsStoryVar_var
			.endProperty
			.property TitleHopeVar Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::TitleHopeVar_var
			.endProperty
			.property TitleScourgeVar Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::TitleScourgeVar_var
			.endProperty
			.property TitleParadigmVar Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::TitleParadigmVar_var
			.endProperty
			.property ExploitVar Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::ExploitVar_var
			.endProperty
			.property SongIntro Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::SongIntro_var
			.endProperty
			.property LastSongPlayed Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::LastSongPlayed_var
			.endProperty
			.property LastSongPlayed2 Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::LastSongPlayed2_var
			.endProperty
			.property LastSongPlayed3 Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::LastSongPlayed3_var
			.endProperty
			.property LastSongPlayed4 Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::LastSongPlayed4_var
			.endProperty
			.property LastNews Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::LastNews_var
			.endProperty
			.property LastPSA Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::LastPSA_var
			.endProperty
			.property LastGreeting Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::LastGreeting_var
			.endProperty
			.property LastGreeting2 Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::LastGreeting2_var
			.endProperty
			.property SongsPlayed Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::SongsPlayed_var
			.endProperty
			.property ThreeDogDead Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::ThreeDogDead_var
			.endProperty
			.property BadDoesGood Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::BadDoesGood_var
			.endProperty
			.property GoodDoesBad Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::GoodDoesBad_var
			.endProperty
			.property DashwoodEp Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::DashwoodEp_var
			.endProperty
			.property CG04Done Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::CG04Done_var
			.endProperty
			.property MQ01Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ01Clear_var
			.endProperty
			.property MQ02Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ02Clear_var
			.endProperty
			.property MQ03Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ03Clear_var
			.endProperty
			.property MQ04Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ04Clear_var
			.endProperty
			.property MQ05Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ05Clear_var
			.endProperty
			.property MQ06Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ06Clear_var
			.endProperty
			.property MQ07Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ07Clear_var
			.endProperty
			.property MQ08Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ08Clear_var
			.endProperty
			.property MQ09Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ09Clear_var
			.endProperty
			.property MS01Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS01Clear_var
			.endProperty
			.property MS02Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS02Clear_var
			.endProperty
			.property MS03Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS03Clear_var
			.endProperty
			.property MS04Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS04Clear_var
			.endProperty
			.property MS05Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS05Clear_var
			.endProperty
			.property MS06Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS06Clear_var
			.endProperty
			.property MS08Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS08Clear_var
			.endProperty
			.property MS09Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS09Clear_var
			.endProperty
			.property MS10Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS10Clear_var
			.endProperty
			.property MS11Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS11Clear_var
			.endProperty
			.property MS12Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS12Clear_var
			.endProperty
			.property MS14Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS14Clear_var
			.endProperty
			.property MS15Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS15Clear_var
			.endProperty
			.property MS16Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS16Clear_var
			.endProperty
			.property MS17Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS17Clear_var
			.endProperty
			.property MS18Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS18Clear_var
			.endProperty
			.property ExploitReady Int auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::ExploitReady_var
			.endProperty
			.property MQ11Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MQ11Clear_var
			.endProperty
			.property DLC03BS1Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::DLC03BS1Clear_var
			.endProperty
			.property DLC03BS2Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::DLC03BS2Clear_var
			.endProperty
			.property DLC03BS3Clear Float auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::DLC03BS3Clear_var
			.endProperty
			.property MS08 Quest auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::MS08_var
			.endProperty
			.property HarknessRef Actor auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::HarknessRef_var
			.endProperty
			.property GameDaysPassed GlobalVariable auto
				.userFlags 0 ;none
				.docString ""
				.autovar ::GameDaysPassed_var
			.endProperty
		.endPropertyTable
		.stateTable
			.state 
				.function OnQuestInit
					 ; function type 0
					.userFlags 0 ;none
					.docString ""
					.return None
					.paramTable
					.endParamTable
					.localTable
						.local ::nonevar None
					.endLocalTable
					.code
						; line 89
						callmethod StartTimer self ::nonevar F34_TickDelay 1 ;2 variable args
					.endCode
				.endFunction ;OnQuestInit
				.function OnQuestShutdown
					 ; function type 0
					.userFlags 0 ;none
					.docString ""
					.return None
					.paramTable
					.endParamTable
					.localTable
						.local ::nonevar None
					.endLocalTable
					.code
						; line 93
						callmethod CancelTimer self ::nonevar 1 ;1 variable args
					.endCode
				.endFunction ;OnQuestShutdown
				.function OnTimer
					 ; function type 0
					.userFlags 0 ;none
					.docString ""
					.return None
					.paramTable
						.param aiTimerID Int
					.endParamTable
					.localTable
						.local ::temp0 Bool
						.local ::temp1 Bool
						.local ::nonevar None
						.local F34_FragNow Float
						.local ::temp2 Float
						.local F34_Now Float
					.endLocalTable
					.code
						; line 97
						cmp_eq ::temp0 aiTimerID 1 
						jmpf ::temp0 _label0
						; line 98
						callmethod IsRunning self ::temp0 ;0 variable args
						not ::temp1 ::temp0 
						jmpf ::temp1 _label1
						; line 99
						return None 
						jmp _label1
						; line 101
					_label1:
						callmethod StartTimer self ::nonevar F34_TickDelay 1 ;2 variable args
						; line 102
						callmethod F34_InOwnWorld self ::temp0 ;0 variable args
						not ::temp1 ::temp0 
						jmpf ::temp1 _label2
						; line 103
						return None 
						jmp _label2
						; line 105
					_label2:
						cmp_gt ::temp0 F34_FragUntil 0 
						jmpf ::temp0 _label3
						; line 106
						callstatic Utility GetCurrentRealTime F34_FragNow ;0 variable args
						; line 107
						cmp_lt ::temp1 F34_FragNow F34_FragUntil 
						cast ::temp0 ::temp1 
						jmpf ::temp0 _label4
						fsub ::temp2 F34_FragUntil 5 
						cmp_gt ::temp1 F34_FragNow ::temp2 
						cast ::temp0 ::temp1 
					_label4:
						jmpf ::temp0 _label5
						; line 108
						return None 
						jmp _label5
						; line 110
					_label5:
						assign F34_FragUntil 0 
						jmp _label3
						; line 112
					_label3:
						callstatic Utility GetCurrentRealTime F34_Now ;0 variable args
						; line 113
						cast ::temp1 F34_Ticking 
						jmpf ::temp1 _label6
						fsub ::temp2 F34_Now F34_TickStart 
						cmp_gt ::temp0 ::temp2 -1 
						cast ::temp1 ::temp0 
					_label6:
						cast ::temp0 ::temp1 
						jmpf ::temp0 _label7
						fsub ::temp2 F34_Now F34_TickStart 
						cmp_lt ::temp1 ::temp2 10 
						cast ::temp0 ::temp1 
					_label7:
						jmpf ::temp0 _label8
						; line 114
						return None 
						jmp _label8
						; line 116
					_label8:
						assign F34_Ticking True 
						; line 117
						assign F34_TickStart F34_Now 
						; line 118
						assign F34_SecondsPassed F34_TickDelay 
						; line 119
						cmp_lt ::temp1 F34_TickDelay 0.1 
						cast ::temp0 ::temp1 
						jmpf ::temp0 _label9
						cmp_gt ::temp1 F34_LastTick 0 
						cast ::temp0 ::temp1 
					_label9:
						cast ::temp1 ::temp0 
						jmpf ::temp1 _label10
						cmp_gt ::temp0 F34_Now F34_LastTick 
						cast ::temp1 ::temp0 
					_label10:
						jmpf ::temp1 _label11
						; line 120
						fsub F34_SecondsPassed F34_Now F34_LastTick 
						; line 121
						cmp_gt ::temp0 F34_SecondsPassed 1 
						jmpf ::temp0 _label12
						; line 122
						assign F34_SecondsPassed 1 
						jmp _label12
					_label12:
						jmp _label11
						; line 125
					_label11:
						assign F34_LastTick F34_Now 
						; line 126
						callmethod F34_GameModeTick self ::nonevar ;0 variable args
						; line 127
						assign F34_Ticking False 
						jmp _label0
					_label0
					.endCode
				.endFunction ;OnTimer
				.function F34_Add_DadStoryVar
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.dadstoryvar to <this>.dadstoryvar + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 133
						iadd ::DadStoryVar_var ::DadStoryVar_var afDelta 
						; line 134
						return ::DadStoryVar_var 
					.endCode
				.endFunction ;F34_Add_DadStoryVar
				.function F34_Add_DashwoodVar
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.dashwoodvar to <this>.dashwoodvar + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 139
						iadd ::DashwoodVar_var ::DashwoodVar_var afDelta 
						; line 140
						return ::DashwoodVar_var 
					.endCode
				.endFunction ;F34_Add_DashwoodVar
				.function F34_Add_ExploitVar
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.exploitvar to <this>.exploitvar + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 145
						iadd ::ExploitVar_var ::ExploitVar_var afDelta 
						; line 146
						return ::ExploitVar_var 
					.endCode
				.endFunction ;F34_Add_ExploitVar
				.function F34_Add_NewsStoryVar
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.newsstoryvar to <this>.newsstoryvar + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 151
						iadd ::NewsStoryVar_var ::NewsStoryVar_var afDelta 
						; line 152
						return ::NewsStoryVar_var 
					.endCode
				.endFunction ;F34_Add_NewsStoryVar
				.function F34_Add_PSAVar
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.psavar to <this>.psavar + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 157
						iadd ::PSAVar_var ::PSAVar_var afDelta 
						; line 158
						return ::PSAVar_var 
					.endCode
				.endFunction ;F34_Add_PSAVar
				.function F34_Add_SongsPlayed
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.songsplayed to <this>.songsplayed + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 163
						iadd ::SongsPlayed_var ::SongsPlayed_var afDelta 
						; line 164
						return ::SongsPlayed_var 
					.endCode
				.endFunction ;F34_Add_SongsPlayed
				.function F34_Add_TitleHopeVar
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.titlehopevar to <this>.titlehopevar + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 169
						iadd ::TitleHopeVar_var ::TitleHopeVar_var afDelta 
						; line 170
						return ::TitleHopeVar_var 
					.endCode
				.endFunction ;F34_Add_TitleHopeVar
				.function F34_Add_TitleParadigmVar
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.titleparadigmvar to <this>.titleparadigmvar + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 175
						iadd ::TitleParadigmVar_var ::TitleParadigmVar_var afDelta 
						; line 176
						return ::TitleParadigmVar_var 
					.endCode
				.endFunction ;F34_Add_TitleParadigmVar
				.function F34_Add_TitleScourgeVar
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR3: another script's 'set <this>.titlescourgevar to <this>.titlescourgevar + n' in one locked call (no lost steps)"
					.return Int
					.paramTable
						.param afDelta Int
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 181
						iadd ::TitleScourgeVar_var ::TitleScourgeVar_var afDelta 
						; line 182
						return ::TitleScourgeVar_var 
					.endCode
				.endFunction ;F34_Add_TitleScourgeVar
				.function F34_QSnap
					 ; function type 0
					.userFlags 0 ;none
					.docString "T125: this quest's FO3 variables, read before the quest is started (a first start re-initialises them)"
					.return Var[]
					.paramTable
					.endParamTable
					.localTable
						.local F34_qa Var[]
						.local ::temp3 Var
					.endLocalTable
					.code
						; line 187
						array_create F34_qa 54 
						; line 188
						cast ::temp3 ::DashwoodVar_var 
						array_setelement F34_qa 0 ::temp3 
						; line 189
						cast ::temp3 ::PSAVar_var 
						array_setelement F34_qa 1 ::temp3 
						; line 190
						cast ::temp3 ::PSANum_var 
						array_setelement F34_qa 2 ::temp3 
						; line 191
						cast ::temp3 ::DadStoryVar_var 
						array_setelement F34_qa 3 ::temp3 
						; line 192
						cast ::temp3 ::NewsStoryVar_var 
						array_setelement F34_qa 4 ::temp3 
						; line 193
						cast ::temp3 ::TitleHopeVar_var 
						array_setelement F34_qa 5 ::temp3 
						; line 194
						cast ::temp3 ::TitleScourgeVar_var 
						array_setelement F34_qa 6 ::temp3 
						; line 195
						cast ::temp3 ::TitleParadigmVar_var 
						array_setelement F34_qa 7 ::temp3 
						; line 196
						cast ::temp3 ::ExploitVar_var 
						array_setelement F34_qa 8 ::temp3 
						; line 197
						cast ::temp3 ::SongIntro_var 
						array_setelement F34_qa 9 ::temp3 
						; line 198
						cast ::temp3 ::LastSongPlayed_var 
						array_setelement F34_qa 10 ::temp3 
						; line 199
						cast ::temp3 ::LastSongPlayed2_var 
						array_setelement F34_qa 11 ::temp3 
						; line 200
						cast ::temp3 ::LastSongPlayed3_var 
						array_setelement F34_qa 12 ::temp3 
						; line 201
						cast ::temp3 ::LastSongPlayed4_var 
						array_setelement F34_qa 13 ::temp3 
						; line 202
						cast ::temp3 ::LastNews_var 
						array_setelement F34_qa 14 ::temp3 
						; line 203
						cast ::temp3 ::LastPSA_var 
						array_setelement F34_qa 15 ::temp3 
						; line 204
						cast ::temp3 ::LastGreeting_var 
						array_setelement F34_qa 16 ::temp3 
						; line 205
						cast ::temp3 ::LastGreeting2_var 
						array_setelement F34_qa 17 ::temp3 
						; line 206
						cast ::temp3 ::SongsPlayed_var 
						array_setelement F34_qa 18 ::temp3 
						; line 207
						cast ::temp3 ::ThreeDogDead_var 
						array_setelement F34_qa 19 ::temp3 
						; line 208
						cast ::temp3 ::BadDoesGood_var 
						array_setelement F34_qa 20 ::temp3 
						; line 209
						cast ::temp3 ::GoodDoesBad_var 
						array_setelement F34_qa 21 ::temp3 
						; line 210
						cast ::temp3 ::DashwoodEp_var 
						array_setelement F34_qa 22 ::temp3 
						; line 211
						cast ::temp3 ::CG04Done_var 
						array_setelement F34_qa 23 ::temp3 
						; line 212
						cast ::temp3 ::MQ01Clear_var 
						array_setelement F34_qa 24 ::temp3 
						; line 213
						cast ::temp3 ::MQ02Clear_var 
						array_setelement F34_qa 25 ::temp3 
						; line 214
						cast ::temp3 ::MQ03Clear_var 
						array_setelement F34_qa 26 ::temp3 
						; line 215
						cast ::temp3 ::MQ04Clear_var 
						array_setelement F34_qa 27 ::temp3 
						; line 216
						cast ::temp3 ::MQ05Clear_var 
						array_setelement F34_qa 28 ::temp3 
						; line 217
						cast ::temp3 ::MQ06Clear_var 
						array_setelement F34_qa 29 ::temp3 
						; line 218
						cast ::temp3 ::MQ07Clear_var 
						array_setelement F34_qa 30 ::temp3 
						; line 219
						cast ::temp3 ::MQ08Clear_var 
						array_setelement F34_qa 31 ::temp3 
						; line 220
						cast ::temp3 ::MQ09Clear_var 
						array_setelement F34_qa 32 ::temp3 
						; line 221
						cast ::temp3 ::MS01Clear_var 
						array_setelement F34_qa 33 ::temp3 
						; line 222
						cast ::temp3 ::MS02Clear_var 
						array_setelement F34_qa 34 ::temp3 
						; line 223
						cast ::temp3 ::MS03Clear_var 
						array_setelement F34_qa 35 ::temp3 
						; line 224
						cast ::temp3 ::MS04Clear_var 
						array_setelement F34_qa 36 ::temp3 
						; line 225
						cast ::temp3 ::MS05Clear_var 
						array_setelement F34_qa 37 ::temp3 
						; line 226
						cast ::temp3 ::MS06Clear_var 
						array_setelement F34_qa 38 ::temp3 
						; line 227
						cast ::temp3 ::MS08Clear_var 
						array_setelement F34_qa 39 ::temp3 
						; line 228
						cast ::temp3 ::MS09Clear_var 
						array_setelement F34_qa 40 ::temp3 
						; line 229
						cast ::temp3 ::MS10Clear_var 
						array_setelement F34_qa 41 ::temp3 
						; line 230
						cast ::temp3 ::MS11Clear_var 
						array_setelement F34_qa 42 ::temp3 
						; line 231
						cast ::temp3 ::MS12Clear_var 
						array_setelement F34_qa 43 ::temp3 
						; line 232
						cast ::temp3 ::MS14Clear_var 
						array_setelement F34_qa 44 ::temp3 
						; line 233
						cast ::temp3 ::MS15Clear_var 
						array_setelement F34_qa 45 ::temp3 
						; line 234
						cast ::temp3 ::MS16Clear_var 
						array_setelement F34_qa 46 ::temp3 
						; line 235
						cast ::temp3 ::MS17Clear_var 
						array_setelement F34_qa 47 ::temp3 
						; line 236
						cast ::temp3 ::MS18Clear_var 
						array_setelement F34_qa 48 ::temp3 
						; line 237
						cast ::temp3 ::ExploitReady_var 
						array_setelement F34_qa 49 ::temp3 
						; line 238
						cast ::temp3 ::MQ11Clear_var 
						array_setelement F34_qa 50 ::temp3 
						; line 239
						cast ::temp3 ::DLC03BS1Clear_var 
						array_setelement F34_qa 51 ::temp3 
						; line 240
						cast ::temp3 ::DLC03BS2Clear_var 
						array_setelement F34_qa 52 ::temp3 
						; line 241
						cast ::temp3 ::DLC03BS3Clear_var 
						array_setelement F34_qa 53 ::temp3 
						; line 242
						return F34_qa 
					.endCode
				.endFunction ;F34_QSnap
				.function F34_QRestore
					 ; function type 0
					.userFlags 0 ;none
					.docString "T125: after the quest start: a variable that was set before and is back to 0 gets its value again"
					.return None
					.paramTable
						.param F34_qa Var[]
					.endParamTable
					.localTable
						.local F34_qs0 Int
						.local ::temp4 Var
						.local ::temp5 Bool
						.local ::temp6 Bool
						.local F34_qs1 Int
						.local F34_qs2 Int
						.local F34_qs3 Int
						.local F34_qs4 Int
						.local F34_qs5 Int
						.local F34_qs6 Int
						.local F34_qs7 Int
						.local F34_qs8 Int
						.local F34_qs9 Int
						.local F34_qs10 Int
						.local F34_qs11 Int
						.local F34_qs12 Int
						.local F34_qs13 Int
						.local F34_qs14 Int
						.local F34_qs15 Int
						.local F34_qs16 Int
						.local F34_qs17 Int
						.local F34_qs18 Int
						.local F34_qs19 Int
						.local F34_qs20 Int
						.local F34_qs21 Int
						.local F34_qs22 Int
						.local F34_qs23 Float
						.local F34_qs24 Float
						.local F34_qs25 Float
						.local F34_qs26 Float
						.local F34_qs27 Float
						.local F34_qs28 Float
						.local F34_qs29 Float
						.local F34_qs30 Float
						.local F34_qs31 Float
						.local F34_qs32 Float
						.local F34_qs33 Float
						.local F34_qs34 Float
						.local F34_qs35 Float
						.local F34_qs36 Float
						.local F34_qs37 Float
						.local F34_qs38 Float
						.local F34_qs39 Float
						.local F34_qs40 Float
						.local F34_qs41 Float
						.local F34_qs42 Float
						.local F34_qs43 Float
						.local F34_qs44 Float
						.local F34_qs45 Float
						.local F34_qs46 Float
						.local F34_qs47 Float
						.local F34_qs48 Float
						.local F34_qs49 Int
						.local F34_qs50 Float
						.local F34_qs51 Float
						.local F34_qs52 Float
						.local F34_qs53 Float
					.endLocalTable
					.code
						; line 247
						array_getlement ::temp4 F34_qa 0 
						cast F34_qs0 ::temp4 
						; line 248
						cmp_eq ::temp5 F34_qs0 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label0
						cmp_eq ::temp5 ::DashwoodVar_var 0 
						cast ::temp6 ::temp5 
					_label0:
						jmpf ::temp6 _label1
						; line 249
						assign ::DashwoodVar_var F34_qs0 
						jmp _label1
						; line 251
					_label1:
						array_getlement ::temp4 F34_qa 1 
						cast F34_qs1 ::temp4 
						; line 252
						cmp_eq ::temp5 F34_qs1 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label2
						cmp_eq ::temp5 ::PSAVar_var 0 
						cast ::temp6 ::temp5 
					_label2:
						jmpf ::temp6 _label3
						; line 253
						assign ::PSAVar_var F34_qs1 
						jmp _label3
						; line 255
					_label3:
						array_getlement ::temp4 F34_qa 2 
						cast F34_qs2 ::temp4 
						; line 256
						cmp_eq ::temp5 F34_qs2 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label4
						cmp_eq ::temp5 ::PSANum_var 0 
						cast ::temp6 ::temp5 
					_label4:
						jmpf ::temp6 _label5
						; line 257
						assign ::PSANum_var F34_qs2 
						jmp _label5
						; line 259
					_label5:
						array_getlement ::temp4 F34_qa 3 
						cast F34_qs3 ::temp4 
						; line 260
						cmp_eq ::temp5 F34_qs3 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label6
						cmp_eq ::temp5 ::DadStoryVar_var 0 
						cast ::temp6 ::temp5 
					_label6:
						jmpf ::temp6 _label7
						; line 261
						assign ::DadStoryVar_var F34_qs3 
						jmp _label7
						; line 263
					_label7:
						array_getlement ::temp4 F34_qa 4 
						cast F34_qs4 ::temp4 
						; line 264
						cmp_eq ::temp5 F34_qs4 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label8
						cmp_eq ::temp5 ::NewsStoryVar_var 0 
						cast ::temp6 ::temp5 
					_label8:
						jmpf ::temp6 _label9
						; line 265
						assign ::NewsStoryVar_var F34_qs4 
						jmp _label9
						; line 267
					_label9:
						array_getlement ::temp4 F34_qa 5 
						cast F34_qs5 ::temp4 
						; line 268
						cmp_eq ::temp5 F34_qs5 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label10
						cmp_eq ::temp5 ::TitleHopeVar_var 0 
						cast ::temp6 ::temp5 
					_label10:
						jmpf ::temp6 _label11
						; line 269
						assign ::TitleHopeVar_var F34_qs5 
						jmp _label11
						; line 271
					_label11:
						array_getlement ::temp4 F34_qa 6 
						cast F34_qs6 ::temp4 
						; line 272
						cmp_eq ::temp5 F34_qs6 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label12
						cmp_eq ::temp5 ::TitleScourgeVar_var 0 
						cast ::temp6 ::temp5 
					_label12:
						jmpf ::temp6 _label13
						; line 273
						assign ::TitleScourgeVar_var F34_qs6 
						jmp _label13
						; line 275
					_label13:
						array_getlement ::temp4 F34_qa 7 
						cast F34_qs7 ::temp4 
						; line 276
						cmp_eq ::temp5 F34_qs7 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label14
						cmp_eq ::temp5 ::TitleParadigmVar_var 0 
						cast ::temp6 ::temp5 
					_label14:
						jmpf ::temp6 _label15
						; line 277
						assign ::TitleParadigmVar_var F34_qs7 
						jmp _label15
						; line 279
					_label15:
						array_getlement ::temp4 F34_qa 8 
						cast F34_qs8 ::temp4 
						; line 280
						cmp_eq ::temp5 F34_qs8 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label16
						cmp_eq ::temp5 ::ExploitVar_var 0 
						cast ::temp6 ::temp5 
					_label16:
						jmpf ::temp6 _label17
						; line 281
						assign ::ExploitVar_var F34_qs8 
						jmp _label17
						; line 283
					_label17:
						array_getlement ::temp4 F34_qa 9 
						cast F34_qs9 ::temp4 
						; line 284
						cmp_eq ::temp5 F34_qs9 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label18
						cmp_eq ::temp5 ::SongIntro_var 0 
						cast ::temp6 ::temp5 
					_label18:
						jmpf ::temp6 _label19
						; line 285
						assign ::SongIntro_var F34_qs9 
						jmp _label19
						; line 287
					_label19:
						array_getlement ::temp4 F34_qa 10 
						cast F34_qs10 ::temp4 
						; line 288
						cmp_eq ::temp5 F34_qs10 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label20
						cmp_eq ::temp5 ::LastSongPlayed_var 0 
						cast ::temp6 ::temp5 
					_label20:
						jmpf ::temp6 _label21
						; line 289
						assign ::LastSongPlayed_var F34_qs10 
						jmp _label21
						; line 291
					_label21:
						array_getlement ::temp4 F34_qa 11 
						cast F34_qs11 ::temp4 
						; line 292
						cmp_eq ::temp5 F34_qs11 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label22
						cmp_eq ::temp5 ::LastSongPlayed2_var 0 
						cast ::temp6 ::temp5 
					_label22:
						jmpf ::temp6 _label23
						; line 293
						assign ::LastSongPlayed2_var F34_qs11 
						jmp _label23
						; line 295
					_label23:
						array_getlement ::temp4 F34_qa 12 
						cast F34_qs12 ::temp4 
						; line 296
						cmp_eq ::temp5 F34_qs12 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label24
						cmp_eq ::temp5 ::LastSongPlayed3_var 0 
						cast ::temp6 ::temp5 
					_label24:
						jmpf ::temp6 _label25
						; line 297
						assign ::LastSongPlayed3_var F34_qs12 
						jmp _label25
						; line 299
					_label25:
						array_getlement ::temp4 F34_qa 13 
						cast F34_qs13 ::temp4 
						; line 300
						cmp_eq ::temp5 F34_qs13 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label26
						cmp_eq ::temp5 ::LastSongPlayed4_var 0 
						cast ::temp6 ::temp5 
					_label26:
						jmpf ::temp6 _label27
						; line 301
						assign ::LastSongPlayed4_var F34_qs13 
						jmp _label27
						; line 303
					_label27:
						array_getlement ::temp4 F34_qa 14 
						cast F34_qs14 ::temp4 
						; line 304
						cmp_eq ::temp5 F34_qs14 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label28
						cmp_eq ::temp5 ::LastNews_var 0 
						cast ::temp6 ::temp5 
					_label28:
						jmpf ::temp6 _label29
						; line 305
						assign ::LastNews_var F34_qs14 
						jmp _label29
						; line 307
					_label29:
						array_getlement ::temp4 F34_qa 15 
						cast F34_qs15 ::temp4 
						; line 308
						cmp_eq ::temp5 F34_qs15 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label30
						cmp_eq ::temp5 ::LastPSA_var 0 
						cast ::temp6 ::temp5 
					_label30:
						jmpf ::temp6 _label31
						; line 309
						assign ::LastPSA_var F34_qs15 
						jmp _label31
						; line 311
					_label31:
						array_getlement ::temp4 F34_qa 16 
						cast F34_qs16 ::temp4 
						; line 312
						cmp_eq ::temp5 F34_qs16 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label32
						cmp_eq ::temp5 ::LastGreeting_var 0 
						cast ::temp6 ::temp5 
					_label32:
						jmpf ::temp6 _label33
						; line 313
						assign ::LastGreeting_var F34_qs16 
						jmp _label33
						; line 315
					_label33:
						array_getlement ::temp4 F34_qa 17 
						cast F34_qs17 ::temp4 
						; line 316
						cmp_eq ::temp5 F34_qs17 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label34
						cmp_eq ::temp5 ::LastGreeting2_var 0 
						cast ::temp6 ::temp5 
					_label34:
						jmpf ::temp6 _label35
						; line 317
						assign ::LastGreeting2_var F34_qs17 
						jmp _label35
						; line 319
					_label35:
						array_getlement ::temp4 F34_qa 18 
						cast F34_qs18 ::temp4 
						; line 320
						cmp_eq ::temp5 F34_qs18 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label36
						cmp_eq ::temp5 ::SongsPlayed_var 0 
						cast ::temp6 ::temp5 
					_label36:
						jmpf ::temp6 _label37
						; line 321
						assign ::SongsPlayed_var F34_qs18 
						jmp _label37
						; line 323
					_label37:
						array_getlement ::temp4 F34_qa 19 
						cast F34_qs19 ::temp4 
						; line 324
						cmp_eq ::temp5 F34_qs19 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label38
						cmp_eq ::temp5 ::ThreeDogDead_var 0 
						cast ::temp6 ::temp5 
					_label38:
						jmpf ::temp6 _label39
						; line 325
						assign ::ThreeDogDead_var F34_qs19 
						jmp _label39
						; line 327
					_label39:
						array_getlement ::temp4 F34_qa 20 
						cast F34_qs20 ::temp4 
						; line 328
						cmp_eq ::temp5 F34_qs20 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label40
						cmp_eq ::temp5 ::BadDoesGood_var 0 
						cast ::temp6 ::temp5 
					_label40:
						jmpf ::temp6 _label41
						; line 329
						assign ::BadDoesGood_var F34_qs20 
						jmp _label41
						; line 331
					_label41:
						array_getlement ::temp4 F34_qa 21 
						cast F34_qs21 ::temp4 
						; line 332
						cmp_eq ::temp5 F34_qs21 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label42
						cmp_eq ::temp5 ::GoodDoesBad_var 0 
						cast ::temp6 ::temp5 
					_label42:
						jmpf ::temp6 _label43
						; line 333
						assign ::GoodDoesBad_var F34_qs21 
						jmp _label43
						; line 335
					_label43:
						array_getlement ::temp4 F34_qa 22 
						cast F34_qs22 ::temp4 
						; line 336
						cmp_eq ::temp5 F34_qs22 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label44
						cmp_eq ::temp5 ::DashwoodEp_var 0 
						cast ::temp6 ::temp5 
					_label44:
						jmpf ::temp6 _label45
						; line 337
						assign ::DashwoodEp_var F34_qs22 
						jmp _label45
						; line 339
					_label45:
						array_getlement ::temp4 F34_qa 23 
						cast F34_qs23 ::temp4 
						; line 340
						cmp_eq ::temp5 F34_qs23 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label46
						cmp_eq ::temp5 ::CG04Done_var 0 
						cast ::temp6 ::temp5 
					_label46:
						jmpf ::temp6 _label47
						; line 341
						assign ::CG04Done_var F34_qs23 
						jmp _label47
						; line 343
					_label47:
						array_getlement ::temp4 F34_qa 24 
						cast F34_qs24 ::temp4 
						; line 344
						cmp_eq ::temp5 F34_qs24 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label48
						cmp_eq ::temp5 ::MQ01Clear_var 0 
						cast ::temp6 ::temp5 
					_label48:
						jmpf ::temp6 _label49
						; line 345
						assign ::MQ01Clear_var F34_qs24 
						jmp _label49
						; line 347
					_label49:
						array_getlement ::temp4 F34_qa 25 
						cast F34_qs25 ::temp4 
						; line 348
						cmp_eq ::temp5 F34_qs25 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label50
						cmp_eq ::temp5 ::MQ02Clear_var 0 
						cast ::temp6 ::temp5 
					_label50:
						jmpf ::temp6 _label51
						; line 349
						assign ::MQ02Clear_var F34_qs25 
						jmp _label51
						; line 351
					_label51:
						array_getlement ::temp4 F34_qa 26 
						cast F34_qs26 ::temp4 
						; line 352
						cmp_eq ::temp5 F34_qs26 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label52
						cmp_eq ::temp5 ::MQ03Clear_var 0 
						cast ::temp6 ::temp5 
					_label52:
						jmpf ::temp6 _label53
						; line 353
						assign ::MQ03Clear_var F34_qs26 
						jmp _label53
						; line 355
					_label53:
						array_getlement ::temp4 F34_qa 27 
						cast F34_qs27 ::temp4 
						; line 356
						cmp_eq ::temp5 F34_qs27 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label54
						cmp_eq ::temp5 ::MQ04Clear_var 0 
						cast ::temp6 ::temp5 
					_label54:
						jmpf ::temp6 _label55
						; line 357
						assign ::MQ04Clear_var F34_qs27 
						jmp _label55
						; line 359
					_label55:
						array_getlement ::temp4 F34_qa 28 
						cast F34_qs28 ::temp4 
						; line 360
						cmp_eq ::temp5 F34_qs28 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label56
						cmp_eq ::temp5 ::MQ05Clear_var 0 
						cast ::temp6 ::temp5 
					_label56:
						jmpf ::temp6 _label57
						; line 361
						assign ::MQ05Clear_var F34_qs28 
						jmp _label57
						; line 363
					_label57:
						array_getlement ::temp4 F34_qa 29 
						cast F34_qs29 ::temp4 
						; line 364
						cmp_eq ::temp5 F34_qs29 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label58
						cmp_eq ::temp5 ::MQ06Clear_var 0 
						cast ::temp6 ::temp5 
					_label58:
						jmpf ::temp6 _label59
						; line 365
						assign ::MQ06Clear_var F34_qs29 
						jmp _label59
						; line 367
					_label59:
						array_getlement ::temp4 F34_qa 30 
						cast F34_qs30 ::temp4 
						; line 368
						cmp_eq ::temp5 F34_qs30 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label60
						cmp_eq ::temp5 ::MQ07Clear_var 0 
						cast ::temp6 ::temp5 
					_label60:
						jmpf ::temp6 _label61
						; line 369
						assign ::MQ07Clear_var F34_qs30 
						jmp _label61
						; line 371
					_label61:
						array_getlement ::temp4 F34_qa 31 
						cast F34_qs31 ::temp4 
						; line 372
						cmp_eq ::temp5 F34_qs31 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label62
						cmp_eq ::temp5 ::MQ08Clear_var 0 
						cast ::temp6 ::temp5 
					_label62:
						jmpf ::temp6 _label63
						; line 373
						assign ::MQ08Clear_var F34_qs31 
						jmp _label63
						; line 375
					_label63:
						array_getlement ::temp4 F34_qa 32 
						cast F34_qs32 ::temp4 
						; line 376
						cmp_eq ::temp5 F34_qs32 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label64
						cmp_eq ::temp5 ::MQ09Clear_var 0 
						cast ::temp6 ::temp5 
					_label64:
						jmpf ::temp6 _label65
						; line 377
						assign ::MQ09Clear_var F34_qs32 
						jmp _label65
						; line 379
					_label65:
						array_getlement ::temp4 F34_qa 33 
						cast F34_qs33 ::temp4 
						; line 380
						cmp_eq ::temp5 F34_qs33 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label66
						cmp_eq ::temp5 ::MS01Clear_var 0 
						cast ::temp6 ::temp5 
					_label66:
						jmpf ::temp6 _label67
						; line 381
						assign ::MS01Clear_var F34_qs33 
						jmp _label67
						; line 383
					_label67:
						array_getlement ::temp4 F34_qa 34 
						cast F34_qs34 ::temp4 
						; line 384
						cmp_eq ::temp5 F34_qs34 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label68
						cmp_eq ::temp5 ::MS02Clear_var 0 
						cast ::temp6 ::temp5 
					_label68:
						jmpf ::temp6 _label69
						; line 385
						assign ::MS02Clear_var F34_qs34 
						jmp _label69
						; line 387
					_label69:
						array_getlement ::temp4 F34_qa 35 
						cast F34_qs35 ::temp4 
						; line 388
						cmp_eq ::temp5 F34_qs35 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label70
						cmp_eq ::temp5 ::MS03Clear_var 0 
						cast ::temp6 ::temp5 
					_label70:
						jmpf ::temp6 _label71
						; line 389
						assign ::MS03Clear_var F34_qs35 
						jmp _label71
						; line 391
					_label71:
						array_getlement ::temp4 F34_qa 36 
						cast F34_qs36 ::temp4 
						; line 392
						cmp_eq ::temp5 F34_qs36 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label72
						cmp_eq ::temp5 ::MS04Clear_var 0 
						cast ::temp6 ::temp5 
					_label72:
						jmpf ::temp6 _label73
						; line 393
						assign ::MS04Clear_var F34_qs36 
						jmp _label73
						; line 395
					_label73:
						array_getlement ::temp4 F34_qa 37 
						cast F34_qs37 ::temp4 
						; line 396
						cmp_eq ::temp5 F34_qs37 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label74
						cmp_eq ::temp5 ::MS05Clear_var 0 
						cast ::temp6 ::temp5 
					_label74:
						jmpf ::temp6 _label75
						; line 397
						assign ::MS05Clear_var F34_qs37 
						jmp _label75
						; line 399
					_label75:
						array_getlement ::temp4 F34_qa 38 
						cast F34_qs38 ::temp4 
						; line 400
						cmp_eq ::temp5 F34_qs38 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label76
						cmp_eq ::temp5 ::MS06Clear_var 0 
						cast ::temp6 ::temp5 
					_label76:
						jmpf ::temp6 _label77
						; line 401
						assign ::MS06Clear_var F34_qs38 
						jmp _label77
						; line 403
					_label77:
						array_getlement ::temp4 F34_qa 39 
						cast F34_qs39 ::temp4 
						; line 404
						cmp_eq ::temp5 F34_qs39 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label78
						cmp_eq ::temp5 ::MS08Clear_var 0 
						cast ::temp6 ::temp5 
					_label78:
						jmpf ::temp6 _label79
						; line 405
						assign ::MS08Clear_var F34_qs39 
						jmp _label79
						; line 407
					_label79:
						array_getlement ::temp4 F34_qa 40 
						cast F34_qs40 ::temp4 
						; line 408
						cmp_eq ::temp5 F34_qs40 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label80
						cmp_eq ::temp5 ::MS09Clear_var 0 
						cast ::temp6 ::temp5 
					_label80:
						jmpf ::temp6 _label81
						; line 409
						assign ::MS09Clear_var F34_qs40 
						jmp _label81
						; line 411
					_label81:
						array_getlement ::temp4 F34_qa 41 
						cast F34_qs41 ::temp4 
						; line 412
						cmp_eq ::temp5 F34_qs41 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label82
						cmp_eq ::temp5 ::MS10Clear_var 0 
						cast ::temp6 ::temp5 
					_label82:
						jmpf ::temp6 _label83
						; line 413
						assign ::MS10Clear_var F34_qs41 
						jmp _label83
						; line 415
					_label83:
						array_getlement ::temp4 F34_qa 42 
						cast F34_qs42 ::temp4 
						; line 416
						cmp_eq ::temp5 F34_qs42 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label84
						cmp_eq ::temp5 ::MS11Clear_var 0 
						cast ::temp6 ::temp5 
					_label84:
						jmpf ::temp6 _label85
						; line 417
						assign ::MS11Clear_var F34_qs42 
						jmp _label85
						; line 419
					_label85:
						array_getlement ::temp4 F34_qa 43 
						cast F34_qs43 ::temp4 
						; line 420
						cmp_eq ::temp5 F34_qs43 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label86
						cmp_eq ::temp5 ::MS12Clear_var 0 
						cast ::temp6 ::temp5 
					_label86:
						jmpf ::temp6 _label87
						; line 421
						assign ::MS12Clear_var F34_qs43 
						jmp _label87
						; line 423
					_label87:
						array_getlement ::temp4 F34_qa 44 
						cast F34_qs44 ::temp4 
						; line 424
						cmp_eq ::temp5 F34_qs44 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label88
						cmp_eq ::temp5 ::MS14Clear_var 0 
						cast ::temp6 ::temp5 
					_label88:
						jmpf ::temp6 _label89
						; line 425
						assign ::MS14Clear_var F34_qs44 
						jmp _label89
						; line 427
					_label89:
						array_getlement ::temp4 F34_qa 45 
						cast F34_qs45 ::temp4 
						; line 428
						cmp_eq ::temp5 F34_qs45 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label90
						cmp_eq ::temp5 ::MS15Clear_var 0 
						cast ::temp6 ::temp5 
					_label90:
						jmpf ::temp6 _label91
						; line 429
						assign ::MS15Clear_var F34_qs45 
						jmp _label91
						; line 431
					_label91:
						array_getlement ::temp4 F34_qa 46 
						cast F34_qs46 ::temp4 
						; line 432
						cmp_eq ::temp5 F34_qs46 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label92
						cmp_eq ::temp5 ::MS16Clear_var 0 
						cast ::temp6 ::temp5 
					_label92:
						jmpf ::temp6 _label93
						; line 433
						assign ::MS16Clear_var F34_qs46 
						jmp _label93
						; line 435
					_label93:
						array_getlement ::temp4 F34_qa 47 
						cast F34_qs47 ::temp4 
						; line 436
						cmp_eq ::temp5 F34_qs47 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label94
						cmp_eq ::temp5 ::MS17Clear_var 0 
						cast ::temp6 ::temp5 
					_label94:
						jmpf ::temp6 _label95
						; line 437
						assign ::MS17Clear_var F34_qs47 
						jmp _label95
						; line 439
					_label95:
						array_getlement ::temp4 F34_qa 48 
						cast F34_qs48 ::temp4 
						; line 440
						cmp_eq ::temp5 F34_qs48 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label96
						cmp_eq ::temp5 ::MS18Clear_var 0 
						cast ::temp6 ::temp5 
					_label96:
						jmpf ::temp6 _label97
						; line 441
						assign ::MS18Clear_var F34_qs48 
						jmp _label97
						; line 443
					_label97:
						array_getlement ::temp4 F34_qa 49 
						cast F34_qs49 ::temp4 
						; line 444
						cmp_eq ::temp5 F34_qs49 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label98
						cmp_eq ::temp5 ::ExploitReady_var 0 
						cast ::temp6 ::temp5 
					_label98:
						jmpf ::temp6 _label99
						; line 445
						assign ::ExploitReady_var F34_qs49 
						jmp _label99
						; line 447
					_label99:
						array_getlement ::temp4 F34_qa 50 
						cast F34_qs50 ::temp4 
						; line 448
						cmp_eq ::temp5 F34_qs50 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label100
						cmp_eq ::temp5 ::MQ11Clear_var 0 
						cast ::temp6 ::temp5 
					_label100:
						jmpf ::temp6 _label101
						; line 449
						assign ::MQ11Clear_var F34_qs50 
						jmp _label101
						; line 451
					_label101:
						array_getlement ::temp4 F34_qa 51 
						cast F34_qs51 ::temp4 
						; line 452
						cmp_eq ::temp5 F34_qs51 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label102
						cmp_eq ::temp5 ::DLC03BS1Clear_var 0 
						cast ::temp6 ::temp5 
					_label102:
						jmpf ::temp6 _label103
						; line 453
						assign ::DLC03BS1Clear_var F34_qs51 
						jmp _label103
						; line 455
					_label103:
						array_getlement ::temp4 F34_qa 52 
						cast F34_qs52 ::temp4 
						; line 456
						cmp_eq ::temp5 F34_qs52 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label104
						cmp_eq ::temp5 ::DLC03BS2Clear_var 0 
						cast ::temp6 ::temp5 
					_label104:
						jmpf ::temp6 _label105
						; line 457
						assign ::DLC03BS2Clear_var F34_qs52 
						jmp _label105
						; line 459
					_label105:
						array_getlement ::temp4 F34_qa 53 
						cast F34_qs53 ::temp4 
						; line 460
						cmp_eq ::temp5 F34_qs53 0 
						not ::temp5 ::temp5 
						cast ::temp6 ::temp5 
						jmpf ::temp6 _label106
						cmp_eq ::temp5 ::DLC03BS3Clear_var 0 
						cast ::temp6 ::temp5 
					_label106:
						jmpf ::temp6 _label107
						; line 461
						assign ::DLC03BS3Clear_var F34_qs53 
						jmp _label107
					_label107
					.endCode
				.endFunction ;F34_QRestore
				.function F34_InOwnWorld
					 ; function type 0
					.userFlags 0 ;none
					.docString "T120: the player's worldspace (outside) / cell (inside) comes from the plugin of this quest; re-read at most
    once a second. Unknown location = yes."
					.return Bool
					.paramTable
					.endParamTable
					.localTable
						.local t Float
						.local ::temp7 Bool
						.local ::temp8 Bool
						.local ::temp9 Float
						.local p Actor
						.local where Form
						.local ::temp10 WorldSpace
						.local ::temp11 Cell
						.local ::temp12 Int
						.local ::temp13 Int
						.local ::temp14 Int
					.endLocalTable
					.code
						; line 468
						callstatic Utility GetCurrentRealTime t ;0 variable args
						; line 469
						comp_gte ::temp7 t F34_OwnWorldAt 
						cast ::temp8 ::temp7 
						jmpf ::temp8 _label0
						fsub ::temp9 t F34_OwnWorldAt 
						cmp_lt ::temp7 ::temp9 1 
						cast ::temp8 ::temp7 
					_label0:
						jmpf ::temp8 _label1
						; line 470
						return F34_OwnWorld 
						jmp _label1
						; line 472
					_label1:
						assign F34_OwnWorldAt t 
						; line 473
						callstatic Game GetPlayer p ;0 variable args
						; line 474
						callmethod GetWorldSpace p ::temp10 ;0 variable args
						cast where ::temp10 
						; line 475
						not ::temp7 where 
						jmpf ::temp7 _label2
						; line 476
						callmethod GetParentCell p ::temp11 ;0 variable args
						cast where ::temp11 
						jmp _label2
						; line 478
					_label2:
						assign F34_OwnWorld True 
						; line 479
						jmpf where _label3
						; line 480
						callmethod GetFormID where ::temp12 ;0 variable args
						idiv ::temp13 ::temp12 16777216 
						callmethod GetFormID self ::temp12 ;0 variable args
						idiv ::temp14 ::temp12 16777216 
						cmp_eq F34_OwnWorld ::temp13 ::temp14 
						jmp _label3
						; line 482
					_label3:
						return F34_OwnWorld 
					.endCode
				.endFunction ;F34_InOwnWorld
				.function F34_GameModeTick
					 ; function type 0
					.userFlags 0 ;none
					.docString "FO3 GameMode / ScriptEffectUpdate blocks, one frame"
					.return None
					.paramTable
					.endParamTable
					.localTable
						.local ::temp15 Bool
						.local ::temp16 Bool
						.local ::temp17 Float
					.endLocalTable
					.code
						; line 489
						callmethod GetStageDone ::MS08_var ::temp15 200 ;1 variable args
						jmpf ::temp15 _label0
						; line 491
						cast ::temp15 ::HarknessRef_var 
						jmpf ::temp15 _label1
						callmethod IsDisabled ::HarknessRef_var ::temp16 ;0 variable args
						cast ::temp15 ::temp16 
					_label1:
						jmpf ::temp15 _label2
						; line 493
						cmp_eq ::temp16 ::MS08Clear_var 0 
						jmpf ::temp16 _label3
						; line 495
						callmethod GetValue ::GameDaysPassed_var ::temp17 ;0 variable args
						fadd ::MS08Clear_var ::temp17 1 
						; line 497
						assign ::ExploitReady_var 1 
						jmp _label3
					_label3:
						jmp _label2
					_label2:
						jmp _label0
					_label0
					.endCode
				.endFunction ;F34_GameModeTick
				.function F34_FragBegin
					 ; function type 0
					.userFlags 0 ;none
					.docString "GNR4: a stage / dialogue result fragment starts setting this quest's variables: no GameMode meanwhile"
					.return None
					.paramTable
					.endParamTable
					.localTable
						.local ::temp18 Float
					.endLocalTable
					.code
						; line 505
						callstatic Utility GetCurrentRealTime ::temp18 ;0 variable args
						fadd F34_FragUntil ::temp18 2 
					.endCode
				.endFunction ;F34_FragBegin
				.function F34_FragEnd
					 ; function type 0
					.userFlags 0 ;none
					.docString ""
					.return None
					.paramTable
					.endParamTable
					.localTable
					.endLocalTable
					.code
						; line 509
						assign F34_FragUntil 0 
					.endCode
				.endFunction ;F34_FragEnd
				.function F34_SetQuestDelay
					 ; function type 0
					.userFlags 0 ;none
					.docString "FO3 SetQuestDelay (0 = the default delay)"
					.return None
					.paramTable
						.param afDelay Float
					.endParamTable
					.localTable
						.local ::temp19 Bool
						.local ::nonevar None
					.endLocalTable
					.code
						; line 514
						cmp_lte ::temp19 afDelay 0 
						jmpf ::temp19 _label0
						; line 515
						assign afDelay 5 
						jmp _label0
						; line 517
					_label0:
						assign F34_TickDelay afDelay 
						; line 518
						callmethod IsRunning self ::temp19 ;0 variable args
						jmpf ::temp19 _label1
						; line 519
						callmethod StartTimer self ::nonevar afDelay 1 ;2 variable args
						jmp _label1
					_label1
					.endCode
				.endFunction ;F34_SetQuestDelay
			.endState
		.endStateTable
	.endObject
.endObjectTable
