# GNR (Fallout 34 – Galaxy News Radio) — START HERE · v5.2 · 21 Nov 2026

**Purpose.** Entry point for any new session. Load this file, then `GNR_MASTER_1_Story_and_Status_v5.2.md` (~14k tokens; read §0A first). Load `GNR_MASTER_2_Evidence_v5.2.md` (~11k tokens) only when a question needs tables, plugin/log/script detail or file hashes. Load `GNR_01_Folder_Map_v5.2.md` (~3k tokens) when you need to know **which file exists where** so you can ask the user for that specific record, log or script. **Never load or request the raw `tree.txt` (13 MB, 163k lines)**; the map replaces it. Do not ask the user for every raw file at once. The folder `Guard_v1.1/` holds the current guard candidate (ESP, PEX, PSC, readme) and the 21 Nov run log; `CHANGELOG_v5.1_to_v5.2.md` lists what changed.

## Chronology of the master documents (newest last)
| Version | Date | What it was |
|---|---|---|
| v1 / v2 | ≤17–18 Nov | Early session memories, README, ruled-out table |
| v3.1.1 | 19 Nov | Claude B consolidation |
| v4.0 / v4.1 | 19 Nov | Claude C (guard, logs, dev fix); v4.1 = Claude C part + v3.1.1 verbatim |
| **v5.0** | **19 Nov** | **Last full chronological master pair** (`GNR_MASTER_1_Story_and_Status_v5.0` + `GNR_MASTER_2_Evidence_and_Appendices_v5.0`). Kept in full in the archive zip (outside the project; not available on 21 Nov). |
| v5.1 | 20 Nov | Lean restructure of v5.0; no finding changed. Cut/moved: 172-row fragment table, 52-reset listing, guard v0.2 source, full old-save log, v5.0 evidence ledger. All regenerable from files named in M2-B1. |
| **v5.2 (this)** | **21 Nov** | **v5.1 + post-v5.1 events**: guard v0.3 report, guard v1.1 (inspected + run log), volume plugin, the 18 Nov test save. Changed statements are marked "▲v5.2" and listed in M1 §9 items 22–28. v5.2 was built from v5.1 (the full v5.0 files were not available). |

Anything newer than v5.2 must be logged below as a **post-v5.2 entry**; never silently edit v5.0-derived text.

## Where things stand (details: M1 §0A, §0)
1. Symptom: Three Dog talks, no songs. Song INFOs are silent dialogue records gated on quest counter `SongsPlayed`; if none passes, the scene moves to the next talk phase.
2. Valid counter cycle is 0 → 1 → 2 → reset to 0. All 344 counter-changing INFOs accept only 0/1/2 (re-checked). Reliable 01 = Save 11 reportedly holds `SongsPlayed = 5` → blocks every song path (H0: strong lead, not measured live).
3. Cause of an out-of-cycle value is UNKNOWN. Tester logs (guard v0.2 running) show runaway counter writes (1596 at first poll; 67 on a brand-new save) — never tested without the guard. The 21 Nov v1.1 run showed none.
4. Project goal: a safe, general self-recovery (separate ESP + Papyrus helper), not chasing why Save 11 has 5.
5. ▲v5.2 **Current candidate: guard v1.1** (`Guard_v1.1/`): polls 3 s; never touches 0/1; sets <0 or >2 to 0; a **2 unchanged for 30 s is treated as stuck → 0**; backs off after 10 recoveries; same ESP as before, new PEX/PSC. User reports it works (3 songs, 21 Nov; log shows 2 recoveries, no runaway). **Not validated:** no guard-off baseline, no song names, history/`SongIntro` not logged.
6. ▲v5.2 **New hypothesis H8:** a counter stuck at 2 stalls songs until a reset offer (N5/N66) arrives; v0.3 (monitor-only, counter 2) gave no songs, v0.2/v1.1 (write 0) did. One report + one log; inference only.
7. Guard v0.2 (resets at ≥ 2 at once) is wrong by design — **do not distribute**.
8. ▲v5.2 **The user stopped testing on 21 Nov (03:47 IST).** The controlled runs in M1 §10 step 3 are not done. Open before any final repair: read the stored counter from the saves, a guard-off baseline, history logging, song names.

## Post-v5.0 entries (from the user, REPORTED)
- 19 Nov: goal = general self-recovery (separate ESP + compiled Papyrus helper). Recovery value: use **0 for now** ("we'll have to see which works"). *Tension:* M1 §10 step 9 warns against blindly writing 0 (normal resets also update history); the user's instruction is provisional, to be validated by the test matrix.
- The game is the original (pre-next-gen) Fallout 4; the user asked which Papyrus compiler is best for it (no answer recorded in v5.0; the guard was compiled with Papyrus Compiler 2.8.0.4 per M1 §6.1).
- 20 Nov: lean restructure requested so new sessions load within context limits; the 13 MB folder listing (`tree.txt`, UTF-16) was condensed into the folder map (a locator, not evidence).
- 20 Nov: guard v0.3 (monitor-only) built; on a virgin save (~5 min ×2) no songs; v0.2 gave songs; disabling the guard ESP did not help; v0.3 log showed counter 2 / `SongIntro` 1 / history `8,2,0,0` throughout (~170 polls). Files not supplied to the 21 Nov session.
- 21 Nov: guard v1.1 delivered ("works unlike v0.3"); run log 03:19–03:33; "radio worked pretty damn good"; **3 songs** on a "half virgin" save (only `GNR_Everywhere`, `GNR No Static` and a GNR volume-up plugin active from the start); volume plugin = `GNR_SongVolumehigh_volume.esp` (user: must load very early); test save = `Save1_…_20261118215740` (`New_save`, 18 Nov). Then: "now lets stop it" and asked for new master files.

## Working rules (from the user; full list M1 §12)
Do not guess; ask for the missing file or detail. Keep VERIFIED-FILE / REPORTED / INFERENCE / UNKNOWN apart. Say plainly what was not opened, compiled or run. Monitor-only diagnosis stays separate from repair. Read M1 §9 (corrections — it wins over older statements) before §8.

## Files worth asking the user for next (only when needed)
The stored counter/`SongIntro`/history of the 18 Nov `New_save` and Save 11 (needs a save parser or the user's own read-out) · guard v0.3 source and log · the user's v0.2 log · song names heard on 21 Nov · whether the radio had been played on the 18 Nov save before 21 Nov · `Fallout34.esm` (to compare the volume plugin's descriptors) · `scripts.zip` (QSnap/QRestore callers).
