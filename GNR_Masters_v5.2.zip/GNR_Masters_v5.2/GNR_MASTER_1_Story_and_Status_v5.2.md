# Fallout 34 – Galaxy News Radio (GNR)
## MASTER 1 of 2 — Story, Findings and Current Status — **v5.2** · 21 Nov 2026

**Lineage.** v5.2 = **v5.1 (lean restructure of v5.0, 20 Nov)** + the post-v5.1 events of 20–21 Nov (guard v0.3 report, guard v1.1, volume plugin, 21 Nov test save). **v5.0/v5.1 text is carried unchanged except where marked "▲v5.2"**; every change to an older statement is listed in §9 (items 22–28). The full v5.0 text and bulk tables are in `GNR_ARCHIVE_v5.0_full_and_bulk.zip` (outside the project and not available to the 21 Nov session). Read `GNR_00_START_HERE_v5.2.md` first.

**Companion.** `GNR_MASTER_2_Evidence_v5.2.md` (evidence, tables, plugin inventories). References like **[M2-B7]** point into it.

**Evidence rule (standing instruction from the user: do not guess; ask for the missing file or detail; keep verified facts apart from hypotheses).** Labels:

| Label | Meaning |
|---|---|
| **VERIFIED-FILE** | Read directly from a plugin, export, script or log in the supplied material. **re-checked** = I re-derived it myself in the v5.0 merge. |
| **REPORTED** | What the user, a tester or the developer said happened. No assistant has run the game, compiled or tested anything. |
| **INFERENCE** | Reasoned interpretation; may be wrong. |
| **UNKNOWN** | Not established by any file or report. |

---

## 0A. ▲v5.2 — Post-v5.1 update (20–21 Nov 2026) — read this before §0

1. **Status: testing stopped by the user on 21 Nov (03:47 IST).** The user reports the radio "worked pretty damn good" with **guard v1.1** (REPORTED).
2. **Guard v0.3 (monitor-only) was built on 20 Nov** (REPORTED, from the project's session notes; the v0.3 files and log were **not** in the 21 Nov session → its source, poll interval and hashes are UNKNOWN to this merge). User's report: on a virgin save (about 5 min, two tries) **v0.3 gave no songs** when Three Dog says to play music, while v0.2 played songs; disabling the guard ESP did not make the radio work; switching back to v0.2 made songs work. The v0.3 log showed `SongsPlayed=2`, `SongIntro=1`, history `8,2,0,0` for the whole run (~170 polls). *Observation:* this exact tuple is also the v0.1 reading of 19 Nov [M2-B8.1] → INFERENCE: both runs may have started from the same stored state (unproven).
3. **Guard v1.1 (VERIFIED-FILE, package inspected on 21 Nov; not compiled or run by me; PEX strings match the PSC, bytecode not parsed):**
   - polls every 3 s; `0` and `1` are never touched;
   - counter `< 0` or `> 2` → set to `0` at once;
   - **a `2` that stays unchanged for 30 s is treated as stuck → set to `0`** (new; v0.2 reset any `>= 2` immediately);
   - after **10 recoveries** per session it stops writing and only logs ("BACKOFF");
   - does nothing and logs once if the GNR quest or `F3:RadioGNRScript` cannot be resolved; never edits `Fallout34.esm`;
   - logs `started (OnInit #n / load game)`, every `SongsPlayed` change, `RECOVERY #n … (reads back X)`; 300-line log cap; **does not log `SongIntro` or the four history slots** (v0.2/v0.1 did);
   - `F34_GNR_Guard.esp` is **byte-identical to the earlier guard ESP** (263 B, SHA-256 `b0f31855…`); only the PEX (5,213 B) and PSC changed [M2-B13].
4. **v1.1 run log (VERIFIED-FILE, 21 Nov 03:19–03:33 on the user's clock, 11 lines)** [M2-B13.3]: two `started (OnInit #1)` lines 3 s apart · first reading `SongsPlayed=2` (03:19:44) · stayed 2 for 30 s → `RECOVERY #1: 2 -> 0 (reads back 0)` (03:20:16) · `0→1` at 03:21:19 · `1→2` at 03:27:35 · stuck 30 s → `RECOVERY #2: 2 -> 0` (03:28:06) · `0→1` at 03:33:00. **Only two recoveries; no value outside 0–2 was ever logged; no runaway.**
5. **User's description of that run (REPORTED):** 3 songs heard, on a "half virgin" save that had only `GNR_Everywhere`, `GNR No Static` and a GNR volume-up plugin active from the start. The log shows three counter increases (03:21:19, 03:27:35, 03:33:00) — consistent with 3 songs (VERIFIED-FILE count vs REPORTED count; the log does not name songs).
6. **The test save (VERIFIED-FILE header/plugin list, [M2-B15]):** `Save1_22AA1324_…_F3_Wasteland_000002_20261118215740_2_2` — player `New_save`, made **18 Nov 21:57**, header shows ~2 minutes of play; **not** Save 10/11. Its plugin list includes `GNR No Static_F34.esp`, `GNR_Everywhere_F34.esp`, `Platinum Radio_FNV34.esp`, `PlatinumRadio_Patch.esp`; it does **not** list the volume plugin or the guard (both added after the save was made). The counter value stored in the save was **not extracted**.
7. **The volume plugin (VERIFIED-FILE, [M2-B14]):** `GNR_SongVolumehigh_volume.esp` (4,020 B, author "cloakarx", description "Fixes quiet songs on Galaxy News Radio"); masters `Fallout4.esm`, `Fallout34.esm`; one `SNDR` group with **20 sound-descriptor overrides** of `Fallout34.esm` (`F34_RadioSnd_MUSLicensed…`); **no quest, scene, INFO, script or counter records**. It therefore cannot change `SongsPlayed`; which sound value it changes cannot be told without `Fallout34.esm`. The user says it must load very early in the load order (REPORTED; it needs to load after `Fallout34.esm` to take effect — it overrides that master's records; any later plugin overriding the same descriptors would win; not checked).
8. **New hypothesis H8 (INFERENCE, §8.2):** a counter stuck at 2 is a **dead end for songs until a reset offer arrives** (reset songs only at talk points N5/N66), so the radio is talk-only for as long as that takes. This fits v0.3 (counter 2 all run, no songs) vs v0.2/v1.1 (a written 0 frees the 0/1-gated songs) — but there is **no guard-off baseline** on the same save, and the history/`SongIntro` effect of writing 0 was not logged.
9. **What v1.1 does not show:** why the first reading was 2 on a 3-day-old, 2-minute save (stored state vs fresh); what the game would have done if left at 2 longer; whether writing 0 left the history out of step; which songs played; why two `started` lines appear (both say `#1`, so it is not one object's `OnInit` running twice — cause UNKNOWN).

---

## 0. Executive summary (read this if you read nothing else)

1. **The symptom:** on some saves Three Dog talks but no songs play. Songs are chosen by silent "song INFO" dialogue records whose conditions include the quest counter `SongsPlayed`. If no song INFO passes, the scene just moves on to the next talk segment. (VERIFIED-FILE, multiple sources.)
2. **The intended counter cycle is 0 → 1 → 2 → reset to 0** (three songs per cycle), with reset songs offered only at talk points N5 and N66. **Every one of the 344 counter-changing INFOs in the live quest accepts only 0, 1 or 2; none accepts any other value.** (VERIFIED-FILE; **re-checked** from `GNR_Full_Live_Quest_Counter_Audit.csv`: 120 increments gated at 0, 120 at 1, 100 resets at 2, 4 resets at 1.)
3. **Reliable 01 = Save 11 holds `SongsPlayed = 5`, `SongIntro = 2`, history `11,8,5,3`** (REPORTED in the ChatGPT-session handoff; the method used to read the save is not documented in the files). Value 5 fails all 344 counter-changing INFOs.
4. **This fits Claude A's Reliable 01 matrix.** The test plugins A2 and A3 (which have no `SongsPlayed` check) played songs; the baseline and A1 (which keep the `SongsPlayed` check) were silent. A counter of 5 would produce exactly that pattern. (INFERENCE — strong, but not proven: the matrix has method gaps, see §5.2.)
5. **How the counter got to 5 is unknown.** The main script has snapshot/restore helpers (`F34_QSnap` / `F34_QRestore`) that *could* re-apply a stored nonzero value, but no caller against the GNR quest has been found. The separate `scripts.zip` needed to finish that search is not in anyone's package. (UNKNOWN.)
6. **Project direction changed:** stop chasing why one save has 5; build a **safe, general self-recovery** mechanism (detect invalid counter, return to a valid state, never disturb valid states 0/1/2). (User decision, ChatGPT session.)
7. **A working-but-unsafe workaround exists:** guard v0.2 (`F34_GNR_Guard.esp` + `F34GNRGuard.pex`) forces the counter to 0 whenever it reads ≥ 2. The user reports songs play with it. **It is wrong by design** (it also resets the valid value 2 at once, suppressing the normal cycle and the 100 reset INFOs that need 2) and **must not be distributed.** *▲v5.2: v0.2 is superseded as the working candidate by **guard v1.1** (§0A), which waits 30 s before treating a 2 as stuck; v0.2 itself stays "do not distribute".*
8. **A new, bigger finding from tester logs (guard v0.2 running):** the counter is sometimes written **many times per second** — 1596 at a tester's first poll, 67 about 77 s after a clean 0 on a brand-new save — with the history filled with one song (song 9). On the old save, songs 1 and 5 alternated for ~25 minutes despite the four-slot "recently played" check. **Cause unknown.** This happens on a *new* save too, so it is not only a damaged old save. Whether it also happens with the guard absent has never been tested (monitor-only run needed). *▲v5.2: the v1.1 run showed no runaway; it is one run on one save and does not settle the question.*
9. **A developer's separate "radio fix"** (`F34_RadioFix.esp`) overrides 225 INFOs (48 of them GNR scene-A song INFOs) to add a hidden speaker NPC and a `.fuz` voice file per song. Nobody has reported testing it on GNR. Whether GNR needs it is open.
10. **Next build (as of v5.1):** a **monitor-only guard v0.3** (never writes), run on the same saves with and without the dev's fix; then — only then — design the repair. Full ordered plan in §10. *▲v5.2: v0.3 was built on 20 Nov (§0A item 2) and guard v1.1 followed on 21 Nov; the controlled runs in §10 step 3 have **not** been done; the user stopped testing on 21 Nov.*

---

## 1. Source material (compact; full inventory in M2-B1)

Sessions in order: **S1** (≤17 Nov) earlier masters v1/v2 → **S2** (18 Nov) Test A/B plugins + independent testers → **S3** (18–19 Nov) **Claude A**: Reliable 01 matrix, bytecode reading → **S4** (19 Nov) **Claude B**, master v3.1.1 → **S5** (19 Nov) **ChatGPT session**: Save 11, full live-quest INFO export/audit, self-recovery objective → **S6** (19 Nov) **Claude C**: guard v0.1/v0.2, own PEX/ESP parsers, tester logs, dev's radio fix, song map, masters v4.0/v4.1 → **S7** (19 Nov) merge = **v5.0** → **S8** (20 Nov) lean restructure = **v5.1**; guard v0.3 built (per notes) → **S9** (21 Nov) guard v1.1 inspected, v1.1 log read, volume plugin and test save inspected = **v5.2**. v3.1.1/v4.0/v4.1 are superseded.

**Not in anyone's hands** (needed for specific open questions): `Fallout34.esm` / `Fallout34old.esm` binaries · the 9,301-script `scripts.zip` · the **counter value stored in any save** (Save 11, the 18 Nov test save, tester saves — the saves exist but nobody parsed their quest variables) · tester's plugin list · user's own v0.2 log · **guard v0.3 files and log** · dev's `tools/radiofix.py` · the 639 fragment sources, scene exports and two song CSVs (available to earlier sessions, not to the v5.0 merge; numbers depending on them are carried and labelled).

---

## 2. What GNR is and how it works

### 2.1 Scenes, INFOs and the counter

- GNR is driven by **radio scenes**: ordered phases that wait, run dialogue, play a sound, or hand over to another scene.
- A **song** is selected through a **song INFO**: a silent dialogue record (empty text, no voice line) whose conditions decide whether it may fire. It then starts the scene phase that plays the licensed song. If no song INFO passes, the scene proceeds to the next talk phase. That is the "talk but no music" symptom.
- Song INFO conditions involve: `SongsPlayed` (quest counter), `LastSongPlayed`–`LastSongPlayed4` (recent-song exclusion), `SongIntro`, whether the GNR quest is running, and whether a transmitter is enabled.
- Conditions are **not** all ANDed: an `Or` flag can group rows. On INFO `0AED5399` the two transmitter checks are grouped "transmitter 0 OR transmitter 1" with the other checks still required. Do not generalise that layout to every INFO.

### 2.2 The counter cycle (VERIFIED-FILE, not yet confirmed in-game)

1. A group of songs is offered when `SongsPlayed == 0`; playing one adds 1.
2. Another group when `SongsPlayed == 1`; playing one adds 1 again.
3. Reset songs when `SongsPlayed == 2`; playing one sets the counter to 0 (and updates the history).
4. So the cycle is **0 → 1 → 2 → 0**. Reset songs are offered only at talk points **N5 and N66**. A counter of **2 is a legitimate "waiting for a reset offer" state, not a fault.** *▲v5.2: the v1.1 run shows the counter really does go 1→2 naturally (03:27:35) and the v0.3 report shows it staying at 2 with no songs — see H8, §8.2. "Legitimate" describes the design, not that the radio keeps playing during it.*
5. The helper `F34_Add_SongsPlayed(afDelta)` is **uncapped**; nothing in the main script limits or resets the counter. Reset fragments set it to 0 and also shift the history.

### 2.3 Fragment inventory (VERIFIED-FILE; the 639 sources were read by earlier sessions)

- 639 GNR topic-info fragments (`tif_f3_radiogalaxynewsquest_<hex>.psc`); the hex is the original Fallout 3 INFO FormID with load-order byte `01`.
- **172 change the counter: 120 increment** (`F34_Add_SongsPlayed(1)`), **52 reset** (`SongsPlayed = 0`). Every one of the 172 also shifts the four history slots and writes the new song number.
- **Each of the 20 song IDs has 6 increment fragments: 3 gated at counter 0 and 3 gated at counter 1** (**re-checked**; this corrects v4.1's A8c wording, see §9 item 14).
- Reset fragments: songs 1–12 have 3 each (36), songs 13–20 have 2 each (16) = 52.
- Each counter-changing fragment is attached to exactly one INFO in scene A and one in scene B → **344 counter-changing INFOs (240 increment, 104 reset)**. Pair members have identical condition lists.
- `SongIntro` writers: 12 set 1–12, 36 set 0, 4 set −1 (the old README said 52 set 1–12; corrected). Seven fragments `01057B11`–`01057B17` use `Fragment_Begin` and only touch `DadStoryVar`.

### 2.4 The live quest (VERIFIED-FILE, full FO4Edit export)

`F34_Radio_RadioGalaxyNews` (`QUST 0AD0EE64`): 164 DIAL topics (82 per scene), **1,732 unique INFOs**, two scenes with 505 phases and 505 actions each. Every INFO in the export names `Fallout34.esm` as its source file, so the audit describes the **master's records only** — it does not show what an active override ESP would change. The 78 `F3_RadioGNR…` topics under `F34_DialogueShared` are empty shells, not the live radio.

### 2.5 Main script `F3:RadioGNRScript`

- `SongsPlayed` is a plain auto property, initial value 0, readable by dialogue conditions.
- `F34_QSnap` copies quest variables into a snapshot array (`SongsPlayed` = slot 18). `F34_QRestore` (after quest start) restores a snapshotted **nonzero** value when the current value is **0**.
- `F34_FragBegin` sets a timer to now + 2 s; `F34_FragEnd` clears it. 172 fragments pair them. This only pauses a periodic check for about two seconds; it does not write the counter.
- `F34_GameModeTick` is the unrelated Harkness/MS08 exploit logic.
- `QSnap`/`QRestore` etc. are **functions inside the main script, not separate `.pex` files** (which is why searching the archive for files with those names found nothing).
- The older README reports 56 `QSnap`/`QRestore` callers in CG02/CG03 fragments acting on their *own* quests, none in the 639 GNR fragments. Claude A later found 1,786 files that *mention* `F34_QSnap` in `scripts.zip` — a raw mention count, not a call count; the definition/reference/call classification was never finished.
- `radiognrscript.psc` is truncated (decompiler crash); `radiognrscript.pas` is the complete bytecode listing (60,094 bytes). Claude C's own parser read the compiled `.pex` to the last byte and agreed with the QRestore reading (parser's opcode argument counts were written from memory, not validated against Champollion).

### 2.6 Transmitters

Both GNR transmitter references (`0AFDDC93`, `0AD7D651`) are **Persistent + Initially Disabled** in `Fallout34.esm` (and in `GNR_Everywhere_F34.esp`), with no Enable Parent. Because A2/A3 kept the transmitter conditions and still played songs, at least one transmitter must have satisfied its condition at runtime. **What enables it is UNKNOWN.** Record flags are not live state; do not say "both are enabled".

---

---

## 3. The two ESM builds

| | `Fallout34old.esm` | `Fallout34.esm` (current) |
|---|---|---|
| Radio scenes | One (A), 435 phases | Two mirrored (A and B), 505 phases each |
| Wait phases | none | 70 short `N#_W` waits (~0.75 s) before talk phases |
| Song INFOs | Start scene A itself (already running) | A and B **hand off to each other** |
| Records | ~9,000 fewer | 363,354,547 bytes; SHA-256 `16F35D6C…FECF7E9` |
| Other | — | 172 INFOs retargeted; 468 of 640 shared GNR INFOs byte-identical |

`Fallout34_1.esm` was byte-identical to `Fallout34.esm`. The user's `Fallout34.esm` is the same **size**; its hash was never compared. This proves the current build has a changed A/B flow, **not** who made the change or why. The old build's behaviour was never tested.

---

---

## 4. Early investigation (17–18 Nov)

### 4.1 Ruled out on paper (S1, 17 Nov; table in M2-B3)

Missing scripts/variables, missing song files, sound settings, missing scene phases, voice files for song INFOs: cleared. Wrong worldspace: weakened. **Transmitter state** was listed as "both enabled" — **not** verified; replaced by §2.6. The modder's `.fuz`/speaker theory was "unsupported", now **contested** (§7).

Useful setup facts: FO4Edit 4.1.5f; game at `C:\Games\Fallout 4`; GNR scripts are in `Fallout34_2 - Main.ba2`; `Fallout34.esm` shows as index `0A` in xEdit and `01` in dumps (compare the last six digits); the Papyrus log has no GNR lines; `F34MUSIC` logs a music-stack clear on every load. Scene A calls song topic `0AEAECDA` at 11 points (action indexes 146, 149, 154, 156, 247, 249, 260, 264, 268, 272, 276); scene B mirrors it with `0AC92CD7`; about 34 talk segments precede the first offer. Only scene A has "Begin on Quest Start". INFO `0AED5399` has flags Start Scene on End, Random, Random End, End Running Scene, empty text, null sound.

### 4.2 Diagnostic plugins and independent testers (S2/S3)

Six test ESPs override the same 96 song INFOs: **Test A** (transmitter + quest-running only), **Test B** (transmitter only), **A0** (base + all three variable groups), **A1** (base + `SongsPlayed`), **A2** (base + `LastSongPlayed`), **A3** (base + `SongIntro`). CTDA counts: M2-B2.1. The user's "Test A01/A02/A03" = A1/A2/A3. ESPs do not rewrite `Fallout34.esm`; disabling one **does not reset anything already stored in a save**.

**Independent testers (REPORTED):** Test A alone, then Test B alone, made the radio work; disabling it broke it again. Consistent with H0 (neither contains a `SongsPlayed` check) — an inference about their saves, not measured.

---

## 5. Test results and audits, by session

### 5.1 The retracted "new save works with every patch off" result

An early run seemed to show songs playing on a new save with all patches off. The user later **retracted** it: the radio played for several songs and then went wrong again. The user suspects the automatic `exitsave` retained state from A2/A3 runs (unproven; the user disabled using that save for later tests). **Do not use that result as evidence that patches are unnecessary.** (A possible link to the runaway seen on a tester's new save is in §8 H1 — inference.)

### 5.2 Claude A — the Reliable 01 matrix (REPORTED by the user)

`Reliable 01` is a pre-project save the user describes as showing the common no-song problem. Test plugins were enabled one at a time; the same plugin list was used; **`GNR_Everywhere_F34.esp` and `GNR No Static_F34.esp` stayed enabled throughout** (so "baseline" means *no diagnostic test ESP*, not "no GNR ESP at all"). `Fallout34.esm` (363,354,547 bytes) was enabled; `Fallout34old.esm` was not.

| Setup on Reliable 01 | Result | Carries the `SongsPlayed` check? |
|---|---|---|
| Baseline (no test ESP) | Conversation only, gaps while a song is sought | yes (original INFOs) |
| A1 | Conversation only (listened for *less* time than A2/A3) | yes |
| A2 | Songs + conversation, "a good amount of time", not cut short | **no** |
| A3 | Songs + conversation, same | **no** |
| A0 (all three groups) | Earlier report: silent; not a documented timed run | yes |

Method gaps (keep them visible): exact listening minutes and song counts were **not recorded**; whether the original save was **freshly reloaded** before every run with no save write in between was **never confirmed**; A1 was listened to for a shorter time. The pattern follows the presence of the `SongsPlayed` condition, which made it the lead.

Screenshot findings (single INFO `0AED5399` only; do not generalise): conditions #4–#7 are the four `LastSongPlayed` checks "Not equal to 1"; the transmitter checks are 0 OR 1; `SongsPlayed` is Equal to 0.

### 5.3 ChatGPT session — Save 11 and the full INFO audit (REPORTED + VERIFIED-FILE)

- **Reliable 01 is Save 11** (user-confirmed, not the virgin new save). Values reported from the save: **`SongsPlayed = 5`, `SongIntro = 2`, history `11, 8, 5, 3`.** How these were read is not documented in the files I have; treat as REPORTED.
- Full FO4Edit export of the live quest (§2.4) and audit: all 172 counter-changing fragments found, two INFOs each (344). **No INFO accepts 5** (re-checked). So a counter of 5 blocks every known song and reset path.
- This also closed an earlier gap: the older cross-check audit found INFO links for only 48 of 120 increment fragments and listed 72 as "no INFO link in supplied exports". The full export finds them all; that "72 unlinked" status in the CSV is **stale**.
- **Confirmed condition/fragment anomalies** (VERIFIED-FILE; they are mismatches, **not** proven causes of silence):
  1. **Song 8**: fragments `01057B29` (A `0AB73340` / B `0AFF891F`) and `010752A7` (A `0AC9F568` / B `0AA24877` — scene labels taken from the audit CSV; the audit's prose has A and B swapped for this one fragment, §9 item 21) write song 8 and shift all four history slots, but their INFOs omit the `LastSongPlayed3` check.
  2. **Two reset fragments** `01074EF3` (A `0AE757B1` / B `0AD3D631`) and `010A870A` (A `0A95D0E8` / B `0AEE8959`) write `LastSongPlayed = 1`, but their conditions compare all four slots to song **2**, and they are gated at `SongsPlayed == 1` rather than 2.
- All eight reset-bearing topics are called by both scene trees around phase groups N5 and N66 (static wiring only; runtime reachability not shown).
- **Project direction change (user decision):** do not make "why does Save 11 hold 5" the objective. Design a general, conservative self-recovery. Design principles and the test matrix are in §10 and M2-B11.

### 5.4 Claude C — guard, logs, dev fix (details §6–§7)

Built guard v0.1 (monitor) and v0.2 (writes); own PEX/ESP parsers; analysed tester logs; parsed the dev's archive; built the song map. `GNR_Everywhere_F34.esp` / `GNR No Static_F34.esp` (VERIFIED-FILE): Everywhere sets the two transmitter REFRs' radio data to `(99.3 = frequency, 1,000,000, 1,200,000, 0)`; No Static overrides `F3_RadioGalaxyNewsRef01` (`01022488`) with no radio data. **Neither has sound, quest, scene, INFO or script records; neither touches the counter or volume.** Detail: M2-B2.2.

### 5.5 ▲v5.2 — 20–21 Nov: guard v0.3 report, guard v1.1 run

See §0A for the facts. Summary of what each run can and cannot support:

| Run | Save | Guard | Songs | What it supports | What it cannot show |
|---|---|---|---|---|---|
| 19 Nov (v0.1 log) | not recorded | v0.1 monitor | user: Three Dog says "music time", news returns | counter 2, history `8,2,0,0` (valid state) | cause of silence |
| 20 Nov (REPORTED) | virgin save | v0.3 monitor | **none** in ~5 min ×2 | counter 2 / intro 1 / history `8,2,0,0` all run; consistent with H8 | no guard-off baseline; v0.3 files not seen |
| 20 Nov (REPORTED) | same | v0.2 (≥2 → 0) | songs | writing 0 frees songs | history effect unlogged |
| 21 Nov (log + REPORTED) | 18 Nov `New_save`, ~2 min play | v1.1 | 3 songs (user) | first reading 2 → 30 s → 0 → song ~1 min later; later 2 → 30 s → 0 → song ~5 min later | whether the game would have recovered unaided; song names; history coherence |

---

## 6. The guard in detail

### 6.1 Versions

| | v0.1 | v0.2 | v0.3 ▲v5.2 | v1.1 ▲v5.2 |
|---|---|---|---|---|
| Role | Monitor only | **Writes**: `SongsPlayed = 0` when `>= 2` | Monitor only (REPORTED) | **Writes** `0` when `<0` / `>2`, or when a `2` is unchanged 30 s; backs off after 10 |
| Poll | 30 s | 5 s | UNKNOWN (~170 polls in the reported run) | 3 s |
| Log | on change or "invalid" (0–2 assumed valid) | every `SongsPlayed` change + `RESET #n` lines | UNKNOWN | `SongsPlayed` changes + `RECOVERY #n`; no history/`SongIntro` |
| Script name | `F34GNRGuard` | same | same (per notes) | same (VERIFIED-FILE) |
| Status | superseded | **do not distribute** | files not seen | **current candidate** (user: works) |

Design (all): quest `F34_GNR_Guard` in `F34_GNR_Guard.esp` runs `F34GNRGuard extends Quest`; finds the GNR quest with `Game.GetFormFromFile(0x00022486, "Fallout34.esm")`, casts to `F3:RadioGNRScript`, reads `SongsPlayed` (v0.1/v0.2 also `SongIntro`, `LastSongPlayed…4`) via `GetPropertyValue`, (v0.2/v1.1) writes via `SetPropertyValue`; registers `OnPlayerLoadGame`; does nothing and logs once if the quest or script is missing. Log: `Documents\My Games\Fallout4\Logs\Script\User\F34_GNR_Guard.0.log` (needs `[Papyrus] bEnableLogging=1, bEnableTrace=1` in `Fallout4Custom.ini`, or the MO2 profile copy). Compile: Papyrus Compiler 2.8.0.4 via `compile_guard.bat`. v0.1's first compile failed (`state` is reserved; no `\` line continuation in Papyrus) and was fixed. Full v0.2 source: archive; v1.1 source: `Guard_v1.1/Scripts/Source/User/F34GNRGuard.psc` in the v5.2 zip and M2-B13.

### 6.2 What the logs show (guard v0.2 running in every case; tester's clock, 18 Nov evening)

Songs: 5 = Billie Holiday "Easy Living", 1 = Cole Porter "Anything Goes", 9 = Bob Crosby "Way Back Home". Key log lines: M2-B8; full old-save log in the archive.

- **User, v0.1** (19 Nov 07:56): two "started" lines same second; one reading 41 s later `SongsPlayed=2 | SongIntro=1 | history=8,2,0,0` — a **valid** state. User also reported: Three Dog says "music time", then news returns after a few seconds; enabling A2 or A3 makes songs work.
- **User, v0.2:** reported "songs works". Save, listening time, song count and log **not supplied** → cannot tell "guard fixed a bad state" from "forcing 0 sidesteps the cycle".
- **Tester, existing save (10:19–10:51 PM):** first poll `1596 | 9,9,9,9` → reset. Then ~23 min with no resets: counter alternating 1,0,1,0, history only songs 5 and 1 (`5,9,9,9 → 1,5,9,9 → 5,1,5,9 → 1,5,1,5 → 5,1,5,1`). At 10:43:39 the counter jumps again (9, 12, 12, 13, 14, 8, 3 …, history `9,9,9,9`): **RESET #2–#35 in ~5 min**; other tuples interleave (e.g. 14,1,5,10 / 17,16,9,18 / 19,15,17,16 with SongIntro 11) and `5,1,5,1` reappears at 10:46:08 exactly as at 10:40:03. Two resets read back 1 right after being set to 0 (#4, #25). Tester said ~20 min, "Easy Living about 4 times", a couple of songs. Save pre-existing (which one unknown); "standby" meaning unclear.
- **Tester, same save reloaded (11:16:54 PM):** `RESET #36` continues the earlier count → the script's own variables **survived save/load**. The guard reset a **valid** 2.
- **Tester, new save (11:18–11:44 PM):** 11:18:45 clean `0 | 0,0,0,0`; next logged reading 11:20:02 **`67 | 9,9,9,9`** (reset); then `1 | 5,1,5,16`, `0 | 1,5,1,5`, `1 | 9,1,5,1`, `2 | 19,9,1,5` (valid 2 reset), `1 | 13,19,9,1`, `2 | 5,13,19,9` (valid 2 reset). More variety than the old save, but `1,5,1,5` / `9,1,5,1` still appear. The relayed remark "no 4-in-a-row repeats; Three Dog changes topic halfway" is only partly supported by the log.

Reading notes: (a) a line is written only when `SongsPlayed` changes, so history changes in between are invisible; (b) "0 then 67" were consecutive *logged* readings 77 s apart; Papyrus timers can pause in menus/loading, so the real rise time is unknown; (c) the 1596 at first poll could be a value *restored from the save* rather than generated in 11 s.

▲v5.2 note: the tester's v0.2 logs show natural 2s at 11:17:41 (history `9,9,1,5`), 11:35:12 and 11:44:21 — i.e. the counter reaches 2 in normal play — and v0.2 reset each one at once, so those logs cannot show how long a natural 2 would have lasted either.

### 6.3 Guard ESP and PEX, parsed (VERIFIED-FILE, my own parse; detail M2-B7.4)

`F34_GNR_Guard.esp` (263 B): masters `Fallout4.esm`, `Fallout34.esm`; one `QUST` with **exactly one script, `F34GNRGuard`, no properties** → **refutes** "the ESP attaches the script twice"; cause of the double `OnInit` (same second on some runs, 13 s apart on the new-save run) is **UNKNOWN**. DNAM first word `0x0011`: meaning not confirmed — **check in CK/FO4Edit that "Run Once" is really off**. The v0.2 `Scripts/F34GNRGuard.pex` (4,213 B) was the unsafe build (`cmpge played 2` → `SetPropertyValue "SongsPlayed"`; `GNRQuestLocalID` 140422 = `0x22486` ✓). ▲v5.2: the v1.1 package ships the **same ESP** (SHA-256 `b0f31855…`) with a new PEX (5,213 B, SHA-256 `a82608be…`); the double "started" lines persist in the v1.1 log (both say `OnInit #1`) [M2-B13.3].

### 6.4 Packaging notes

An MO2-installable archive needs `F34_GNR_Guard.esp` and `Scripts\F34GNRGuard.pex` at the top level (optionally `Scripts\Source\User\F34GNRGuard.psc`, `README.txt`); no `Data` folder inside; make sure no other MO2 mod carries an older `F34GNRGuard.pex`. Load order must put the ESP after `Fallout34.esm`. ▲v5.2: the v1.1 `ReadMe.txt` is clean (no hostile line; install steps, log instructions, log-line key) and warns that v0.2 builds also reset the valid 2; the v1.1 zip does **not** contain `HOWTO_compile_and_test.md` (the v0.1 text), `compile_guard.bat` or `pexdump.py`, so whether the old HOWTO is still circulating is UNKNOWN. The `.psc` header still says "(candidate)".

---

---

## 7. The developer's radio fix (`radiofix.rar`) and the song map

### 7.1 What the developer said (REPORTED via the user)

Most FO3/FNV DJ lines were never properly converted; in the originals songs play through an attached dialogue line, Fallout 4 does not do that; song lines have no speaker so the engine has nothing to play; every song needs a speaker (an invisible "radio music" voice) and a `.fuz` voice file. Two fixes are needed: make songs playable, and make stations actually play DJ lines and songs.

### 7.2 What the archive contains (carried from v4.1; archive not re-opened; detail M2-B9)

`F34_RadioFix.esp` (Fallout 3 stations) and `F34_RadioFixNV.esp` (New Vegas; **not GNR evidence**). The FO3 plugin has 225 INFOs, 15 DIAL, 5 QUST (incl. GNR `01D0EE64`), one speaker NPC `F34R_RadioMusicVoice` (`02000801`); **all 225 INFOs name that speaker and a Start-Scene-on-End target**, same `SongsPlayed`/history conditions. **All 48 INFOs of GNR scene A's song topic `0AEAECDA` are in it; none of scene B's 48 (`0AC92CD7`)** — reason unknown. Audio (`F34R_RadioMusic` 225 `.fuz`, 524 Three Dog lines …) is converted game audio from the user's own install — **do not redistribute**.

### 7.3 What this does and does not tell us

- The speaker + `.fuz` approach is **real and implemented** for 48 GNR song INFOs (so not hypothetical).
- **Conflict still open:** the scene exports show **113 direct "Play Sound" actions in each scene** naming the song descriptors, next to 135 Radio actions with null sound. Which path makes music audible in-game is not established. A tester does hear Easy Living without the fix, so at least some songs are audible. ▲v5.2: the 21 Nov test also heard 3 songs without `F34_RadioFix.esp` (the plugin list of that save does not contain it).
- The dev's fix keeps the same counter conditions, so **it does not explain the runaway or the 5/1 alternation.** The 524 Three Dog voice files may relate to "Three Dog changes topic halfway through the news" — nothing in the files shows it.
- Originals of those 48 INFOs (speaker, response audio) were never compared because `Fallout34.esm` was unavailable.

### 7.4 Song ID map (record-derived; spot-check in FO4Edit)

Songs 1–12 are named in M2-B5 (e.g. 1 Anything Goes, 5 Easy Living, 9 Way Back Home, 12 I Don't Want to Set the World on Fire). Songs 13–20 are **not mapped** (their INFOs are in other topics). The map came from fragment sources + the scene export + the song CSV, none of which this merge could re-open.

**How the counter pattern explains the 5/1 alternation (INFERENCE, plausible):** song 5 has increment fragments gated at 0 and at 1; song 1 has **two resets gated at 1** (`01074EF3`, `010A870A` — the same mismatched pair as §5.3). So "5 then 1" moves the counter 0 → 1 → 0 without ever reaching 2. What this does **not** explain is why song 5's own four-slot history check does not exclude it when it is already in the history (`5,1,5,1`).

---

---

## 8. Putting it all together

### 8.1 What the combined evidence supports

1. **A counter outside {0,1,2} blocks every song path.** VERIFIED-FILE for the INFO gates (re-checked). Reliable 01 (Save 11) holds 5 (REPORTED). Claude A's matrix (silent with the `SongsPlayed` check present, songs without it) and the independent testers' Test A / Test B results (no variable checks at all) are all consistent with this. **Strong lead for Reliable 01; not a measured runtime proof** (the matrix had method gaps, the value was read from a save by an undocumented method, and the user's test plugin list included two GNR ESPs).
2. **Abnormal values exist without the guard:** Save 11 is a *pre-project* save, so the guard did not create its 5.
3. **Something can rewrite the counter and history at high rate.** Seen only in guard-v0.2 logs, on an existing save and on a new save (§6.2). Whether it happens with no guard running is **untested**.
4. **Forcing the counter to 0 lets 0- and 1-gated groups fire**, which is why "songs work" with v0.2 — but the log also shows the 5/1 repetition and runaway episodes persisting with v0.2 running, so v0.2 is not a fix.
5. **The cause of any out-of-cycle value is unknown** (restore path, runaway fragment loop, or something else).
6. ▲v5.2: **Writing 0 after a 30 s wait (v1.1) coincided with working radio in one run** (3 songs, 2 recoveries, no runaway) on a 3-day-old save. That is encouraging for the guard design but is a single unblinded run; it does not distinguish "guard fixed a stuck state" from "radio would have worked anyway".

### 8.2 Hypothesis register

| ID | Hypothesis | For | Against / gaps | What would decide it |
|---|---|---|---|---|
| **H0** | An out-of-cycle `SongsPlayed` makes all song INFOs fail → talk-only radio | Gates re-checked; Save 11 = 5; A0/A1 silent vs A2/A3 songs; Test A/B worked for testers | Runtime value never read during the A-tests; fresh-reload not confirmed; save-read method unknown | Monitor-only log on Reliable 01; repeat A1/A2/A3 with timing and fresh reload |
| **H1** | A song-9 end-fragment (or a silent INFO with Start Scene on End) re-fires repeatedly, adding 1 and writing song 9 into all history slots each time | Signature `N | 9,9,9,9`; each increment adds exactly 1 and shifts history; 0.75 s wait phases would allow a few runs/second; the history only contains 9 though 67–1596 increments happened. *Fragments run after an INFO is picked, so a re-fired end fragment would not re-check conditions* — which would also explain how history exclusion can be bypassed | Does not say what restarts it, or why it is song 9; also could not be separated from restored-from-save (§6.2c) | v0.3-style per-second log (rate of change, history fill) on a clean new game without the guard writing |
| **H2** | Two copies of GNR variables / two script instances → flipping state tuples | Distinct tuples recur exactly (`5,1,5,1` at 10:40:03 and 10:46:08); double "started" (also in the v1.1 log, both `#1`) | The guard ESP carries one script (§6.3), so the guard itself is not doubled; no evidence of a second GNR instance; in v1.1 a second instance should have logged `SongsPlayed=2 (was -999)` twice — it appears once | Log object identity and an `OnInit` counter; read variables both via property and directly |
| **H3** | `F34_QRestore` re-applies a snapshotted nonzero value when the counter is 0 | The function exists and does exactly that; guard writes of 0 could trigger it; "now reads 1" after two writes | No GNR caller found; `scripts.zip` unavailable | Classify the 1,786 mentions into definitions / references / calls |
| **H4** | The four-slot recent-song exclusion is not working for some songs | `1,5,1,5` repeats; song 8 INFOs miss a slot; song 1 resets mismatched | Song 5's INFOs do carry all four checks; INFO conditions are evaluated at selection, not at fragment time (see H1) | Log with song audible-name capture; check scene-direct "Play Sound" path |
| **H5** *(mine, untested)* | Under A2/A3 the counter gating is gone, so increments continue uncapped and the counter drifts upward; later, with the test ESP removed, it stays out of cycle | A2/A3 play songs regardless of counter; reset INFOs need exactly 2; the user's `exitsave` suspicion fits; the retracted "worked then broke" new-save result fits | Pure inference; no counter value was ever read after A-tests | Log counter during an A2/A3 run |
| **H6** | The 5 in Save 11 came from a snapshot/restore or earlier broken run | — | No evidence either way | Same as H3 |
| **H7** | Songs need a speaker + `.fuz` to be audible (dev's view) | Dev's plugin implements it for 48 GNR INFOs | Scenes also play song sounds directly; a tester hears Easy Living without the fix; 3 songs heard on 21 Nov without the fix | Test GNR with and without `F34_RadioFix.esp`; ask the dev |
| **H8** ▲v5.2 *(INFERENCE)* | A counter **stuck at 2 is a dead end for songs** until a reset song is offered (talk points N5/N66, ~34 talk segments before the first song offer, so possibly minutes). On some saved states the counter sits at 2 and the radio is talk-only; a write of 0 (v0.2 at once, v1.1 after 30 s) frees the 0/1-gated song INFOs | v0.3 (monitor-only): counter 2, no songs, whole run; v0.2 (≥2 → 0): songs on the same kind of save; v1.1 log: first reading 2 → 0 after 30 s → first song ~63 s later; second 2 (reached naturally) → 0 after 30 s → next song ~4 min 54 s later; all 344 song/increment INFOs need 0 or 1 | No guard-off baseline on the same save; v0.3 files/log unseen; the songs after the recoveries might have come anyway; whether the N5/N66 reset ever fires from a stuck 2 is **not** known; history/`SongIntro` effect of writing 0 not logged; one 5-minute and one 14-minute run | Monitor-only run (with `SongIntro` + history) on the 18 Nov `New_save` and on the "virgin save", long enough to pass an N5/N66 point; count and name songs; then same save with v1.1 |

None of H1–H8 is confirmed. H0 is the best-supported for Reliable 01; H8 is the best-supported reading of the 20–21 Nov runs but rests on one report and one log.

---

---

## 9. Corrections and retractions (consolidated)

Where an older statement conflicts with this list, this list wins.

1. **Retracted (S3):** "a new save works with all patches off" — it later broke. §5.1.
2. **Superseded (v2 → v3):** "only counter values 0 and 1 pass / no live reset path." The cycle is 0→1→2→reset; reset INFOs are attached to live topics (104 INFOs).
3. **Retracted (Claude C):** "song lines accept only 0 or 1, so 2 is stuck." 2 is valid. *▲v5.2: the retraction stands for the INFO gates (reset INFOs gate on 2). Item 23 records the practical question — whether a long-lived 2 silences the radio — as a hypothesis (H8), not as a reinstated claim.*
4. **Guard v0.2's threshold (`>= 2`) is wrong**; the rule is: leave 0,1,2 alone; act only on < 0 or > 2. *▲v5.2: provisionally refined by item 23.*
5. **The tester ran guard v0.2**, not "no guard" (the user's "standalone" meant guard alone, without A2/A3).
6. **`99.3` in `GNR_Everywhere_F34.esp` is the radio frequency**, not an unknown value.
7. **Duplicate "started" line:** the theory "the ESP attaches the script twice" is **refuted** (one script in `VMAD`). Cause still unknown.
8. **Dev's archive has two plugins** (FO3 and NV); the FO3 one covers GNR.
9. **The `.fuz`/speaker theory** is **contested**, no longer "unsupported" (§7).
10. The re-uploaded `Fallout34_GNR_Claude_B_Package_v3_1_1_1.zip` and `…Handoff_Package…_1.zip` were byte-identical to the originals (checked by Claude C).
11. Tester logs use **the tester's clock**.
12. **Transmitters are not "both enabled"**; records are Persistent + Initially Disabled and the runtime enabler is unknown.
13. **Old README corrections:** intro fragments are 12 (values 1–12) + 36 (zero) + 4 (−1), not 52 at 1–12; seven fragments (`01057B11`–`01057B17`) use `Fragment_Begin` and are `DadStoryVar`-only, so not every fragment uses `Fragment_End`; both song CSVs duplicate every row twice (407 unique rows each).
14. **v4.1 A8c wording was wrong** ("each ID has 2 gated at 0, 2 gated at 1, 2 ungated"). The audit CSV (**re-checked**) gives **every song ID: 3 increment fragments gated at 0 and 3 gated at 1**. The song-5, song-9 and song-1 fragment lists in v4.1 were correct.
15. **The cross-check audit's "72 increment fragments with no INFO link"** (and the CSV status text) is stale; the full export links all 172.
16. v4.1 said the guard ESP's masters/script count were unverified; they are now verified (§6.3).
17. The v0.2 `F34GNRGuard.pex` (4,213 B) is **unsafe**, and `HOWTO_compile_and_test.md` still describes v0.1. *▲v5.2: the v1.1 package replaces the PEX; the HOWTO is not in the v1.1 zip (§6.4).*
18. The tester's "no 4-in-a-row" remark is only partly supported by their new-save log.
19. **Console dead end stays:** the console cannot read the counter (`GetVMQuestVariable`: "Param type 74 unimplemented"). Do not propose it as untried.
20. **The v3.1.1 "Next technical gap" (QSnap caller search) is still open** but is no longer the main line.
21. **Scene labels for song-8 fragment `010752A7`:** the audit `.md`/handoff prose lists scene A = INFO `0AA24877` / DIAL `0AFC288C`, scene B = `0AC9F568` / `0AD702D2`. The audit CSV (**re-checked**) has it the other way round (A = `0AC9F568` / `0AD702D2`; B = `0AA24877` / `0AFC288C`), and `0AFC288C` is a scene-B topic everywhere else in the CSV. This document follows the CSV. The INFO pair itself is unaffected.
22. ▲v5.2 **"Working-but-unsafe workaround" (§0 item 7):** v0.2 is no longer the working candidate; **guard v1.1** is. v0.2 remains "do not distribute". Reason: v0.2 resets a valid 2 at once.
23. ▲v5.2 **Rule "leave 0, 1, 2 untouched; act only on < 0 or > 2" (items 4, §10 step 9, §12) is provisionally relaxed to: leave 0 and 1 untouched; a 2 is left alone for up to 30 s, then treated as stuck.** Basis: user's report that v0.3 (monitor-only, counter 2) gave no songs while v0.2 did, and the v1.1 run. **Not validated:** history coherence after writing 0 was not logged, and whether the game would have reset a 2 on its own was not tested. Treat as a user-chosen working rule, not a proven one.
24. ▲v5.2 **"v0.3 is not yet written, compiled or run by anyone" (M1 §0 item 10, §10 step 2, M2-B11.3):** v0.3 was built on 20 Nov and run by the user (REPORTED). Its files and log were not seen by this merge.
25. ▲v5.2 **"Next build: monitor-only v0.3" is done**; the user then moved to v1.1. §10 step 3 (controlled runs) is still **not done**.
26. ▲v5.2 **The 21 Nov test save is `New_save` (18 Nov 21:57, ~2 min play), not Save 10/11 and not a brand-new save made on 21 Nov.** The user calls it "half virgin". Its stored counter value is not known.
27. ▲v5.2 **The user's "GNR volume" plugin is `GNR_SongVolumehigh_volume.esp`** (20 `SNDR` overrides, no counter/quest/script records). It does not touch the counter, so it is not an explanation for songs playing or not playing. The folder map lists a `make_radio_volume_patch.py` under `F34Radio Reports/scripts`; that it generates this plugin is a guess from the name — not opened.
28. ▲v5.2 **Guard ESP unchanged:** the v1.1 package's `F34_GNR_Guard.esp` is byte-identical to the earlier ESP (SHA-256 `b0f31855…`); do not describe v1.1 as "a new ESP".

---

---

## 10. Recommended next steps (merged, in order)

▲v5.2 status as of 21 Nov: **testing stopped by the user.** Step 1 was acted on (v0.2 superseded by v1.1). Step 2 was done (v0.3 built, reported). Steps 3–9 are open. Add before step 3: **(a)** extract the stored `SongsPlayed`/`SongIntro`/history from the 18 Nov `New_save` and from Save 11 with a proper save parser (or ask the user for a different read-out) so a first reading of 2 can be traced to the save; **(b)** a v1.1-style build with a `LogOnly` switch and `SongIntro` + four-slot history logging.

1. **Stop distributing v0.2.** Tell testers it is an experiment that writes the counter and also resets the valid value 2 immediately. Do not ship its README as is (§6.4).
2. **Build v0.3, monitor-only (never writes).** Specification (originally not written; ▲v5.2: built 20 Nov per user, not seen):
   - poll every 1 s; log whenever *any* monitored field changes: `SongsPlayed`, `SongIntro`, `LastSongPlayed`–`LastSongPlayed4`, `LastNews`, `LastGreeting`, `LastGreeting2`, `ThreeDogDead`;
   - on every line: `GetQuestRunning`/`IsRunning` of the GNR quest, worldspace and cell, `Utility.GetCurrentRealTime()`;
   - when `SongsPlayed` rises by more than 2 between polls, log the rate and a running count (marks a runaway);
   - log the object's own identity once at start and a counter of `OnInit` calls (tests the double-start idea);
   - log `OnPlayerLoadGame` and fast-travel/cell changes;
   - no `SetPropertyValue`, no resets; keep the date/time-stamp format.
   *Expectations to judge it by:* a fragment loop should show the counter rising ~once per second together with history filling with one song; an external writer may look irregular; two instances would show `OnInit` count 2.
3. **Controlled runs, one change at a time** (same load order, same listening time, log attached): (a) new game, monitor-only, no radio plugins; (b) the tester's pre-existing save, monitor-only; (c) Reliable 01 (Save 11) with and without A2 / A3 per Claude A's matrix, fresh reload each time, timed, songs counted; (d) new game with `F34_RadioFix.esp` + its sound folder (from the developer; not redistributed), monitor-only; (e) the same existing save with the fix. Record songs heard **by name**, whether the radio went silent, and whether Three Dog changed topic mid-news. ▲v5.2: add (f) the 18 Nov `New_save`, monitor-only, long enough to pass an N5/N66 point, then the same with v1.1.
4. **Ask the tester/user what is missing:** which save was used; plugin list; whether `F34_RadioFix.esp` or any other radio plugin was enabled; what "changes topics halfway through the news" sounded like; what they were doing ("standby") and hearing at 10:43:39 and 11:20:02; the user's own v0.2 log. ▲v5.2: also the v0.3 files and log; which songs were heard on 21 Nov; whether the radio had been played on the 18 Nov save before 21 Nov.
5. **Fix the duplicate-start question** by an `OnInit` counter that survives (the v1.1 counter reads `#1` twice, so it is per-object) and by confirming the quest's flags in the CK (Run Once off).
6. **Finish the data mapping** (assistant can do this when the files are in the folder): name songs 13–20 with `song_fragment_map.py`; read the 49 reset fragments not yet opened (only 3 of 52 were read directly); check whether the dev's `.fuz` set covers all 48 scene-A INFOs; compare the originals' speakers.
7. **Ask the developer:** does the speaker/`.fuz` requirement apply to GNR songs given the scenes' direct Play Sound actions; why only scene A's song topic is overridden; can users run the fix tool on their own install; is the runaway known; what he sees for the 5/1 alternation.
8. **Resume the caller search** if `scripts.zip` (or a fresh extraction of compiled scripts) is supplied: separate definitions, references and real call sites for `F34_QSnap` / `F34_QRestore`; reconcile with the 56 CG02/CG03 callers. Also find what enables the transmitters.
9. **Only then design the final repair.** Rules: leave 0/1 untouched (▲v5.2: 2 untouched for up to 30 s — item 23); act on < 0 or > 2; do **not** blindly write 0 without checking the history effect (normal resets also update history; a write of 0 can desync counter and history) — ▲v5.2: v1.1 does write 0, the user chose it provisionally; do not touch `SongIntro` or history unless source evidence requires; no repair loops (a runaway climbs several counts per second and would fight a guard — find the loop first; v1.1's 10-recovery backoff is a partial safeguard); do nothing and log if the quest or script cannot be resolved; separate ESP, never edit `Fallout34.esm`; diagnostic mode first. Test on **disposable save copies** with the matrix below. Reload and removal behaviour must be tested.

**Repair test matrix:**

| Counter on load | Expected |
|---|---|
| −1 | detect invalid; apply the approved recovery only |
| 0, 1 | no intervention |
| 2 | ▲v5.2: no intervention for up to 30 s; allow the normal reset route; if still 2 after 30 s the current candidate writes 0 (to be validated) |
| 3, 5, large | detect invalid; apply the approved recovery |

For each: value after recovery; song eligibility; one song plays and completes; history coherent and no immediate repeat; Three Dog and scene flow normal; no repeated resets; reload does not reintroduce the fault; a clean new save leaves the guard inactive.

---

---

## 11. What is still unknown (merged, de-duplicated)

**About the counter and cause**
1. What does `SongsPlayed` read *at the moment* song INFOs are evaluated on Reliable 01? (Save 11 file says 5; never measured live.)
2. How did Save 11 reach 5? Is it related to the tester's saves?
3. What writes the counter many times per second (1596 first poll; 67 on a new save)? Fragment loop, restore, or something else? Does it happen with **no** guard?
4. Why do songs 5 and 1 alternate for ~25 minutes despite the history check?
5. What triggered the 10:43:39 episode? (Tester was "standby".)
6. Which tuples are real separate states (H2)?
7. Do `SetPropertyValue` writes always persist? (Two reads-after-write showed 1; v1.1's two read-backs showed 0.)
8. Why do two "started" lines appear (same second, 13 s apart, 3 s apart in v1.1; v1.1 prints `#1` both times)?
9. Does `F34_QRestore` ever run against the GNR quest? Caller search unfinished; `scripts.zip` missing.
10. Does anything outside the 639 GNR fragments write `SongsPlayed`?
25. ▲v5.2 What counter, `SongIntro` and history are stored in the 18 Nov `New_save` (the v1.1 run read 2 first), and in the "virgin save" of the v0.3 report? Why 2 on a save with ~2 minutes of play?
26. ▲v5.2 How long would a natural 2 last with no guard — does the N5/N66 reset offer ever arrive from it (H8)?
27. ▲v5.2 Does writing 0 desync the four-slot history or `SongIntro`? (v1.1 does not log them.)

**About tests**
11. Was Reliable 01 freshly reloaded before each A-run? Exact minutes / songs per run?
12. Which save and duration were used when the user reported "songs works" with v0.2? The user's own v0.2 log?
13. Which of the tester's songs were actually audible at the odd times? (A history entry does not prove a song was heard.)
14. What exactly is "Three Dog changes topic halfway through the news"?
15. Does Reliable 01 reach the N5/N66 reset offers in-game? Do House radio songs play (they share 12 of 20 sound descriptors)?
16. Was the SHA-256 of the user's `Fallout34.esm` ever checked (size matches)?
28. ▲v5.2 Which songs (by name) were heard in the 21 Nov run? Had the radio been played on that save before 21 Nov?
29. ▲v5.2 What do the guard v0.3 source/log contain (poll interval, fields, hashes)? What was the "virgin save" (which file)?

**About structure**
17. Which script or mechanism enables a transmitter at runtime, and which one?
18. Audio path: scene "Play Sound" actions, song INFOs, or both? Does GNR need the speaker/`.fuz` approach? Original content of the 48 INFOs?
19. Why does the dev's fix cover scene A's 48 song INFOs but not scene B's?
20. Do silent INFOs with "Start Scene on End" end properly in Fallout 4?
21. Do Three Dog's intro lines match the S61/S72 song-number mapping?
22. Which 12 files made up the earlier Gist; what is the 13-file `Source_Exports/` mapping?
23. What value do the other 49 reset fragments assign (only 3 of 52 read directly)?
24. Is the `.esp` quest flag word really "Start Game Enabled on, Run Once off"?
30. ▲v5.2 What does `GNR_SongVolumehigh_volume.esp` change relative to the master (needs `Fallout34.esm`); where does it sit in the user's load order; does any other plugin override the same 20 descriptors; is it generated by `make_radio_volume_patch.py`?

---

---

## 12. Cautions and working rules

- ▲v5.2 Do not call 2 invalid at once. A 2 is a normal transient (the counter reaches it naturally), but a **persistent** 2 is suspected to stall songs (H8, unproven). Do not reset on `>= 2` immediately; v1.1's 30 s wait is the user's provisional rule.
- Do not treat guard runs as controlled tests: v0.2 and v1.1 write and perturb what they observe. Use monitor-only builds for diagnosis.
- Do not infer a cause from "it works" without logs, save names and durations. ▲v5.2: the 21 Nov run has a log, a save name and a song count but **no baseline and no song names**.
- Do not use New Vegas material (`ba2_radio_report.txt`, `ba2_voice_report.txt`, `radio_dump.txt`, `F34_RadioFixNV.esp`) as evidence for GNR; `fo4_radio_lookup.txt` and `gistfile1.txt` of the old set are Fallout 4 comparison material only.
- Do not say a file was read unless it was opened and checked to its end; do not treat names, summaries or snippets as substitutes.
- Do not create or edit another diagnostic ESP until the original implementation and evidence are understood; change one variable at a time.
- Keep apart: record overrides, master-file edits, save-state changes, runtime behaviour.
- A log that records only on one field's change hides other changes. "No log line" ≠ "nothing happened".
- The song-name map depends on counting phase indexes in a text export; spot-check a few rows in FO4Edit.
- `radiofix.rar` audio is converted game content; do not repost it or attach it to a public thread. ▲v5.2: the same applies to third-party plugins such as `GNR_SongVolumehigh_volume.esp` (author cloakarx) — described here, **not** included in the v5.2 zip.
- Keep original ZIPs and ESM files unchanged; work on copies; never experiment on the only copy of Reliable 01 or the 18 Nov test save.
- An ESP patch does not rewrite the ESM; disabling it does not undo values already stored in a save. A save keeps quest-variable values and running-scene state. Fallout 4 makes an automatic `exitsave` on quit; the user avoids loading it in tests.
- Do not rebuild or reconvert a clean Fallout 4 installation yet.

---

---

## 13. Test-log template (copy one block per run; write "not recorded" rather than guessing)

```
Date/time (and whose clock):
Save used (exact filename; new game / pre-existing / Reliable 01 = Save 11 / New_save 18 Nov):
Was the original source save freshly loaded for this run? (yes/no/not recorded):
ESM used (name + size + SHA-256 if available):
Enabled diagnostic test ESP (none/A0/A1/A2/A3/TestA/TestB):
Guard build (none/v0.1/v0.2/v0.3/v1.1) and ESP size/hash; does it write? (v0.3 must say "monitor only"):
Script count on the guard quest (should be 1):
Radio plugins enabled (F34_RadioFix.esp / NV / GNR_Everywhere / GNR No Static / GNR_SongVolumehigh_volume / Platinum Radio / A-tests) and their load-order positions:
Other enabled patches and relevant load-order entries:
Was exitsave disabled/avoided? (yes/no):
Had the radio been played on this save before? (yes/no/not recorded):
Time listened (minutes):
Songs heard (count, and BY NAME):
What the player was doing at each log timestamp (idle/standby, fast travel, interior, loading a save):
What was heard at those times:
Three Dog dialogue continued? Did he change topic mid-news? When / what changed:
Did music stop or the radio become abnormal later? (describe / time / song count):
Did the result repeat on a second fresh load? (yes/no/not tested):
Attach the full F34_GNR_Guard.0.log:
Notes:
```

---

## 14. Glossary

**ESM / ESP** main plugin vs patch plugin (a patch overrides records while enabled; it does not rewrite the ESM). **Save state** values and running state stored in a save. **Scene** ordered phases controlling when the radio waits, talks, plays or hands over. **DIAL / INFO** dialogue topic / dialogue response record; song INFOs are silent. **TIF / fragment** a small Papyrus script attached to a topic INFO. **Papyrus** the scripting language; **PEX** compiled, **PSC** source, **PAS** bytecode listing. **FO4Edit / xEdit** plugin inspection tool. **CTDA** a condition entry. **`SongsPlayed`** the counter (valid 0,1,2). **`LastSongPlayed`–`4`** four-slot recent-song history. **`SongIntro`** variable used by the intro sequence. **Guard** the experimental `F34_GNR_Guard` ESP + script (v0.1 … v1.1). **Stuck 2** ▲v5.2 a counter value of 2 unchanged for 30 s (v1.1's trigger; hypothesis H8). **SNDR** sound-descriptor record. **VMAD / DNAM** a record's script data / flags subrecords. **`.fuz`** Fallout 4 voice file (audio + lip data).

---

## 15–16. Moved

How to start a follow-up session → `GNR_00_START_HERE_v5.2.md`. The v5.0 evidence-ledger table was dropped as redundant with the inline labels and §0; it is in the archive.

*End of Master 1.*
