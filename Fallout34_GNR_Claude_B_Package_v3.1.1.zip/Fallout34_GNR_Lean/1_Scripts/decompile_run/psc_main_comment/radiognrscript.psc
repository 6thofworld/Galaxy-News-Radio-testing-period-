;/ Decompiled by Champollion V1.0.6
PEX format v3.9 GameID: 2
Source   : RadioGNRScript.psc
Modified : 2020-09-13 17:56:40
Compiled : 2020-09-13 17:56:40
User     : f34
Computer : papyrus.py
/;
ScriptName F3:RadioGNRScript extends Quest conditional
{ Fallout 3 script RadioGNRScript (SCPT 00057B31, quest) translated by f34.geck. Fix the translator, not this file. }

;-- Properties --------------------------------------
int Property DashwoodVar Auto conditional
int Property PSAVar Auto conditional
int Property PSANum Auto conditional
int Property DadStoryVar Auto conditional
int Property NewsStoryVar Auto conditional
int Property TitleHopeVar Auto conditional
int Property TitleScourgeVar Auto conditional
int Property TitleParadigmVar Auto conditional
int Property ExploitVar Auto conditional
int Property SongIntro Auto conditional
int Property LastSongPlayed Auto conditional
int Property LastSongPlayed2 Auto conditional
int Property LastSongPlayed3 Auto conditional
int Property LastSongPlayed4 Auto conditional
int Property LastNews Auto conditional
int Property LastPSA Auto conditional
int Property LastGreeting Auto conditional
int Property LastGreeting2 Auto conditional
int Property SongsPlayed Auto conditional
int Property ThreeDogDead Auto conditional
int Property BadDoesGood Auto conditional
int Property GoodDoesBad Auto conditional
int Property DashwoodEp Auto conditional
float Property CG04Done Auto conditional
float Property MQ01Clear Auto conditional
float Property MQ02Clear Auto conditional
float Property MQ03Clear Auto conditional
float Property MQ04Clear Auto conditional
float Property MQ05Clear Auto conditional
float Property MQ06Clear Auto conditional
float Property MQ07Clear Auto conditional
float Property MQ08Clear Auto conditional
float Property MQ09Clear Auto conditional
float Property MS01Clear Auto conditional
float Property MS02Clear Auto conditional
float Property MS03Clear Auto conditional
float Property MS04Clear Auto conditional
float Property MS05Clear Auto conditional
float Property MS06Clear Auto conditional
float Property MS08Clear Auto conditional
float Property MS09Clear Auto conditional
float Property MS10Clear Auto conditional
float Property MS11Clear Auto conditional
float Property MS12Clear Auto conditional
float Property MS14Clear Auto conditional
float Property MS15Clear Auto conditional
float Property MS16Clear Auto conditional
float Property MS17Clear Auto conditional
float Property MS18Clear Auto conditional
int Property ExploitReady Auto conditional
float Property MQ11Clear Auto conditional
float Property DLC03BS1Clear Auto conditional
float Property DLC03BS2Clear Auto conditional
float Property DLC03BS3Clear Auto conditional
Quest Property MS08 Auto Const
Actor Property HarknessRef Auto Const
GlobalVariable Property GameDaysPassed Auto Const

;-- Variables ---------------------------------------
; int ::DashwoodVar_var conditional
; int ::PSAVar_var conditional
; int ::PSANum_var conditional
; int ::DadStoryVar_var conditional
; int ::NewsStoryVar_var conditional
; int ::TitleHopeVar_var conditional
; int ::TitleScourgeVar_var conditional
; int ::TitleParadigmVar_var conditional
; int ::ExploitVar_var conditional
; int ::SongIntro_var conditional
; int ::LastSongPlayed_var conditional
; int ::LastSongPlayed2_var conditional
; int ::LastSongPlayed3_var conditional
; int ::LastSongPlayed4_var conditional
; int ::LastNews_var conditional
; int ::LastPSA_var conditional
; int ::LastGreeting_var conditional
; int ::LastGreeting2_var conditional
; int ::SongsPlayed_var conditional
; int ::ThreeDogDead_var conditional
; int ::BadDoesGood_var conditional
; int ::GoodDoesBad_var conditional
; int ::DashwoodEp_var conditional
; float ::CG04Done_var conditional
; float ::MQ01Clear_var conditional
; float ::MQ02Clear_var conditional
; float ::MQ03Clear_var conditional
; float ::MQ04Clear_var conditional
; float ::MQ05Clear_var conditional
; float ::MQ06Clear_var conditional
; float ::MQ07Clear_var conditional
; float ::MQ08Clear_var conditional
; float ::MQ09Clear_var conditional
; float ::MS01Clear_var conditional
; float ::MS02Clear_var conditional
; float ::MS03Clear_var conditional
; float ::MS04Clear_var conditional
; float ::MS05Clear_var conditional
; float ::MS06Clear_var conditional
; float ::MS08Clear_var conditional
; float ::MS09Clear_var conditional
; float ::MS10Clear_var conditional
; float ::MS11Clear_var conditional
; float ::MS12Clear_var conditional
; float ::MS14Clear_var conditional
; float ::MS15Clear_var conditional
; float ::MS16Clear_var conditional
; float ::MS17Clear_var conditional
; float ::MS18Clear_var conditional
; int ::ExploitReady_var conditional
; float ::MQ11Clear_var conditional
; float ::DLC03BS1Clear_var conditional
; float ::DLC03BS2Clear_var conditional
; float ::DLC03BS3Clear_var conditional
; Quest ::MS08_var Const
; Actor ::HarknessRef_var Const
; GlobalVariable ::GameDaysPassed_var Const
float F34_TickDelay = 5
float F34_SecondsPassed
float F34_LastTick
bool F34_Ticking
float F34_TickStart
bool F34_OwnWorld = True
float F34_OwnWorldAt
float F34_FragUntil

;-- Functions ---------------------------------------

Event OnQuestInit()
	;None ::nonevar
	
	; 000 : callmethod StartTimer self ::nonevar F34_TickDelay 1 
	Self.StartTimer(F34_TickDelay, 1)
EndEvent

Event OnQuestShutdown()
	;None ::nonevar
	
	; 000 : callmethod CancelTimer self ::nonevar 1 
	Self.CancelTimer(1)
EndEvent

Event OnTimer(int aiTimerID)
	;Bool ::temp0
	;Bool ::temp1
	;None ::nonevar
	;Float ::temp2
	
	; 000 : cmp_eq ::temp0 aiTimerID 1 
	; 001 : jmpf ::temp0 064
	If (aiTimerID == 1)
		; 002 : callmethod IsRunning self ::temp0 
		; 003 : not ::temp1 ::temp0 
		; 004 : jmpf ::temp1 007
		If (!Self.IsRunning())
			; 005 : return None 
			return 
		; 006 : jmp 007
		EndIf
		; 007 : callmethod StartTimer self ::nonevar F34_TickDelay 1 
		Self.StartTimer(F34_TickDelay, 1)
		; 008 : callmethod F34_InOwnWorld self ::temp0 
		; 009 : not ::temp1 ::temp0 
		; 010 : jmpf ::temp1 013
		If (!Self.F34_InOwnWorld())
			; 011 : return None 
			return 
		; 012 : jmp 013
		EndIf
		; 013 : cmp_gt ::temp0 F34_FragUntil 0 
		; 014 : jmpf ::temp0 027
		If (F34_FragUntil > 0)
			; 015 : callstatic Utility GetCurrentRealTime F34_FragNow 
			float F34_FragNow = Utility.GetCurrentRealTime()
			; 016 : cmp_lt ::temp1 F34_FragNow F34_FragUntil 
			; 017 : cast ::temp0 ::temp1 
			; 018 : jmpf ::temp0 022
			; 019 : fsub ::temp2 F34_FragUntil 5 
			; 020 : cmp_gt ::temp1 F34_FragNow ::temp2 
			; 021 : cast ::temp0 ::temp1 
			; 022 : jmpf ::temp0 025
			If (F34_FragNow < F34_FragUntil && F34_FragNow > F34_FragUntil - 5)
				; 023 : return None 
				return 
			; 024 : jmp 025
			EndIf
			; 025 : assign F34_FragUntil 0 
			F34_FragUntil = 0
		; 026 : jmp 027
		EndIf
		; 027 : callstatic Utility GetCurrentRealTime F34_Now 
		float F34_Now = Utility.GetCurrentRealTime()
		; 028 : cast ::temp1 F34_Ticking 
		; 029 : jmpf ::temp1 033
		; 030 : fsub ::temp2 F34_Now F34_TickStart 
		; 031 : cmp_gt ::temp0 ::temp2 -1 
		; 032 : cast ::temp1 ::temp0 
		; 033 : cast ::temp0 ::temp1 
		; 034 : jmpf ::temp0 038
		; 035 : fsub ::temp2 F34_Now F34_TickStart 
		; 036 : cmp_lt ::temp1 ::temp2 10 
		; 037 : cast ::temp0 ::temp1 
		; 038 : jmpf ::temp0 041
		If (F34_Ticking && F34_Now - F34_TickStart > -1 && F34_Now - F34_TickStart < 10)
			; 039 : return None 
			return 
		; 040 : jmp 041
		EndIf
		; 041 : assign F34_Ticking True 
		F34_Ticking = True
		; 042 : assign F34_TickStart F34_Now 
		F34_TickStart = F34_Now
		; 043 : assign F34_SecondsPassed F34_TickDelay 
		F34_SecondsPassed = F34_TickDelay
		; 044 : cmp_lt ::temp1 F34_TickDelay 0.1 
		; 045 : cast ::temp0 ::temp1 
		; 046 : jmpf ::temp0 049
		; 047 : cmp_gt ::temp1 F34_LastTick 0 
		; 048 : cast ::temp0 ::temp1 
		; 049 : cast ::temp1 ::temp0 
		; 050 : jmpf ::temp1 053
		; 051 : cmp_gt ::temp0 F34_Now F34_LastTick 
		; 052 : cast ::temp1 ::temp0 
		; 053 : jmpf ::temp1 060
		If (F34_TickDelay < 0.1 && F34_LastTick > 0 && F34_Now > F34_LastTick)
			; 054 : fsub F34_SecondsPassed F34_Now F34_LastTick 
			F34_SecondsPassed = F34_Now - F34_LastTick
			; 055 : cmp_gt ::temp0 F34_SecondsPassed 1 
			; 056 : jmpf ::temp0 059
			If (F34_SecondsPassed > 1)
				; 057 : assign F34_SecondsPassed 1 
				F34_SecondsPassed = 1
			; 058 : jmp 059
			EndIf
		; 057 : assign F34_SecondsPassed 1 
		EndIf
		; 060 : assign F34_LastTick F34_Now 
		F34_LastTick = F34_Now
		; 061 : callmethod F34_GameModeTick self ::nonevar 
		Self.F34_GameModeTick()
		; 062 : assign F34_Ticking False 
		F34_Ticking = False
	; 063 : jmp 064
	EndIf
EndEvent

int Function F34_Add_DadStoryVar(int afDelta)
{ GNR3: another script's 'set <this>.dadstoryvar to <this>.dadstoryvar + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::DadStoryVar_var ::DadStoryVar_var afDelta 
	DadStoryVar += afDelta
	; 001 : return ::DadStoryVar_var 
	return DadStoryVar
EndFunction

int Function F34_Add_DashwoodVar(int afDelta)
{ GNR3: another script's 'set <this>.dashwoodvar to <this>.dashwoodvar + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::DashwoodVar_var ::DashwoodVar_var afDelta 
	DashwoodVar += afDelta
	; 001 : return ::DashwoodVar_var 
	return DashwoodVar
EndFunction

int Function F34_Add_ExploitVar(int afDelta)
{ GNR3: another script's 'set <this>.exploitvar to <this>.exploitvar + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::ExploitVar_var ::ExploitVar_var afDelta 
	ExploitVar += afDelta
	; 001 : return ::ExploitVar_var 
	return ExploitVar
EndFunction

int Function F34_Add_NewsStoryVar(int afDelta)
{ GNR3: another script's 'set <this>.newsstoryvar to <this>.newsstoryvar + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::NewsStoryVar_var ::NewsStoryVar_var afDelta 
	NewsStoryVar += afDelta
	; 001 : return ::NewsStoryVar_var 
	return NewsStoryVar
EndFunction

int Function F34_Add_PSAVar(int afDelta)
{ GNR3: another script's 'set <this>.psavar to <this>.psavar + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::PSAVar_var ::PSAVar_var afDelta 
	PSAVar += afDelta
	; 001 : return ::PSAVar_var 
	return PSAVar
EndFunction

int Function F34_Add_SongsPlayed(int afDelta)
{ GNR3: another script's 'set <this>.songsplayed to <this>.songsplayed + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::SongsPlayed_var ::SongsPlayed_var afDelta 
	SongsPlayed += afDelta
	; 001 : return ::SongsPlayed_var 
	return SongsPlayed
EndFunction

int Function F34_Add_TitleHopeVar(int afDelta)
{ GNR3: another script's 'set <this>.titlehopevar to <this>.titlehopevar + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::TitleHopeVar_var ::TitleHopeVar_var afDelta 
	TitleHopeVar += afDelta
	; 001 : return ::TitleHopeVar_var 
	return TitleHopeVar
EndFunction

int Function F34_Add_TitleParadigmVar(int afDelta)
{ GNR3: another script's 'set <this>.titleparadigmvar to <this>.titleparadigmvar + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::TitleParadigmVar_var ::TitleParadigmVar_var afDelta 
	TitleParadigmVar += afDelta
	; 001 : return ::TitleParadigmVar_var 
	return TitleParadigmVar
EndFunction

int Function F34_Add_TitleScourgeVar(int afDelta)
{ GNR3: another script's 'set <this>.titlescourgevar to <this>.titlescourgevar + n' in one locked call (no lost steps) }
	
	; 000 : iadd ::TitleScourgeVar_var ::TitleScourgeVar_var afDelta 
	TitleScourgeVar += afDelta
	; 001 : return ::TitleScourgeVar_var 
	return TitleScourgeVar
EndFunction

var[] Function F34_QSnap()
{ T125: this quest's FO3 variables, read before the quest is started (a first start re-initialises them) }
	;Var ::temp3
	
	; 000 : array_create F34_qa 54 
	var[] F34_qa = new var[54]
	; 001 : cast ::temp3 ::DashwoodVar_var 
	; 002 : array_setelement F34_qa 0 ::temp3 
	F34_qa[0] = DashwoodVar as var
	; 003 : cast ::temp3 ::PSAVar_var 
	; 004 : array_setelement F34_qa 1 ::temp3 
	F34_qa[1] = PSAVar as var
	; 005 : cast ::temp3 ::PSANum_var 
	; 006 : array_setelement F34_qa 2 ::temp3 
	F34_qa[2] = PSANum as var
	; 007 : cast ::temp3 ::DadStoryVar_var 
	; 008 : array_setelement F34_qa 3 ::temp3 
	F34_qa[3] = DadStoryVar as var
	; 009 : cast ::temp3 ::NewsStoryVar_var 
	; 010 : array_setelement F34_qa 4 ::temp3 
	F34_qa[4] = NewsStoryVar as var
	; 011 : cast ::temp3 ::TitleHopeVar_var 
	; 012 : array_setelement F34_qa 5 ::temp3 
	F34_qa[5] = TitleHopeVar as var
	; 013 : cast ::temp3 ::TitleScourgeVar_var 
	; 014 : array_setelement F34_qa 6 ::temp3 
	F34_qa[6] = TitleScourgeVar as var
	; 015 : cast ::temp3 ::TitleParadigmVar_var 
	; 016 : array_setelement F34_qa 7 ::temp3 
	F34_qa[7] = TitleParadigmVar as var
	; 017 : cast ::temp3 ::ExploitVar_var 
	; 018 : array_setelement F34_qa 8 ::temp3 
	F34_qa[8] = ExploitVar as var
	; 019 : cast ::temp3 ::SongIntro_var 
	; 020 : array_setelement F34_qa 9 ::temp3 
	F34_qa[9] = SongIntro as var
	; 021 : cast ::temp3 ::LastSongPlayed_var 
	; 022 : array_setelement F34_qa 10 ::temp3 
	F34_qa[10] = LastSongPlayed as var
	; 023 : cast ::temp3 ::LastSongPlayed2_var 
	; 024 : array_setelement F34_qa 11 ::temp3 
	F34_qa[11] = LastSongPlayed2 as var
	; 025 : cast ::temp3 ::LastSongPlayed3_var 
	; 026 : array_setelement F34_qa 12 ::temp3 
	F34_qa[12] = LastSongPlayed3 as var
	; 027 : cast ::temp3 ::LastSongPlayed4_var 
	; 028 : array_setelement F34_qa 13 ::temp3 
	F34_qa[13] = LastSongPlayed4 as var
	; 029 : cast ::temp3 ::LastNews_var 
	; 030 : array_setelement F34_qa 14 ::temp3 
	F34_qa[14] = LastNews as var
	; 031 : cast ::temp3 ::LastPSA_var 
	; 032 : array_setelement F34_qa 15 ::temp3 
	F34_qa[15] = LastPSA as var
	; 033 : cast ::temp3 ::LastGreeting_var 
	; 034 : array_setelement F34_qa 16 ::temp3 
	F34_qa[16] = LastGreeting as var
	; 035 : cast ::temp3 ::LastGreeting2_var 
	; 036 : array_setelement F34_qa 17 ::temp3 
	F34_qa[17] = LastGreeting2 as var
	; 037 : cast ::temp3 ::SongsPlayed_var 
	; 038 : array_setelement F34_qa 18 ::temp3 
	F34_qa[18] = SongsPlayed as var
	; 039 : cast ::temp3 ::ThreeDogDead_var 
	; 040 : array_setelement F34_qa 19 ::temp3 
	F34_qa[19] = ThreeDogDead as var
	; 041 : cast ::temp3 ::BadDoesGood_var 
	; 042 : array_setelement F34_qa 20 ::temp3 
	F34_qa[20] = BadDoesGood as var
	; 043 : cast ::temp3 ::GoodDoesBad_var 
	; 044 : array_setelement F34_qa 21 ::temp3 
	F34_qa[21] = GoodDoesBad as var
	; 045 : cast ::temp3 ::DashwoodEp_var 
	; 046 : array_setelement F34_qa 22 ::temp3 
	F34_qa[22] = DashwoodEp as var
	; 047 : cast ::temp3 ::CG04Done_var 
	; 048 : array_setelement F34_qa 23 ::temp3 
	F34_qa[23] = CG04Done as var
	; 049 : cast ::temp3 ::MQ01Clear_var 
	; 050 : array_setelement F34_qa 24 ::temp3 
	F34_qa[24] = MQ01Clear as var
	; 051 : cast ::temp3 ::MQ02Clear_var 
	; 052 : array_setelement F34_qa 25 ::temp3 
	F34_qa[25] = MQ02Clear as var
	; 053 : cast ::temp3 ::MQ03Clear_var 
	; 054 : array_setelement F34_qa 26 ::temp3 
	F34_qa[26] = MQ03Clear as var
	; 055 : cast ::temp3 ::MQ04Clear_var 
	; 056 : array_setelement F34_qa 27 ::temp3 
	F34_qa[27] = MQ04Clear as var
	; 057 : cast ::temp3 ::MQ05Clear_var 
	; 058 : array_setelement F34_qa 28 ::temp3 
	F34_qa[28] = MQ05Clear as var
	; 059 : cast ::temp3 ::MQ06Clear_var 
	; 060 : array_setelement F34_qa 29 ::temp3 
	F34_qa[29] = MQ06Clear as var
	; 061 : cast ::temp3 ::MQ07Clear_var 
	; 062 : array_setelement F34_qa 30 ::temp3 
	F34_qa[30] = MQ07Clear as var
	; 063 : cast ::temp3 ::MQ08Clear_var 
	; 064 : array_setelement F34_qa 31 ::temp3 
	F34_qa[31] = MQ08Clear as var
	; 065 : cast ::temp3 ::MQ09Clear_var 
	; 066 : array_setelement F34_qa 32 ::temp3 
	F34_qa[32] = MQ09Clear as var
	; 067 : cast ::temp3 ::MS01Clear_var 
	; 068 : array_setelement F34_qa 33 ::temp3 
	F34_qa[33] = MS01Clear as var
	; 069 : cast ::temp3 ::MS02Clear_var 
	; 070 : array_setelement F34_qa 34 ::temp3 
	F34_qa[34] = MS02Clear as var
	; 071 : cast ::temp3 ::MS03Clear_var 
	; 072 : array_setelement F34_qa 35 ::temp3 
	F34_qa[35] = MS03Clear as var
	; 073 : cast ::temp3 ::MS04Clear_var 
	; 074 : array_setelement F34_qa 36 ::temp3 
	F34_qa[36] = MS04Clear as var
	; 075 : cast ::temp3 ::MS05Clear_var 
	; 076 : array_setelement F34_qa 37 ::temp3 
	F34_qa[37] = MS05Clear as var
	; 077 : cast ::temp3 ::MS06Clear_var 
	; 078 : array_setelement F34_qa 38 ::temp3 
	F34_qa[38] = MS06Clear as var
	; 079 : cast ::temp3 ::MS08Clear_var 
	; 080 : array_setelement F34_qa 39 ::temp3 
	F34_qa[39] = MS08Clear as var
	; 081 : cast ::temp3 ::MS09Clear_var 
	; 082 : array_setelement F34_qa 40 ::temp3 
	F34_qa[40] = MS09Clear as var
	; 083 : cast ::temp3 ::MS10Clear_var 
	; 084 : array_setelement F34_qa 41 ::temp3 
	F34_qa[41] = MS10Clear as var
	; 085 : cast ::temp3 ::MS11Clear_var 
	; 086 : array_setelement F34_qa 42 ::temp3 
	F34_qa[42] = MS11Clear as var
	; 087 : cast ::temp3 ::MS12Clear_var 
	; 088 : array_setelement F34_qa 43 ::temp3 
	F34_qa[43] = MS12Clear as var
	; 089 : cast ::temp3 ::MS14Clear_var 
	; 090 : array_setelement F34_qa 44 ::temp3 
	F34_qa[44] = MS14Clear as var
	; 091 : cast ::temp3 ::MS15Clear_var 
	; 092 : array_setelement F34_qa 45 ::temp3 
	F34_qa[45] = MS15Clear as var
	; 093 : cast ::temp3 ::MS16Clear_var 
	; 094 : array_setelement F34_qa 46 ::temp3 
	F34_qa[46] = MS16Clear as var
	; 095 : cast ::temp3 ::MS17Clear_var 
	; 096 : array_setelement F34_qa 47 ::temp3 
	F34_qa[47] = MS17Clear as var
	; 097 : cast ::temp3 ::MS18Clear_var 
	; 098 : array_setelement F34_qa 48 ::temp3 
	F34_qa[48] = MS18Clear as var
	; 099 : cast ::temp3 ::ExploitReady_var 
	; 100 : array_setelement F34_qa 49 ::temp3 
	F34_qa[49] = ExploitReady as var
	; 101 : cast ::temp3 ::MQ11Clear_var 
	; 102 : array_setelement F34_qa 50 ::temp3 
	F34_qa[50] = MQ11Clear as var
	; 103 : cast ::temp3 ::DLC03BS1Clear_var 
	; 104 : array_setelement F34_qa 51 ::temp3 
	F34_qa[51] = DLC03BS1Clear as var
	; 105 : cast ::temp3 ::DLC03BS2Clear_var 
	; 106 : array_setelement F34_qa 52 ::temp3 
	F34_qa[52] = DLC03BS2Clear as var
	; 107 : cast ::temp3 ::DLC03BS3Clear_var 
	; 108 : array_setelement F34_qa 53 ::temp3 
	F34_qa[53] = DLC03BS3Clear as var
	; 109 : return F34_qa 
	return F34_qa
EndFunction

Function F34_QRestore(var[] F34_qa)
{ T125: after the quest start: a variable that was set before and is back to 0 gets its value again }
	;Var ::temp4
	;Bool ::temp5
	;Bool ::temp6
	
	; 000 : array_getlement ::temp4 F34_qa 0 
	; 001 : cast F34_qs0 ::temp4 
	int F34_qs0 = F34_qa[0] as int
	; 002 : cmp_eq ::temp5 F34_qs0 0 
	; 003 : not ::temp5 ::temp5 
	; 004 : cast ::temp6 ::temp5 
	; 005 : jmpf ::temp6 008
	; 006 : cmp_eq ::temp5 ::DashwoodVar_var 0 
	; 007 : cast ::temp6 ::temp5 
	; 008 : jmpf ::temp6 011
	If (F34_qs0 != 0 && DashwoodVar == 0)
		; 009 : assign ::DashwoodVar_var F34_qs0 
		DashwoodVar = F34_qs0
	; 010 : jmp 011
	EndIf
	; 011 : array_getlement ::temp4 F34_qa 1 
	; 012 : cast F34_qs1 ::temp4 
	int F34_qs1 = F34_qa[1] as int
	; 013 : cmp_eq ::temp5 F34_qs1 0 
	; 014 : not ::temp5 ::temp5 
	; 015 : cast ::temp6 ::temp5 
	; 016 : jmpf ::temp6 019
	; 017 : cmp_eq ::temp5 ::PSAVar_var 0 
	; 018 : cast ::temp6 ::temp5 
	; 019 : jmpf ::temp6 022
	If (F34_qs1 != 0 && PSAVar == 0)
		; 020 : assign ::PSAVar_var F34_qs1 
		PSAVar = F34_qs1
	; 021 : jmp 022
	EndIf
	; 022 : array_getlement ::temp4 F34_qa 2 
	; 023 : cast F34_qs2 ::temp4 
	int F34_qs2 = F34_qa[2] as int
	; 024 : cmp_eq ::temp5 F34_qs2 0 
	; 025 : not ::temp5 ::temp5 
	; 026 : cast ::temp6 ::temp5 
	; 027 : jmpf ::temp6 030
	; 028 : cmp_eq ::temp5 ::PSANum_var 0 
	; 029 : cast ::temp6 ::temp5 
	; 030 : jmpf ::temp6 033
	If (F34_qs2 != 0 && PSANum == 0)
		; 031 : assign ::PSANum_var F34_qs2 
		PSANum = F34_qs2
	; 032 : jmp 033
	EndIf
	; 033 : array_getlement ::temp4 F34_qa 3 
	; 034 : cast F34_qs3 ::temp4 
	int F34_qs3 = F34_qa[3] as int
	; 035 : cmp_eq ::temp5 F34_qs3 0 
	; 036 : not ::temp5 ::temp5 
	; 037 : cast ::temp6 ::temp5 
	; 038 : jmpf ::temp6 041
	; 039 : cmp_eq ::temp5 ::DadStoryVar_var 0 
	; 040 : cast ::temp6 ::temp5 
	; 041 : jmpf ::temp6 044
	If (F34_qs3 != 0 && DadStoryVar == 0)
		; 042 : assign ::DadStoryVar_var F34_qs3 
		DadStoryVar = F34_qs3
	; 043 : jmp 044
	EndIf
	; 044 : array_getlement ::temp4 F34_qa 4 
	; 045 : cast F34_qs4 ::temp4 
	int F34_qs4 = F34_qa[4] as int
	; 046 : cmp_eq ::temp5 F34_qs4 0 
	; 047 : not ::temp5 ::temp5 
	; 048 : cast ::temp6 ::temp5 
	; 049 : jmpf ::temp6 052
	; 050 : cmp_eq ::temp5 ::NewsStoryVar_var 0 
	; 051 : cast ::temp6 ::temp5 
	; 052 : jmpf ::temp6 055
	If (F34_qs4 != 0 && NewsStoryVar == 0)
		; 053 : assign ::NewsStoryVar_var F34_qs4 
		NewsStoryVar = F34_qs4
	; 054 : jmp 055
	EndIf
	; 055 : array_getlement ::temp4 F34_qa 5 
	; 056 : cast F34_qs5 ::temp4 
	int F34_qs5 = F34_qa[5] as int
	; 057 : cmp_eq ::temp5 F34_qs5 0 
	; 058 : not ::temp5 ::temp5 
	; 059 : cast ::temp6 ::temp5 
	; 060 : jmpf ::temp6 063
	; 061 : cmp_eq ::temp5 ::TitleHopeVar_var 0 
	; 062 : cast ::temp6 ::temp5 
	; 063 : jmpf ::temp6 066
	If (F34_qs5 != 0 && TitleHopeVar == 0)
		; 064 : assign ::TitleHopeVar_var F34_qs5 
		TitleHopeVar = F34_qs5
	; 065 : jmp 066
	EndIf
	; 066 : array_getlement ::temp4 F34_qa 6 
	; 067 : cast F34_qs6 ::temp4 
	int F34_qs6 = F34_qa[6] as int
	; 068 : cmp_eq ::temp5 F34_qs6 0 
	; 069 : not ::temp5 ::temp5 
	; 070 : cast ::temp6 ::temp5 
	; 071 : jmpf ::temp6 074
	; 072 : cmp_eq ::temp5 ::TitleScourgeVar_var 0 
	; 073 : cast ::temp6 ::temp5 
	; 074 : jmpf ::temp6 077
	If (F34_qs6 != 0 && TitleScourgeVar == 0)
		; 075 : assign ::TitleScourgeVar_var F34_qs6 
		TitleScourgeVar = F34_qs6
	; 076 : jmp 077
	EndIf
	; 077 : array_getlement ::temp4 F34_qa 7 
	; 078 : cast F34_qs7 ::temp4 
	int F34_qs7 = F34_qa[7] as int
	; 079 : cmp_eq ::temp5 F34_qs7 0 
	; 080 : not ::temp5 ::temp5 
	; 081 : cast ::temp6 ::temp5 
	; 082 : jmpf ::temp6 085
	; 083 : cmp_eq ::temp5 ::TitleParadigmVar_var 0 
	; 084 : cast ::temp6 ::temp5 
	; 085 : jmpf ::temp6 088
	If (F34_qs7 != 0 && TitleParadigmVar == 0)
		; 086 : assign ::TitleParadigmVar_var F34_qs7 
		TitleParadigmVar = F34_qs7
	; 087 : jmp 088
	EndIf
	; 088 : array_getlement ::temp4 F34_qa 8 
	; 089 : cast F34_qs8 ::temp4 
	int F34_qs8 = F34_qa[8] as int
	; 090 : cmp_eq ::temp5 F34_qs8 0 
	; 091 : not ::temp5 ::temp5 
	; 092 : cast ::temp6 ::temp5 
	; 093 : jmpf ::temp6 096
	; 094 : cmp_eq ::temp5 ::ExploitVar_var 0 
	; 095 : cast ::temp6 ::temp5 
	; 096 : jmpf ::temp6 099
	If (F34_qs8 != 0 && ExploitVar == 0)
		; 097 : assign ::ExploitVar_var F34_qs8 
		ExploitVar = F34_qs8
	; 098 : jmp 099
	EndIf
	; 099 : array_getlement ::temp4 F34_qa 9 
	; 100 : cast F34_qs9 ::temp4 
	int F34_qs9 = F34_qa[9] as int
	; 101 : cmp_eq ::temp5 F34_qs9 0 
	; 102 : not ::temp5 ::temp5 
	; 103 : cast ::temp6 ::temp5 
	; 104 : jmpf ::temp6 107
	; 105 : cmp_eq ::temp5 ::SongIntro_var 0 
	; 106 : cast ::temp6 ::temp5 
	; 107 : jmpf ::temp6 110
	If (F34_qs9 != 0 && SongIntro == 0)
		; 108 : assign ::SongIntro_var F34_qs9 
		SongIntro = F34_qs9
	; 109 : jmp 110
	EndIf
	; 110 : array_getlement ::temp4 F34_qa 10 
	; 111 : cast F34_qs10 ::temp4 
	int F34_qs10 = F34_qa[10] as int
	; 112 : cmp_eq ::temp5 F34_qs10 0 
	; 113 : not ::temp5 ::temp5 
	; 114 : cast ::temp6 ::temp5 
	; 115 : jmpf ::temp6 118
	; 116 : cmp_eq ::temp5 ::LastSongPlayed_var 0 
	; 117 : cast ::temp6 ::temp5 
	; 118 : jmpf ::temp6 121
	If (F34_qs10 != 0 && LastSongPlayed == 0)
		; 119 : assign ::LastSongPlayed_var F34_qs10 
		LastSongPlayed = F34_qs10
	; 120 : jmp 121
	EndIf
	; 121 : array_getlement ::temp4 F34_qa 11 
	; 122 : cast F34_qs11 ::temp4 
	int F34_qs11 = F34_qa[11] as int
	; 123 : cmp_eq ::temp5 F34_qs11 0 
	; 124 : not ::temp5 ::temp5 
	; 125 : cast ::temp6 ::temp5 
	; 126 : jmpf ::temp6 129
	; 127 : cmp_eq ::temp5 ::LastSongPlayed2_var 0 
	; 128 : cast ::temp6 ::temp5 
	; 129 : jmpf ::temp6 132
	If (F34_qs11 != 0 && LastSongPlayed2 == 0)
		; 130 : assign ::LastSongPlayed2_var F34_qs11 
		LastSongPlayed2 = F34_qs11
	; 131 : jmp 132
	EndIf
	; 132 : array_getlement ::temp4 F34_qa 12 
	; 133 : cast F34_qs12 ::temp4 
	int F34_qs12 = F34_qa[12] as int
	; 134 : cmp_eq ::temp5 F34_qs12 0 
	; 135 : not ::temp5 ::temp5 
	; 136 : cast ::temp6 ::temp5 
	; 137 : jmpf ::temp6 140
	; 138 : cmp_eq ::temp5 ::LastSongPlayed3_var 0 
	; 139 : cast ::temp6 ::temp5 
	; 140 : jmpf ::temp6 143
	If (F34_qs12 != 0 && LastSongPlayed3 == 0)
		; 141 : assign ::LastSongPlayed3_var F34_qs12 
		LastSongPlayed3 = F34_qs12
	; 142 : jmp 143
	EndIf
	; 143 : array_getlement ::temp4 F34_qa 13 
	; 144 : cast F34_qs13 ::temp4 
	int F34_qs13 = F34_qa[13] as int
	; 145 : cmp_eq ::temp5 F34_qs13 0 
	; 146 : not ::temp5 ::temp5 
	; 147 : cast ::temp6 ::temp5 
	; 148 : jmpf ::temp6 151
	; 149 : cmp_eq ::temp5 ::LastSongPlayed4_var 0 
	; 150 : cast ::temp6 ::temp5 
	; 151 : jmpf ::temp6 154
	If (F34_qs13 != 0 && LastSongPlayed4 == 0)
		; 152 : assign ::LastSongPlayed4_var F34_qs13 
		LastSongPlayed4 = F34_qs13
	; 153 : jmp 154
	EndIf
	; 154 : array_getlement ::temp4 F34_qa 14 
	; 155 : cast F34_qs14 ::temp4 
	int F34_qs14 = F34_qa[14] as int
	; 156 : cmp_eq ::temp5 F34_qs14 0 
	; 157 : not ::temp5 ::temp5 
	; 158 : cast ::temp6 ::temp5 
	; 159 : jmpf ::temp6 162
	; 160 : cmp_eq ::temp5 ::LastNews_var 0 
	; 161 : cast ::temp6 ::temp5 
	; 162 : jmpf ::temp6 165
	If (F34_qs14 != 0 && LastNews == 0)
		; 163 : assign ::LastNews_var F34_qs14 
		LastNews = F34_qs14
	; 164 : jmp 165
	EndIf
	; 165 : array_getlement ::temp4 F34_qa 15 
	; 166 : cast F34_qs15 ::temp4 
	int F34_qs15 = F34_qa[15] as int
	; 167 : cmp_eq ::temp5 F34_qs15 0 
	; 168 : not ::temp5 ::temp5 
	; 169 : cast ::temp6 ::temp5 
	; 170 : jmpf ::temp6 173
	; 171 : cmp_eq ::temp5 ::LastPSA_var 0 
	; 172 : cast ::temp6 ::temp5 
	; 173 : jmpf ::temp6 176
	If (F34_qs15 != 0 && LastPSA == 0)
		; 174 : assign ::LastPSA_var F34_qs15 
		LastPSA = F34_qs15
	; 175 : jmp 176
	EndIf
	; 176 : array_getlement ::temp4 F34_qa 16 
	; 177 : cast F34_qs16 ::temp4 
	int F34_qs16 = F34_qa[16] as int
	; 178 : cmp_eq ::temp5 F34_qs16 0 
	; 179 : not ::temp5 ::temp5 
	; 180 : cast ::temp6 ::temp5 
	; 181 : jmpf ::temp6 184
	; 182 : cmp_eq ::temp5 ::LastGreeting_var 0 
	; 183 : cast ::temp6 ::temp5 
	; 184 : jmpf ::temp6 187
	If (F34_qs16 != 0 && LastGreeting == 0)
		; 185 : assign ::LastGreeting_var F34_qs16 
		LastGreeting = F34_qs16
	; 186 : jmp 187
	EndIf
	; 187 : array_getlement ::temp4 F34_qa 17 
	; 188 : cast F34_qs17 ::temp4 
	int F34_qs17 = F34_qa[17] as int
	; 189 : cmp_eq ::temp5 F34_qs17 0 
	; 190 : not ::temp5 ::temp5 
	; 191 : cast ::temp6 ::temp5 
	; 192 : jmpf ::temp6 195
	; 193 : cmp_eq ::temp5 ::LastGreeting2_var 0 
	; 194 : cast ::temp6 ::temp5 
	; 195 : jmpf ::temp6 198
	If (F34_qs17 != 0 && LastGreeting2 == 0)
		; 196 : assign ::LastGreeting2_var F34_qs17 
		LastGreeting2 = F34_qs17
	; 197 : jmp 198
	EndIf
	; 198 : array_getlement ::temp4 F34_qa 18 
	; 199 : cast F34_qs18 ::temp4 
	int F34_qs18 = F34_qa[18] as int
	; 200 : cmp_eq ::temp5 F34_qs18 0 
	; 201 : not ::temp5 ::temp5 
	; 202 : cast ::temp6 ::temp5 
	; 203 : jmpf ::temp6 206
	; 204 : cmp_eq ::temp5 ::SongsPlayed_var 0 
	; 205 : cast ::temp6 ::temp5 
	; 206 : jmpf ::temp6 209
	If (F34_qs18 != 0 && SongsPlayed == 0)
		; 207 : assign ::SongsPlayed_var F34_qs18 
		SongsPlayed = F34_qs18
	; 208 : jmp 209
	EndIf
	; 209 : array_getlement ::temp4 F34_qa 19 
	; 210 : cast F34_qs19 ::temp4 
	int F34_qs19 = F34_qa[19] as int
	; 211 : cmp_eq ::temp5 F34_qs19 0 
	; 212 : not ::temp5 ::temp5 
	; 213 : cast ::temp6 ::temp5 
	; 214 : jmpf ::temp6 217
	; 215 : cmp_eq ::temp5 ::ThreeDogDead_var 0 
	; 216 : cast ::temp6 ::temp5 
	; 217 : jmpf ::temp6 220
	If (F34_qs19 != 0 && ThreeDogDead == 0)
		; 218 : assign ::ThreeDogDead_var F34_qs19 
		ThreeDogDead = F34_qs19
	; 219 : jmp 220
	EndIf
	; 220 : array_getlement ::temp4 F34_qa 20 
	; 221 : cast F34_qs20 ::temp4 
	int F34_qs20 = F34_qa[20] as int
	; 222 : cmp_eq ::temp5 F34_qs20 0 
	; 223 : not ::temp5 ::temp5 
	; 224 : cast ::temp6 ::temp5 
	; 225 : jmpf ::temp6 228
	; 226 : cmp_eq ::temp5 ::BadDoesGood_var 0 
	; 227 : cast ::temp6 ::temp5 
	; 228 : jmpf ::temp6 231
	If (F34_qs20 != 0 && BadDoesGood == 0)
		; 229 : assign ::BadDoesGood_var F34_qs20 
		BadDoesGood = F34_qs20
	; 230 : jmp 231
	EndIf
	; 231 : array_getlement ::temp4 F34_qa 21 
	; 232 : cast F34_qs21 ::temp4 
	int F34_qs21 = F34_qa[21] as int
	; 233 : cmp_eq ::temp5 F34_qs21 0 
	; 234 : not ::temp5 ::temp5 
	; 235 : cast ::temp6 ::temp5 
	; 236 : jmpf ::temp6 239
	; 237 : cmp_eq ::temp5 ::GoodDoesBad_var 0 
	; 238 : cast ::temp6 ::temp5 
	; 239 : jmpf ::temp6 242
	If (F34_qs21 != 0 && GoodDoesBad == 0)
		; 240 : assign ::GoodDoesBad_var F34_qs21 
		GoodDoesBad = F34_qs21
	; 241 : jmp 242
	EndIf
	; 242 : array_getlement ::temp4 F34_qa 22 
	; 243 : cast F34_qs22 ::temp4 
	int F34_qs22 = F34_qa[22] as int
	; 244 : cmp_eq ::temp5 F34_qs22 0 
	; 245 : not ::temp5 ::temp5 
	; 246 : cast ::temp6 ::temp5 
	; 247 : jmpf ::temp6 250
	; 248 : cmp_eq ::temp5 ::DashwoodEp_var 0 
	; 249 : cast ::temp6 ::temp5 
	; 250 : jmpf ::temp6 253
	If (F34_qs22 != 0 && DashwoodEp == 0)
		; 251 : assign ::DashwoodEp_var F34_qs22 
		DashwoodEp = F34_qs22
	; 252 : jmp 253
	EndIf
	; 253 : array_getlement ::temp4 F34_qa 23 
	; 254 : cast F34_qs23 ::temp4 
	float F34_qs23 = F34_qa[23] as float
	; 255 : cmp_eq ::temp5 F34_qs23 0 
	; 256 : not ::temp5 ::temp5 
	; 257 : cast ::temp6 ::temp5 
	; 258 : jmpf ::temp6 261
	; 259 : cmp_eq ::temp5 ::CG04Done_var 0 
	; 260 : cast ::temp6 ::temp5 
	; 261 : jmpf ::temp6 264
	If (F34_qs23 != 0 && CG04Done == 0)
		; 262 : assign ::CG04Done_var F34_qs23 
		CG04Done = F34_qs23
	; 263 : jmp 264
	EndIf
	; 264 : array_getlement ::temp4 F34_qa 24 
	; 265 : cast F34_qs24 ::temp4 
	float F34_qs24 = F34_qa[24] as float
	; 266 : cmp_eq ::temp5 F34_qs24 0 
	; 267 : not ::temp5 ::temp5 
	; 268 : cast ::temp6 ::temp5 
	; 269 : jmpf ::temp6 272
	; 270 : cmp_eq ::temp5 ::MQ01Clear_var 0 
	; 271 : cast ::temp6 ::temp5 
	; 272 : jmpf ::temp6 275
	If (F34_qs24 != 0 && MQ01Clear == 0)
		; 273 : assign ::MQ01Clear_var F34_qs24 
		MQ01Clear = F34_qs24
	; 274 : jmp 275
	EndIf
	; 275 : array_getlement ::temp4 F34_qa 25 
	; 276 : cast F34_qs25 ::temp4 
	float F34_qs25 = F34_qa[25] as float
	; 277 : cmp_eq ::temp5 F34_qs25 0 
	; 278 : not ::temp5 ::temp5 
	; 279 : cast ::temp6 ::temp5 
	; 280 : jmpf ::temp6 283
	; 281 : cmp_eq ::temp5 ::MQ02Clear_var 0 
	; 282 : cast ::temp6 ::temp5 
	; 283 : jmpf ::temp6 286
	If (F34_qs25 != 0 && MQ02Clear == 0)
		; 284 : assign ::MQ02Clear_var F34_qs25 
		MQ02Clear = F34_qs25
	; 285 : jmp 286
	EndIf
	; 286 : array_getlement ::temp4 F34_qa 26 
	; 287 : cast F34_qs26 ::temp4 
	float F34_qs26 = F34_qa[26] as float
	; 288 : cmp_eq ::temp5 F34_qs26 0 
	; 289 : not ::temp5 ::temp5 
	; 290 : cast ::temp6 ::temp5 
	; 291 : jmpf ::temp6 294
	; 292 : cmp_eq ::temp5 ::MQ03Clear_var 0 
	; 293 : cast ::temp6 ::temp5 
	; 294 : jmpf ::temp6 297
	If (F34_qs26 != 0 && MQ03Clear == 0)
		; 295 : assign ::MQ03Clear_var F34_qs26 
		MQ03Clear = F34_qs26
	; 296 : jmp 297
	EndIf
	; 297 : array_getlement ::temp4 F34_qa 27 
	; 298 : cast F34_qs27 ::temp4 
	float F34_qs27 = F34_qa[27] as float
	; 299 : cmp_eq ::temp5 F34_qs27 0 
	; 300 : not ::temp5 ::temp5 
	; 301 : cast ::temp6 ::temp5 
	; 302 : jmpf ::temp6 305
	; 303 : cmp_eq ::temp5 ::MQ04Clear_var 0 
	; 304 : cast ::temp6 ::temp5 
	; 305 : jmpf ::temp6 308
	If (F34_qs27 != 0 && MQ04Clear == 0)
		; 306 : assign ::MQ04Clear_var F34_qs27 
		MQ04Clear = F34_qs27
	; 307 : jmp 308
	EndIf
	; 308 : array_getlement ::temp4 F34_qa 28 
	; 309 : cast F34_qs28 ::temp4 
	float F34_qs28 = F34_qa[28] as float
	; 310 : cmp_eq ::temp5 F34_qs28 0 
	; 311 : not ::temp5 ::temp5 
	; 312 : cast ::temp6 ::temp5 
	; 313 : jmpf ::temp6 316
	; 314 : cmp_eq ::temp5 ::MQ05Clear_var 0 
	; 315 : cast ::temp6 ::temp5 
	; 316 : jmpf ::temp6 319
	If (F34_qs28 != 0 && MQ05Clear == 0)
		; 317 : assign ::MQ05Clear_var F34_qs28 
		MQ05Clear = F34_qs28
	; 318 : jmp 319
	EndIf
	; 319 : array_getlement ::temp4 F34_qa 29 
	; 320 : cast F34_qs29 ::temp4 
	float F34_qs29 = F34_qa[29] as float
	; 321 : cmp_eq ::temp5 F34_qs29 0 
	; 322 : not ::temp5 ::temp5 
	; 323 : cast ::temp6 ::temp5 
	; 324 : jmpf ::temp6 327
	; 325 : cmp_eq ::temp5 ::MQ06Clear_var 0 
	; 326 : cast ::temp6 ::temp5 
	; 327 : jmpf ::temp6 330
	If (F34_qs29 != 0 && MQ06Clear == 0)
		; 328 : assign ::MQ06Clear_var F34_qs29 
		MQ06Clear = F34_qs29
	; 329 : jmp 330
	EndIf
	; 330 : array_getlement ::temp4 F34_qa 30 
	; 331 : cast F34_qs30 ::temp4 
	float F34_qs30 = F34_qa[30] as float
	; 332 : cmp_eq ::temp5 F34_qs30 0 
	; 333 : not ::temp5 ::temp5 
	; 334 : cast ::temp6 ::temp5 
	; 335 : jmpf ::temp6 338
	; 336 : cmp_eq ::temp5 ::MQ07Clear_var 0 
	; 337 : cast ::temp6 ::temp5 
	; 338 : jmpf ::temp6 341
	If (F34_qs30 != 0 && MQ07Clear == 0)
		; 339 : assign ::MQ07Clear_var F34_qs30 
		MQ07Clear = F34_qs30
	; 340 : jmp 341
	EndIf
	; 341 : array_getlement ::temp4 F34_qa 31 
	; 342 : cast F34_qs31 ::temp4 
	float F34_qs31 = F34_qa[31] as float
	; 343 : cmp_eq ::temp5 F34_qs31 0 
	; 344 : not ::temp5 ::temp5 
	; 345 : cast ::temp6 ::temp5 
	; 346 : jmpf ::temp6 349
	; 347 : cmp_eq ::temp5 ::MQ08Clear_var 0 
	; 348 : cast ::temp6 ::temp5 
	; 349 : jmpf ::temp6 352
	If (F34_qs31 != 0 && MQ08Clear == 0)
		; 350 : assign ::MQ08Clear_var F34_qs31 
		MQ08Clear = F34_qs31
	; 351 : jmp 352
	EndIf
	; 352 : array_getlement ::temp4 F34_qa 32 
	; 353 : cast F34_qs32 ::temp4 
	float F34_qs32 = F34_qa[32] as float
	; 354 : cmp_eq ::temp5 F34_qs32 0 
	; 355 : not ::temp5 ::temp5 
	; 356 : cast ::temp6 ::temp5 
	; 357 : jmpf ::temp6 360
	; 358 : cmp_eq ::temp5 ::MQ09Clear_var 0 
	; 359 : cast ::temp6 ::temp5 
	; 360 : jmpf ::temp6 363
	If (F34_qs32 != 0 && MQ09Clear == 0)
		; 361 : assign ::MQ09Clear_var F34_qs32 
		MQ09Clear = F34_qs32
	; 362 : jmp 363
	EndIf
	; 363 : array_getlement ::temp4 F34_qa 33 
	; 364 : cast F34_qs33 ::temp4 
	float F34_qs33 = F34_qa[33] as float
	; 365 : cmp_eq ::temp5 F34_qs33 0 
	; 366 : not ::temp5 ::temp5 
	; 367 : cast ::temp6 ::temp5 
	; 368 : jmpf ::temp6 371
	; 369 : cmp_eq ::temp5 ::MS01Clear_var 0 
	; 370 : cast ::temp6 ::temp5 
	; 371 : jmpf ::temp6 374
	If (F34_qs33 != 0 && MS01Clear == 0)
		; 372 : assign ::MS01Clear_var F34_qs33 
		MS01Clear = F34_qs33
	; 373 : jmp 374
	EndIf
	; 374 : array_getlement ::temp4 F34_qa 34 
	; 375 : cast F34_qs34 ::temp4 
	float F34_qs34 = F34_qa[34] as float
	; 376 : cmp_eq ::temp5 F34_qs34 0 
	; 377 : not ::temp5 ::temp5 
	; 378 : cast ::temp6 ::temp5 
	; 379 : jmpf ::temp6 382
	; 380 : cmp_eq ::temp5 ::MS02Clear_var 0 
	; 381 : cast ::temp6 ::temp5 
	; 382 : jmpf ::temp6 385
	If (F34_qs34 != 0 && MS02Clear == 0)
		; 383 : assign ::MS02Clear_var F34_qs34 
		MS02Clear = F34_qs34
	; 384 : jmp 385
	EndIf
	; 385 : array_getlement ::temp4 F34_qa 35 
	; 386 : cast F34_qs35 ::temp4 
	float F34_qs35 = F34_qa[35] as float
	; 387 : cmp_eq ::temp5 F34_qs35 0 
	; 388 : not ::temp5 ::temp5 
	; 389 : cast ::temp6 ::temp5 
	; 390 : jmpf ::temp6 393
	; 391 : cmp_eq ::temp5 ::MS03Clear_var 0 
	; 392 : cast ::temp6 ::temp5 
	; 393 : jmpf ::temp6 396
	If (F34_qs35 != 0 && MS03Clear == 0)
		; 394 : assign ::MS03Clear_var F34_qs35 
		MS03Clear = F34_qs35
	; 395 : jmp 396
	EndIf
	; 396 : array_getlement ::temp4 F34_qa 36 
	; 397 : cast F34_qs36 ::temp4 
	float F34_qs36 = F34_qa[36] as float
	; 398 : cmp_eq ::temp5 F34_qs36 0 
	; 399 : not ::temp5 ::temp5 
	; 400 : cast ::temp6 ::temp5 
	; 401 : jmpf ::temp6 404
	; 402 : cmp_eq ::temp5 ::MS04Clear_var 0 
	; 403 : cast ::temp6 ::temp5 
	; 404 : jmpf ::temp6 407
	If (F34_qs36 != 0 && MS04Clear == 0)
		; 405 : assign ::MS04Clear_var F34_qs36 
		MS04Clear = F34_qs36
	; 406 : jmp 407
	EndIf
	; 407 : array_getlement ::temp4 F34_qa 37 
	; 408 : cast F34_qs37 ::temp4 
	float F34_qs37 = F34_qa[37] as float
	; 409 : cmp_eq ::temp5 F34_qs37 0 
	; 410 : not ::temp5 ::temp5 
	; 411 : cast ::temp6 ::temp5 
	; 412 : jmpf ::temp6 415
	; 413 : cmp_eq ::temp5 ::MS05Clear_var 0 
	; 414 : cast ::temp6 ::temp5 
	; 415 : jmpf ::temp6 418
	If (F34_qs37 != 0 && MS05Clear == 0)
		; 416 : assign ::MS05Clear_var F34_qs37 
		MS05Clear = F34_qs37
	; 417 : jmp 418
	EndIf
	; 418 : array_getlement ::temp4 F34_qa 38 
	; 419 : cast F34_qs38 ::temp4 
	float F34_qs38 = F34_qa[38] as float
	; 420 : cmp_eq ::temp5 F34_qs38 0 
	; 421 : not ::temp5 ::temp5 
	; 422 : cast ::temp6 ::temp5 
	; 423 : jmpf ::temp6 426
	; 424 : cmp_eq ::temp5 ::MS06Clear_var 0 
	; 425 : cast ::temp6 ::temp5 
	; 426 : jmpf ::temp6 429
	If (F34_qs38 != 0 && MS06Clear == 0)
		; 427 : assign ::MS06Clear_var F34_qs38 
		MS06Clear = F34_qs38
	; 428 : jmp 429
	EndIf
	; 429 : array_getlement ::temp4 F34_qa 39 
	; 430 : cast F34_qs39 ::temp4 
	float F34_qs39 = F34_qa[39] as float
	; 431 : cmp_eq ::temp5 F34_qs39 0 
	; 432 : not ::temp5 ::temp5 
	; 433 : cast ::temp6 ::temp5 
	; 434 : jmpf ::temp6 437
	; 435 : cmp_eq ::temp5 ::MS08Clear_var 0 
	; 436 : cast ::temp6 ::temp5 
	; 437 : jmpf ::temp6 440
	If (F34_qs39 != 0 && MS08Clear == 0)
		; 438 : assign ::MS08Clear_var F34_qs39 
		MS08Clear = F34_qs39
	; 439 : jmp 440
	EndIf
	; 440 : array_getlement ::temp4 F34_qa 40 
	; 441 : cast F34_qs40 ::temp4 
	float F34_qs40 = F34_qa[40] as float
	; 442 : cmp_eq ::temp5 F34_qs40 0 
	; 443 : not ::temp5 ::temp5 
	; 444 : cast ::temp6 ::temp5 
	; 445 : jmpf ::temp6 448
	; 446 : cmp_eq ::temp5 ::MS09Clear_var 0 
	; 447 : cast ::temp6 ::temp5 
	; 448 : jmpf ::temp6 451
	If (F34_qs40 != 0 && MS09Clear == 0)
		; 449 : assign ::MS09Clear_var F34_qs40 
		MS09Clear = F34_qs40
	; 450 : jmp 451
	EndIf
	; 451 : array_getlement ::temp4 F34_qa 41 
	; 452 : cast F34_qs41 ::temp4 
	float F34_qs41 = F34_qa[41] as float
	; 453 : cmp_eq ::temp5 F34_qs41 0 
	; 454 : not ::temp5 ::temp5 
	; 455 : cast ::temp6 ::temp5 
	; 456 : jmpf ::temp6 459
	; 457 : cmp_eq ::temp5 ::MS10Clear_var 0 
	; 458 : cast ::temp6 ::temp5 
	; 459 : jmpf ::temp6 462
	If (F34_qs41 != 0 && MS10Clear == 0)
		; 460 : assign ::MS10Clear_var F34_qs41 
		MS10Clear = F34_qs41
	; 461 : jmp 462
	EndIf
	; 462 : array_getlement ::temp4 F34_qa 42 
	; 463 : cast F34_qs42 ::temp4 
	float F34_qs42 = F34_qa[42] as float
	; 464 : cmp_eq ::temp5 F34_qs42 0 
	; 465 : not ::temp5 ::temp5 
	; 466 : cast ::temp6 ::temp5 
	; 467 : jmpf ::temp6 470
	; 468 : cmp_eq ::temp5 ::MS11Clear_var 0 
	; 469 : cast ::temp6 ::temp5 
	; 470 : jmpf ::temp6 473
	If (F34_qs42 != 0 && MS11Clear == 0)
		; 471 : assign ::MS11Clear_var F34_qs42 
		MS11Clear = F34_qs42
	; 472 : jmp 473
	EndIf
	; 473 : array_getlement ::temp4 F34_qa 43 
	; 474 : cast F34_qs43 ::temp4 
	float F34_qs43 = F34_qa[43] as float
	; 475 : cmp_eq ::temp5 F34_qs43 0 
	; 476 : not ::temp5 ::temp5 
	; 477 : cast ::temp6 ::temp5 
	; 478 : jmpf ::temp6 481
	; 479 : cmp_eq ::temp5 ::MS12Clear_var 0 
	; 480 : cast ::temp6 ::temp5 
	; 481 : jmpf ::temp6 484
	If (F34_qs43 != 0 && MS12Clear == 0)
		; 482 : assign ::MS12Clear_var F34_qs43 
		MS12Clear = F34_qs43
	; 483 : jmp 484
	EndIf
	; 484 : array_getlement ::temp4 F34_qa 44 
	; 485 : cast F34_qs44 ::temp4 
	float F34_qs44 = F34_qa[44] as float
	; 486 : cmp_eq ::temp5 F34_qs44 0 
	; 487 : not ::temp5 ::temp5 
	; 488 : cast ::temp6 ::temp5 
	; 489 : jmpf ::temp6 492
	; 490 : cmp_eq ::temp5 ::MS14Clear_var 0 
	; 491 : cast ::temp6 ::temp5 
	; 492 : jmpf ::temp6 495
	If (F34_qs44 != 0 && MS14Clear == 0)
		; 493 : assign ::MS14Clear_var F34_qs44 
		MS14Clear = F34_qs44
	; 494 : jmp 495
	EndIf
	; 495 : array_getlement ::temp4 F34_qa 45 
	; 496 : cast F34_qs45 ::temp4 
	float F34_qs45 = F34_qa[45] as float
	; 497 : cmp_eq ::temp5 F34_qs45 0 
	; 498 : not ::temp5 ::temp5 
	; 499 : cast ::temp6 ::temp5 
	; 500 : jmpf ::temp6 503
	; 501 : cmp_eq ::temp5 ::MS15Clear_var 0 
	; 502 : cast ::temp6 ::temp5 
	; 503 : jmpf ::temp6 506
	If (F34_qs45 != 0 && MS15Clear == 0)
		; 504 : assign ::MS15Clear_var F34_qs45 
		MS15Clear = F34_qs45
	; 505 : jmp 506
	EndIf
	; 506 : array_getlement ::temp4 F34_qa 46 
	; 507 : cast F34_qs46 ::temp4 
	float F34_qs46 = F34_qa[46] as float
	; 508 : cmp_eq ::temp5 F34_qs46 0 
	; 509 : not ::temp5 ::temp5 
	; 510 : cast ::temp6 ::temp5 
	; 511 : jmpf ::temp6 514
	; 512 : cmp_eq ::temp5 ::MS16Clear_var 0 
	; 513 : cast ::temp6 ::temp5 
	; 514 : jmpf ::temp6 517
	If (F34_qs46 != 0 && MS16Clear == 0)
		; 515 : assign ::MS16Clear_var F34_qs46 
		MS16Clear = F34_qs46
	; 516 : jmp 517
	EndIf
	; 517 : array_getlement ::temp4 F34_qa 47 
	; 518 : cast F34_qs47 ::temp4 
	float F34_qs47 = F34_qa[47] as float
	; 519 : cmp_eq ::temp5 F34_qs47 0 
	; 520 : not ::temp5 ::temp5 
	; 521 : cast ::temp6 ::temp5 
	; 522 : jmpf ::temp6 525
	; 523 : cmp_eq ::temp5 ::MS17Clear_var 0 
	; 524 : cast ::temp6 ::temp5 
	; 525 : jmpf ::temp6 528
	If (F34_qs47 != 0 && MS17Clear == 0)
		; 526 : assign ::MS17Clear_var F34_qs47 
		MS17Clear = F34_qs47
	; 527 : jmp 528
	EndIf
	; 528 : array_getlement ::temp4 F34_qa 48 
	; 529 : cast F34_qs48 ::temp4 
	float F34_qs48 = F34_qa[48] as float
	; 530 : cmp_eq ::temp5 F34_qs48 0 
	; 531 : not ::temp5 ::temp5 
	; 532 : cast ::temp6 ::temp5 
	; 533 : jmpf ::temp6 536
	; 534 : cmp_eq ::temp5 ::MS18Clear_var 0 
	; 535 : cast ::temp6 ::temp5 
	; 536 : jmpf ::temp6 539
	If (F34_qs48 != 0 && MS18Clear == 0)
		; 537 : assign ::MS18Clear_var F34_qs48 
		MS18Clear = F34_qs48
	; 538 : jmp 539
	EndIf
	; 539 : array_getlement ::temp4 F34_qa 49 
	; 540 : cast F34_qs49 ::temp4 
	int F34_qs49 = F34_qa[49] as int
	; 541 : cmp_eq ::temp5 F34_qs49 0 
	; 542 : not ::temp5 ::temp5 
	; 543 : cast ::temp6 ::temp5 
	; 544 : jmpf ::temp6 547
	; 545 : cmp_eq ::temp5 ::ExploitReady_var 0 
	; 546 : cast ::temp6 ::temp5 
	; 547 : jmpf ::temp6 550
	If (F34_qs49 != 0 && ExploitReady == 0)
		; 548 : assign ::ExploitReady_var F34_qs49 
		ExploitReady = F34_qs49
	; 549 : jmp 550
	EndIf
	; 550 : array_getlement ::temp4 F34_qa 50 
	; 551 : cast F34_qs50 ::temp4 
	float F34_qs50 = F34_qa[50] as float
	; 552 : cmp_eq ::temp5 F34_qs50 0 
	; 553 : not ::temp5 ::temp5 
	; 554 : cast ::temp6 ::temp5 
	; 555 : jmpf ::temp6 558
	; 556 : cmp_eq ::temp5 ::MQ11Clear_var 0 
	; 557 : cast ::temp6 ::temp5 
	; 558 : jmpf ::temp6 561
	If (F34_qs50 != 0 && MQ11Clear == 0)
		; 559 : assign ::MQ11Clear_var F34_qs50 
		MQ11Clear = F34_qs50
	; 560 : jmp 561
	EndIf
	; 561 : array_getlement ::temp4 F34_qa 51 
	; 562 : cast F34_qs51 ::temp4 
	float F34_qs51 = F34_qa[51] as float
	; 563 : cmp_eq ::temp5 F34_qs51 0 
	; 564 : not ::temp5 ::temp5 
	; 565 : cast ::temp6 ::temp5 
	; 566 : jmpf ::temp6 569
	; 567 : cmp_eq ::temp5 ::DLC03BS1Clear_var 0 
	; 568 : cast ::temp6 ::temp5 
	; 569 : jmpf ::temp6 572
	If (F34_qs51 != 0 && DLC03BS1Clear == 0)
		; 570 : assign ::DLC03BS1Clear_var F34_qs51 
		DLC03BS1Clear = F34_qs51
	; 571 : jmp 572
	EndIf
	; 572 : array_getlement ::temp4 F34_qa 52 
	; 573 : cast F34_qs52 ::temp4 
	float F34_qs52 = F34_qa[52] as float
	; 574 : cmp_eq ::temp5 F34_qs52 0 
	; 575 : not ::temp5 ::temp5 
	; 576 : cast ::temp6 ::temp5 
	; 577 : jmpf ::temp6 580
	; 578 : cmp_eq ::temp5 ::DLC03BS2Clear_var 0 
	; 579 : cast ::temp6 ::temp5 
	; 580 : jmpf ::temp6 583
	If (F34_qs52 != 0 && DLC03BS2Clear == 0)
		; 581 : assign ::DLC03BS2Clear_var F34_qs52 
		DLC03BS2Clear = F34_qs52
	; 582 : jmp 583
	EndIf
	; 583 : array_getlement ::temp4 F34_qa 53 
	; 584 : cast F34_qs53 ::temp4 
	float F34_qs53 = F34_qa[53] as float
	; 585 : cmp_eq ::temp5 F34_qs53 0 
	; 586 : not ::temp5 ::temp5 
	; 587 : cast ::temp6 ::temp5 
	; 588 : jmpf ::temp6 591
	; 589 : cmp_eq ::temp5 ::DLC03BS3Clear_var 0 
	; 590 : cast ::temp6 ::temp5 
	; 591 : jmpf ::temp6 594
	If (F34_qs53 != 0 && DLC03BS3Clear == 0)
		; 592 : assign ::DLC03BS3Clear_var F34_qs53 
		DLC03BS3Clear = F34_qs53
	; 593 : jmp 594
	EndIf
EndFunction

bool Function F34_InOwnWorld()
{ T120: the player's worldspace (outside) / cell (inside) comes from the plugin of this quest; re-read at most
    once a second. Unknown location = yes. }
	;Bool ::temp7
	;Bool ::temp8
	;Float ::temp9
	;WorldSpace ::temp10
	;Cell ::temp11
	;Int ::temp12
	;Int ::temp13
	;Int ::temp14
	
	; 000 : callstatic Utility GetCurrentRealTime t 
	float t = Utility.GetCurrentRealTime()
	; 001 : comp_gte ::temp7 t F34_OwnWorldAt 
	; 002 : cast ::temp8 ::temp7 
	; 003 : jmpf ::temp8 007
	; 004 : fsub ::temp9 t F34_OwnWorldAt 
	; 005 : cmp_lt ::temp7 ::temp9 1 
	; 006 : cast ::temp8 ::temp7 
	; 007 : jmpf ::temp8 010
	If (t >= F34_OwnWorldAt && t - F34_OwnWorldAt < 1)
		; 008 : return F34_OwnWorld 
		return F34_OwnWorld
	; 009 : jmp 010
	EndIf
	; 010 : assign F34_OwnWorldAt t 
	F34_OwnWorldAt = t
	; 011 : callstatic Game GetPlayer p 
	Actor p = Game.GetPlayer()
	; 012 : callmethod GetWorldSpace p ::temp10 
	; 013 : cast where ::temp10 
	Form where = p.GetWorldSpace() as Form
	; 014 : not ::temp7 where 
	; 015 : jmpf ::temp7 019
	If (!where)
		; 016 : callmethod GetParentCell p ::temp11 
		; 017 : cast where ::temp11 
		where = p.GetParentCell() as Form
	; 018 : jmp 019
	EndIf
	; 019 : assign F34_OwnWorld True 
	F34_OwnWorld = True
	; 020 : jmpf where 027
	If (where)
		; 021 : callmethod GetFormID where ::temp12 
		; 022 : idiv ::temp13 ::temp12 16777216 
		; 023 : callmethod GetFormID self ::temp12 
		; 024 : idiv ::temp14 ::temp12 16777216 
		; 025 : cmp_eq F34_OwnWorld ::temp13 ::temp14 
		F34_OwnWorld = where.GetFormID() / 1677721