#!/usr/bin/env python3
"""song_fragment_map.py - summarize what each decoded GNR fragment dump does to the song counter.

Usage (Command Prompt, in the folder holding the pexdump.py output .txt files):
    python song_fragment_map.py            -> writes song_fragment_map.csv and prints a summary
    python song_fragment_map.py 9          -> also lists every fragment that records song ID 9

Input: the .txt files made by 'python pexdump.py file.pex > file.txt' (the TIF_F3_RadioGalaxyNewsQuest_* dumps).
It reads the instruction text only; it never writes to the game.
Columns: fragment, song_id (value written to LastSongPlayed), songs_played_action
(add N / set V / none), song_intro_action (set V / none), shifts_history (yes/no).
"""
import csv, glob, os, re, sys

def parse(path):
    songs_action, intro_action, song_id = 'none', 'none', ''
    shifts = False
    last_assign = {}
    temp_val = None
    with open(path, encoding='utf8', errors='replace') as f:
        for line in f:
            m = re.match(r'\s*\d+\s+assign\s+(\S+)\s+(-?\d+)\s*$', line)
            if m:
                last_assign[m.group(1)] = int(m.group(2))
                continue
            m = re.match(r'\s*\d+\s+propset\s+(\w+)\s+\S+\s+(\S+)', line)
            if m:
                prop, src = m.group(1), m.group(2)
                val = last_assign.get(src)
                if prop == 'LastSongPlayed':
                    song_id = val if val is not None else '?'
                elif prop in ('LastSongPlayed2', 'LastSongPlayed3', 'LastSongPlayed4'):
                    shifts = True
                elif prop == 'SongsPlayed':
                    songs_action = 'set %s' % (val if val is not None else '?')
                elif prop == 'SongIntro':
                    intro_action = 'set %s' % (val if val is not None else '?')
                continue
            m = re.match(r'\s*\d+\s+callmethod\s+F34_Add_SongsPlayed\s+\S+\s+\S+\s+\((-?\d+)\)', line)
            if m:
                songs_action = 'add %s' % m.group(1)
    return song_id, songs_action, intro_action, shifts

def main():
    want = sys.argv[1] if len(sys.argv) > 1 else None
    rows = []
    for p in sorted(glob.glob('*.txt')):
        name = os.path.basename(p)
        if not name.lower().startswith('tif_'):
            continue
        sid, sa, ia, sh = parse(p)
        rows.append((name, sid, sa, ia, 'yes' if sh else 'no'))
    with open('song_fragment_map.csv', 'w', newline='', encoding='utf8') as f:
        w = csv.writer(f)
        w.writerow(['fragment', 'song_id', 'songs_played_action', 'song_intro_action', 'shifts_history'])
        w.writerows(rows)
    print('fragments read:', len(rows), '-> song_fragment_map.csv')
    from collections import Counter
    c = Counter(r[2] for r in rows)
    print('SongsPlayed actions:', dict(c))
    if want is not None:
        print('\nFragments that record song ID', want)
        for r in rows:
            if str(r[1]) == want:
                print('  ', r[0], '|', r[2], '| intro:', r[3], '| shifts history:', r[4])

if __name__ == '__main__':
    main()
