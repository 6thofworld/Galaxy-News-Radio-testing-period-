# Fallout 3 / Fallout34 GNR investigation — session handoff
**Prepared:** 19 November 2026  
**Scope:** Work completed in this ChatGPT session through the full live-quest INFO export.

## Executive conclusion

Reliable 01 is Save 11. The save inspection reported `F3:RadioGNRScript` with:
- `SongsPlayed = 5`
- `SongIntro = 2`
- Recent-song history slots 1–4: `11, 8, 5, 3`

The full FO4Edit export of `F34_Radio_RadioGalaxyNews` (`QUST:0AD0EE64`) contains 1,732 unique INFO records under 164 DIAL topics across two scene trees. Cross-referencing its Papyrus fragment IDs against the 639 supplied GNR fragment source files accounts for all 172 counter-changing fragments: 120 increments and 52 resets. Each has one INFO in Scene A and one in Scene B, for 344 counter-changing INFO records.

Every one of those 344 INFO records checks `SongsPlayed` against 0, 1, or 2. None accepts 5. This strongly supports that the saved value 5 blocks all known song-increment and reset INFO paths in the exported live quest.

**This does not prove how `SongsPlayed` became 5.** The main script contains `F34_QSnap` and `F34_QRestore`. `F34_QSnap` stores `SongsPlayed` in snapshot slot 18. `F34_QRestore` can restore a saved nonzero value if the current value is 0. This behaviour was read from the supplied `radiognrscript.pas` / `.psc`, not from `scripts.zip`. Whether an external script actually calls the restore function for GNR remains unverified.

## What was inspected

1. User-confirmed Reliable 01 save: `Save11_... .fos` (not the virgin new save).
2. `GNR_ResetInfoExport.txt`: earlier partial reset INFO export, 56 records across six DIAL topics.
3. `GNR_Target_INFO_Conditions_v3.txt`: successful targeted export for four INFO records.
4. `GNR_Full_Live_Quest_INFO_Export_v2.txt`: complete export for the live GNR quest's two scene trees.
5. `GNR_Full_Live_Quest_Counter_Audit.md` and CSV: complete cross-reference of all counter-changing fragments and INFO records.
6. Supplied GNR project package v3.1.1: used to inspect the main script `.pas` / `.psc`, 639 GNR fragment source files, and nested README notes.

## Full live quest export

- Quest: `F34_Radio_RadioGalaxyNews` (`QUST:0AD0EE64`)
- DIAL topics: 164 total; 82 referenced by Scene A and 82 by Scene B.
- Unique INFO records: 1,732.
- Each scene: 505 phases and 505 actions.
- All 172 counter-changing fragment IDs are present, with exactly two INFO records per fragment (one per scene).
- The two scene-pair INFOs for each fragment have identical condition lists.
- Counter-changing INFO records: 344 (240 increment INFOs and 104 reset INFOs).

### Counter gates

| INFO group | Condition |
|---|---:|
| Increment INFOs | `SongsPlayed = 0` or `1` |
| 100 ordinary reset INFOs | `SongsPlayed = 2` |
| 4 INFOs for two exceptional reset fragments | `SongsPlayed = 1` |

No counter-changing INFO accepts `SongsPlayed = 5`.

### Confirmed condition anomalies

**Song 8 — missing third history check:** Two distinct fragments write song ID 8 and shift all four history slots, but their INFO conditions omit `LastSongPlayed3`.
- `01057B29`: Scene A INFO `0AB73340` / DIAL `0AEAECDA`; Scene B INFO `0AFF891F` / DIAL `0AC92CD7`.
- `010752A7`: Scene A INFO `0AA24877` / DIAL `0AFC288C`; Scene B INFO `0AC9F568` / DIAL `0AD702D2`.

**Two reset-fragment history mismatches:** Each INFO pair checks all four history slots against song ID 2, while the attached fragment writes `LastSongPlayed = 1`.
- `01074EF3`: Scene A INFO `0AE757B1` / DIAL `0AB4CDB4`; Scene B INFO `0AD3D631` / DIAL `0AFB2328`.
- `010A870A`: Scene A INFO `0A95D0E8` / DIAL `0A942D8E`; Scene B INFO `0AEE8959` / DIAL `0ACB5E3C`.

These are confirmed differences between conditions and fragment behaviour; they are not, by themselves, proof of the silence cause.

## Main-script snapshot functions — evidence and limitation

- `F34_QSnap` and `F34_QRestore` are functions inside `F3:RadioGNRScript`, not separate PEX files.
- They were read from `Fallout34_GNR_Lean/1_Scripts/main_script/radiognrscript.pas` and `.psc` in the supplied v3.1.1 project package.
- `F34_QSnap` stores `SongsPlayed` in snapshot array position 18.
- `F34_QRestore` restores a snapshotted nonzero `SongsPlayed` value when the current value is 0.
- The separate `scripts.zip` (reported in prior notes to contain 9,301 compiled scripts) was **not included** in the supplied project package available in this session.
- Earlier Claude A work reportedly found 1,786 files mentioning `F34_QSnap`, but the raw mention count was not separated into definitions, references, and actual call sites before that session expired.
- Therefore, actual external callers and any GNR-specific invocation remain unknown.

## What is established vs. not established

**Established from supplied evidence**
- Reliable 01 / Save 11 stored `SongsPlayed = 5` and history `11, 8, 5, 3`.
- The complete exported master-plugin quest INFO set contains 1,732 unique INFOs.
- All 172 supplied counter-changing fragments have paired INFOs in both scenes.
- Every counter-changing INFO rejects a counter value of 5.
- The main script contains the snapshot/restore functions and their relevant counter logic.

**Not yet established**
- Which event or code path caused the counter to reach 5.
- Whether `F34_QRestore` is actually called for GNR in the failing playthrough.
- Whether an experimental ESP override changed any winning INFO conditions at runtime; the full export rows identify `Fallout34.esm`, and no ESP override rows are included.
- Runtime scene phase reachability and live transmitter state at the failure moment.
- Whether any external script outside the supplied 639 GNR fragments writes `SongsPlayed`.

## Recommended next investigation

1. Locate and provide the separate `scripts.zip` (or equivalent full compiled-script archive).
2. Search it for real call sites of `F34_QSnap` and `F34_QRestore`, distinguishing function definitions, string mentions, and executable calls.
3. Determine whether any caller targets `F3:RadioGNRScript` / the GNR quest.
4. Separately verify the active experimental ESP overrides for the relevant INFO records.
5. Do not edit Reliable 01 or manually set `SongsPlayed` until the writer/restore path is understood.

## Included evidence files

See the accompanying ZIP manifest. The ZIP contains the full FO4Edit export, audit tables, earlier targeted exports, relevant main-script source files, and the earlier session-memory reference. The Reliable 01 save itself is deliberately not included.
