;/ Decompiled by Champollion V1.0.6
PEX format v3.9 GameID: 2
Source   : TIF_F3_RadioGalaxyNewsQuest_010657E7.psc
Modified : 2020-09-13 17:56:40
Compiled : 2020-09-13 17:56:40
User     : f34
Computer : papyrus.py
/;
ScriptName Fragments:TopicInfos:TIF_F3_RadioGalaxyNewsQuest_010657E7 extends TopicInfo Const hidden
{ Fallout 3 result scripts of INFO 000657E7 (RadioGalaxyNewsQuest) translated by f34.geck. }

;-- Properties --------------------------------------
F3:RadioGNRScript Property RadioGalaxyNewsQuest Auto Const

;-- Variables ---------------------------------------

;-- Functions ---------------------------------------

Function Fragment_End(ObjectReference akSpeakerRef)
	Actor akSpeaker = akSpeakerRef as Actor
	RadioGalaxyNewsQuest.F34_FragBegin()
	RadioGalaxyNewsQuest.LastSongPlayed4 = RadioGalaxyNewsQuest.LastSongPlayed3
	RadioGalaxyNewsQuest.LastSongPlayed3 = RadioGalaxyNewsQuest.LastSongPlayed2
	RadioGalaxyNewsQuest.LastSongPlayed2 = RadioGalaxyNewsQuest.LastSongPlayed
	RadioGalaxyNewsQuest.LastSongPlayed = 13
	RadioGalaxyNewsQuest.SongsPlayed = 0
	RadioGalaxyNewsQuest.F34_FragEnd()
EndFunction
