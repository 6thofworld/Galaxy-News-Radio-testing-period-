# Fallout 34 – Galaxy News Radio (GNR)
## Session memory: from full INFO audit to a safe self-recovery design
**Prepared:** 19 November 2026  
**Purpose:** Handoff to another AI that already has `GNR_Master_Session_Memory_v3.1.1.md` and `Fallout34_GNR_Claude_B_Package_v3.1.1.zip`. This document records what happened in the intervening investigation and, most importantly, the updated project objective. It is not a replacement for v3.1.1; read both.

---

## 1. The important change in project direction

The user clarified that the project should **not remain focused on discovering why one particular save acquired `SongsPlayed = 5`**. The fact that a known save has an abnormal value is useful evidence, but it is not the general problem to solve. A new save has shown a different state, and the user correctly points out that chasing one save-specific cause may not help other players.

**New project objective: design and validate a safe, general self-recovery mechanism for GNR.**

The question is:

> If the GNR song-selection system ever leaves its intended state, can it detect that condition and return to a valid state without breaking normal song selection, recent-song avoidance, dialogue, or other quest behaviour?

Do not revert to treating the cause of value 5 as the central objective. The cause can remain a separate research branch if it later helps, but it is not a prerequisite for designing robust recovery.

## 2. Evidence baseline carried forward

The preceding investigation completed a full FO4Edit export of the live GNR quest:

- Quest: `F34_Radio_RadioGalaxyNews` (`QUST:0AD0EE64`).
- 164 DIAL topics: 82 referenced by Scene A and 82 by Scene B.
- 1,732 unique INFO records.
- Each scene export contains 505 phases and 505 actions.
- All 172 counter-changing GNR fragment IDs from the supplied 639-fragment source set appear in the full export.
- Each counter-changing fragment has exactly two INFO records: one in Scene A and one in Scene B.
- Those paired INFO records have identical condition lists.
- Total counter-changing INFO records: 344 (240 increment INFOs and 104 reset INFOs).

### Counter condition pattern

| INFO category | `SongsPlayed` gate |
|---|---|
| Increment INFOs | 120 INFOs require 0; 120 require 1 |
| Ordinary reset INFOs | 100 require 2 |
| Two exceptional reset fragments | 4 INFOs require 1 |

**No one of these 344 INFO records accepts `SongsPlayed = 5`.** More generally, the audited INFOs use the counter states 0, 1, and 2. The source logic shows 120 increment fragments call `F34_Add_SongsPlayed(1)` and 52 reset fragments set `SongsPlayed = 0`.

The existing helper `F34_Add_SongsPlayed()` was reported from the script inspection as uncapped: it adds the requested amount rather than enforcing a maximum. This is relevant to robustness design, but does not by itself establish how often invalid values can occur.

### Reliable 01 reference observation

The user confirmed Save 11 is Reliable 01, not the virgin/new save. The inspected state was reported as:

- `SongsPlayed = 5`
- `SongIntro = 2`
- recent-song history slots 1–4: `11, 8, 5, 3`

This is a concrete example of an out-of-range state. It must not be treated as the only possible failure state or as the sole reason to design recovery.

### Existing INFO anomalies (retain as evidence; do not overinterpret)

1. Song 8: two fragments write song ID 8 and shift history, but the associated INFO conditions omit `LastSongPlayed3`.
   - Fragment `01057B29`: Scene A INFO `0AB73340` / DIAL `0AEAECDA`; Scene B INFO `0AFF891F` / DIAL `0AC92CD7`.
   - Fragment `010752A7`: Scene A INFO `0AA24877` / DIAL `0AFC288C`; Scene B INFO `0AC9F568` / DIAL `0AD702D2`.
2. Two reset fragments write `LastSongPlayed = 1`, while their INFO conditions compare all four recent-song slots against song ID 2:
   - `01074EF3`: Scene A INFO `0AE757B1` / DIAL `0AB4CDB4`; Scene B INFO `0AD3D631` / DIAL `0AFB2328`.
   - `010A870A`: Scene A INFO `0A95D0E8` / DIAL `0A942D8E`; Scene B INFO `0AEE8959` / DIAL `0ACB5E3C`.
These are confirmed condition/fragment mismatches, not proven causes of all radio silence.

## 3. What the earlier snapshot/restore research does and does not mean

`F34_QSnap` and `F34_QRestore` are functions inside `F3:RadioGNRScript`, not separate PEX files. They were read from `radiognrscript.pas` / `.psc` in the v3.1.1 package, **not** from the separate `scripts.zip`.

- `F34_QSnap` stores quest variables in a snapshot array; `SongsPlayed` is in slot 18.
- `F34_QRestore` can restore a snapshotted nonzero `SongsPlayed` value if the current value is 0.
- Whether an external caller actually invokes the restore function against GNR has not been established.
- The separately mentioned `scripts.zip` (reportedly 9,301 compiled scripts) was not in the available v3.1.1 package. A prior search reportedly found 1,786 raw mentions of `F34_QSnap`, but those mentions were not separated into definitions, ordinary references, and executable call sites.

This branch is unresolved. It is **not** a reason to postpone the general recovery design, and do not claim `F34_QRestore` caused the Reliable 01 value.

## 4. The self-recovery idea discussed in this session

The user asked whether an ESP could reset `SongsPlayed` whenever it goes off track. The answer is yes in principle, but it must be designed as an **ESP plus a compiled Papyrus script** (and any required script assets), not as an ESP record alone.

A possible high-level architecture is:
1. A small helper quest/script in a separate diagnostic/repair ESP.
2. It obtains a reference to the existing GNR quest script/property safely.
3. It checks the counter at an appropriate cadence or at safe state-transition points.
4. It does nothing for valid values.
5. It invokes a vetted recovery transition for invalid values.
6. It logs/records that a recovery occurred during testing, without altering unrelated GNR state.

This is a design sketch only. No ESP, Papyrus source, or compiled PEX has been created or tested in this work.

## 5. Critical safety correction: do not blindly set the counter to zero

An earlier suggestion was to periodically check `SongsPlayed` and set it to zero whenever it is outside 0–2. The user accepted the general self-recovery direction, but the safety of that specific implementation has **not** been proven.

The full audit shows that the normal reset fragments do more than set `SongsPlayed = 0`: they also perform recent-song bookkeeping. A direct write to zero could therefore leave the counter and history out of sync. That might cause repeated songs, unexpected exclusions, or a state that differs from the mod's intended reset.

Therefore:
- Do not immediately implement a blind `SongsPlayed = 0` watchdog.
- Do not clear or rewrite `SongIntro` or `LastSongPlayed1–4` merely to make values look tidy.
- Do not assume that the ordinary reset fragment can safely be called from arbitrary Papyrus context; first inspect its exact effects and invocation constraints.
- Prefer a recovery transition that preserves invariants and mirrors the mod's intended reset semantics.
- If no safe existing reset path can be called, design and document a minimal repair transition only after the complete counter/history invariants are understood.

## 6. Required recovery design principles

The repair mechanism should be general, conservative, and idempotent:

1. **Valid-state no-op:** `SongsPlayed` values 0, 1, and 2 must be left untouched.
2. **Invalid-state detection:** define invalid as values outside the verified state set, including negative values and values greater than 2. Confirm whether any transient values are possible before finalizing.
3. **Safe recovery:** return to a state that is valid for the existing GNR state machine, using normal reset semantics where possible.
4. **History integrity:** preserve `LastSongPlayed1–4` unless the chosen normal reset operation intentionally changes them. Do not invent a history policy.
5. **Intro integrity:** do not change `SongIntro` unless source evidence proves it is part of the required recovery.
6. **No repeated repair loop:** recovery should not trigger itself continuously or fight with normal fragments.
7. **Timing safety:** do not write during a fragment's partial update or at a point that races with scene INFO evaluation. Determine a safe point/cadence.
8. **Scope isolation:** do not alter unrelated quests, radios, scenes, transmitters, or master records.
9. **Observability:** during testing, provide a clear log or diagnostic indication of detected value, recovery action, and resulting state. Avoid permanent noisy logging in release builds.
10. **Failure-safe behaviour:** if the GNR quest/script reference cannot be resolved, do nothing and report the condition; do not crash or modify another quest.
11. **Separate diagnosis from repair:** a diagnostic-only mode should be available so the team can first observe abnormal states without changing them.
12. **Compatibility:** inspect load order, plugin overrides, script property access, and save persistence before release.

## 7. Test matrix required before calling it safe

Use disposable copies of saves. Never experiment on the only copy of Reliable 01.

| Test counter | Expected guard behaviour |
|---:|---|
| -1 | Detect as invalid; apply vetted recovery |
| 0 | No intervention |
| 1 | No intervention |
| 2 | No intervention; allow normal reset route |
| 3 | Detect as invalid; apply vetted recovery |
| 5 | Detect as invalid; apply vetted recovery |
| Large positive value | Detect as invalid; apply vetted recovery |

For each test, verify:
- The value after recovery is in the intended state.
- Normal song INFOs become eligible when all their other conditions are satisfied.
- A song plays and completes normally.
- The recent-song history remains coherent.
- No immediate repeat or history corruption is introduced.
- Three Dog dialogue and scene progression remain normal.
- The guard does not repeatedly reset a valid state.
- Reloading the save does not reintroduce an invalid value or cause a repair loop.
- Disabling/removing the test plugin does not leave persistent unwanted state.

Also test a normal playthrough from a clean/new save, because the user explicitly notes that the new-save state differs from Reliable 01. The repair must be safe when it has nothing to repair.

## 8. Recommended work sequence for the next AI

Do not start by writing Papyrus code. First build a precise state-transition specification from the source already in the package.

### Step A — inspect the exact script source and fragments
Use `radiognrscript.pas` and `.psc`, the 639 fragment sources, and the cross-reference CSV. Identify:
- Exact property declaration and type for `SongsPlayed`.
- Exact implementation of `F34_Add_SongsPlayed()`.
- Every increment/reset fragment's full write set, especially history variables.
- Whether reset fragments are interchangeable or depend on song IDs, `SongIntro`, INFO conditions, or scene phases.
- Any periodic main-script behaviour relevant to counter updates.

### Step B — define invariants and legal transitions
Document:
- Valid counter states.
- Allowed transitions and triggering events.
- Relationship between counter and history slots.
- What the normal reset changes.
- Whether `SongsPlayed = 2` is a valid waiting-for-reset state.
- Whether any negative/transient value is intentionally used.

Do not infer a full state machine from the condition gates alone; verify against source fragments and actual quest scene structure.

### Step C — choose the safest repair point
Compare:
- A dedicated helper quest timer.
- A check at a safe event/scene boundary.
- An explicit recovery function in a controlled script.
Evaluate race conditions with dialogue INFO conditions and the existing `F34_FragBegin/End` timer behaviour. Those helpers were reported to pause a periodic check briefly, not to change the counter themselves.

### Step D — implement a diagnostic prototype first
First log abnormal values without modifying them. Verify the script can resolve the correct GNR quest script/property in Fallout 4 Papyrus and that the monitor runs reliably.

### Step E — implement repair only after transition approval
Prefer a single well-defined recovery function with explicit guards and a clear write set. Do not edit `Fallout34.esm`; keep the prototype in a separate ESP. Document every record and script change.

### Step F — test and report
Use disposable saves and the matrix above. Report actual runtime test results separately from static source analysis. Do not claim it works merely because it compiles.

## 9. Existing evidence package and files

The earlier evidence ZIP is included intact inside this new handoff ZIP as `GNR_Session_Evidence_Package_2026-11-19.zip`. It contains the full live INFO export, the audit, cross-reference tables, prior exports, source script listings, and the earlier v3.1.1 master session memory.

Important individual files also included at the root of this handoff ZIP:
- `GNR_Master_Session_Memory_v3.1.1.md` — read this with this session memory.
- `GNR_Full_Live_Quest_Counter_Audit.md`
- `GNR_Counter_Fragment_Crosscheck_Audit.txt`
- `GNR_SongsPlayed_172_Fragment_CrossReference_2.csv`
- `GNR_Full_Live_Quest_INFO_Export_v2.pas` and `.txt`
- `radiognrscript.pas` and `.psc`
- `README_F34_GNR__nested_revised.md`
- Earlier session handoff PDF/MD.

The Reliable 01 `.fos` save is intentionally not included. The separate `scripts.zip` is not available in the supplied package. No game files or saves were modified in this session.

## 10. Important instruction to the next AI

**Do not restart the investigation from scratch.** The v3.1.1 master memory and the prior evidence ZIP contain the earlier project history and raw evidence. This session memory adds the complete INFO audit conclusions and the new general self-recovery objective.

The user's intended outcome is a robust, narrowly scoped GNR recovery mechanism that can bring an invalid counter state back into a valid state **without breaking anything else**. Be conservative, prove the state transitions, and distinguish static evidence from in-game validation.

---
**Handoff status:** Design objective clarified; implementation not yet started. No ESP/PEX created, no save edited, no runtime repair tested.
