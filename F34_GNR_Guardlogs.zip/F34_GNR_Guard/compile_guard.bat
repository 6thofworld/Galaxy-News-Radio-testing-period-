@echo off
rem Put this file in your Fallout 4 game folder (next to Fallout4.exe) and double-click it.
rem Compiles Data\Scripts\Source\User\F34GNRGuard.psc to Data\Scripts\F34GNRGuard.pex
set "GAME=%~dp0"
cd /d "%GAME%Data\Scripts\Source\Base"
"%GAME%Papyrus Compiler\PapyrusCompiler.exe" "%GAME%Data\Scripts\Source\User\F34GNRGuard.psc" -f="Institute_Papyrus_Flags.flg" -i="%GAME%Data\Scripts\Source\User;%GAME%Data\Scripts\Source\Base" -o="%GAME%Data\Scripts"
echo.
if exist "%GAME%Data\Scripts\F34GNRGuard.pex" (echo F34GNRGuard.pex exists) else (echo NO .pex produced - copy the red/error text above and send it to me)
pause
