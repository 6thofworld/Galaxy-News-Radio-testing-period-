# Fallout 34 – Galaxy News Radio (GNR)
## Master Session Memory and Project Notes — v4.1 (19 November 2026)

**Purpose:** The single handoff document for continuing the Fallout 34 Galaxy News Radio work. It is built in two parts. **Part A (this part)** is new in v4.0: current position, corrections, and everything done in the "Claude C" session (script guard, bytecode reading, plugin parsing, tester log). **Part B** is the complete v3.1.1 master, carried forward unchanged for the project history. Where Part A corrects Part B, Part A wins.

**What changed in v4.1 (vs the v4.0 draft):** adds the tester's **new-save log** and the short second log (A5.4, A5.5); the **dev's radio-fix archive** with both plugins, including the Fallout 3 one that covers GNR (A8b); a **song-ID map** built from the user's own exports (A8c); a new finding that the tester's repeated songs are **song 5 (Easy Living) and song 1 (Anything Goes)** and that the 5 / 1 alternation matches the counter fragments (A5.3 note, A8c); an updated hypothesis list, v0.3 specification and test plan (A11); raw logs and the guard source as appendices (A16, A17). A2 lists the corrections.

**Evidence rule (unchanged):** keep direct file findings, user-reported results, independent-tester reports, deductions and untested ideas separate. The assistant has not run the game. Nothing in this session was compiled or run by the assistant; every compile and in-game result is a report from the user or a tester.

## A1. Read this first — current position (19 Nov 2026)

- **Goal (self-recovery package, A8):** a safe, general mechanism that detects an invalid GNR counter state and returns to a valid one without breaking normal song selection. Finding why one save reached a bad value is secondary.
- **A working-but-unsafe workaround exists:** `F34_GNR_Guard.esp` + `F34GNRGuard.pex` **v0.2** sets `F3:RadioGNRScript.SongsPlayed` to 0 whenever it reads 2 or higher. The user reports songs play with it. **It is not release-ready** and should not be distributed (A2, A5).
- **The dev's radio fix is a second, different approach** (A8b): `F34_RadioFix.esp` overrides 225 song INFOs (48 of them GNR scene-A song INFOs) to add an invisible speaker NPC and a `.fuz` voice file per song. Nobody on this project has reported testing it on GNR yet.
- **Biggest open questions:** (1) what writes to `SongsPlayed` many times a second (1596 at one tester's first poll; 67 in ~77 s on a new save, both with history `9,9,9,9`); (2) why songs 5 and 1 alternate for ~25 minutes on one save; (3) whether the speaker / `.fuz` approach is needed for GNR at all, given that the scenes also play the song sounds directly (A8b).
- **Tester summary:** on a pre-existing save the guard did not give normal behaviour (few songs, Easy Living about 4 times, runaway counter episodes). On a new save the tester reported no 4-in-a-row repeats and new songs continuing, but Three Dog changed topic halfway through the news; the log of that run still shows a counter jump to 67 and songs 1 and 5 alternating early. The guard was running in all of these.
- **Next build:** a **monitor-only v0.3** (no writes), run on the same saves with and without `F34_RadioFix.esp`, before any further repair design (A11).

## A2. Corrections — read before trusting earlier statements

1. **Wrong earlier claim (assistant, this session):** "the song lines only accept SongsPlayed 0 or 1, so a counter of 2 is stuck and nothing can play." **Retracted.** Per Part B Section 2 and the self-recovery audit (A8), valid states are **0, 1 and 2**; 100 ordinary reset INFOs require 2 and are offered only at talk points N5 and N66. A counter of 2 is a legitimate "waiting for the reset offer" state. The first user log (`SongsPlayed=2 | SongIntro=1 | history=8,2,0,0`) is therefore **not** proof of a stuck counter. That claim came from an older note in the project memory, which Part B had already superseded.
2. **Guard v0.2's threshold is wrong:** it resets at `>= 2`, which also hits the valid state 2. The self-recovery design rule is "values 0, 1 and 2 are left untouched; act only on values below 0 or above 2". v0.2 therefore suppresses the intended 0 -> 1 -> 2 -> reset cycle and the 100 reset INFOs that need value 2. The fact that songs played with v0.2 shows only that forcing the counter to 0 makes the 0-gated and 1-gated song groups available; it does not show v0.2 is correct.
3. **The tester was running guard v0.2**, not "no guard". The user had said "use this as standalone" (meaning the guard plugin alone, no A2/A3). The log header confirms v0.2.
4. **Earlier claim that `GNR_Everywhere_F34.esp` radio data value 99.3 was unknown:** Part B Section 4D (from Claude A's screenshots) reads 99.3 as the **frequency**. My raw parse agrees on the numbers (A7).
5. **"Started" logged twice** in both the user's v0.1 log and the tester's v0.2 log. Earlier I treated it as unexplained. Because it appears on two machines using the same ESP, the likely cause is the ESP itself (script attached twice to the quest, or two quest instances). Unverified. Check before release.

6. **Earlier statement that the dev's archive had no Fallout 3 plugin was wrong.** `radiofix.rar` contains **two** plugins, `F34_RadioFix.esp` (Fallout 3) and `F34_RadioFixNV.esp` (New Vegas). The first extraction only pulled the NV file. Both are analysed in A8b.
7. **Part B calls the `.fuz` / speaker theory "unsupported" (Part B Section 4B, "Ruled out on paper").** That row is now **contested**: the dev's own Fallout 3 plugin adds a speaker and `.fuz` to GNR song INFOs. It is not settled either way for GNR, because the scene exports also show direct "Play Sound" radio actions with the song descriptors (A8b). Treat the Part B row as an open question, not a closed one.
8. **The re-uploaded `Fallout34_GNR_Claude_B_Package_v3_1_1_1.zip` and `GNR_Self_Recovery_Handoff_Package_2026-11-19_1.zip` are byte-identical to the earlier copies** (same SHA-256, checked). The v3.1.1 PDF has the same text as the v3.1.1 Markdown as far as read. Nothing new came from them.
9. **Tester logs use the tester's clock** (11/18/2026 evening); this document uses the same stamps for them.

## A3. What happened in this session (timeline)

1. User uploaded `F34GNRGuard.psc` (v0.1, monitor only), `compile_guard.bat`, and a HOWTO. First compile failed: `state` is a reserved word in Papyrus, and Papyrus has no `\` line continuation. Fixed (variable renamed `stateText`; message built with `+=`). Compile then succeeded: "F34GNRGuard.pex exists".
2. User created `F34_GNR_Guard.esp` in the Creation Kit with one quest: Start Game Enabled on, Run Once off, script `F34GNRGuard` attached. The CK Papyrus Manager listed the script (Compiled Yes, Has Source Yes), but the Add Script dialog did not show it at first; the user later reported adding it anyway (cause not established). `CreationKit.ini` already had `sScriptSourceFolder = ".\Data\Scripts\Source\User"`; `creationkitcustom.ini` only had `bAllowMultipleMasterLoads=1`; `CreationKitPrefs.ini` had no source-folder override.
3. User ran v0.1: one reading `SongsPlayed=2 | SongIntro=1 | history=8,2,0,0`; no change after. User reported Three Dog says "music time" and then news returns after a few seconds; enabling TestA2 or TestA3 makes songs work.
4. User uploaded `radiognrscript.pex` and two fragment `.pex` files; the assistant wrote `pexdump.py` and read them (A6). The user then extracted all fragments and ran `findstr` searches (A6).
5. Guard v0.2 written (resets `>= 2` to 0, polls every 5 s, logs every change). User reported "songs works" with it (save used and duration not recorded; v0.2 log from the user not yet reviewed).
6. User uploaded `GNR_Everywhere_F34.esp` and `GNR_No_Static_F34.esp` and asked about volume; the assistant parsed both (A7).
7. User began preparing an MO2-installable zip (layout confirmed in a screenshot: `README.txt`, `F34_GNR_Guard.esp`, `Scripts/` at the top level).
8. A tester using the guard alone reported few songs and Easy Living about 4 times; the tester's `F34_GNR_Guard.0.log` (v0.2) was analysed (A5.3). Tester answers: save was **pre-existing**; what they were doing at the odd times: **"standby"** (meaning not clarified); what they heard: **they don't remember**.

9. User uploaded `radiofix.rar` from a main F34 developer (A8b) and relayed the developer's comments: most FO3/FNV DJ lines were never properly converted; FO3/FNV songs play through an attached dialogue line in the originals; FO4 does not do that; song lines have no speaker so the engine has nothing to play; every song needs a speaker (an invisible "radio music" voice) and a `.fuz` voice file; two fixes are needed (make songs playable; make stations actually play DJ lines and songs).
10. Tester ran the guard (v0.2) on a **new save**; user relayed that 4-in-a-row repeats did not occur and new songs continued, but "3 Dog changes topics halfway through the news". Tester posted three logs in one gist (A5.4, A5.5, A16). Ordering by timestamps: old-save log (22:19–22:51) -> old-save reload (23:16–23:18) -> new-save log (23:18–23:44).
11. Assistant opened the dev's archive, parsed both plugins, compared the 225 FO3 INFOs with the user's GNR song exports, and built a song-ID map from the user's own exports and fragment sources (A8b, A8c).
12. User asked for a strong master file covering the guard's results on the tester's existing and new saves, ideas for v0.3, the previous zip packages and the records (this document).

## A4. The guard: versions and exact behaviour

| Item | v0.1 | v0.2 |
|---|---|---|
| Role | Monitor only; never writes | **Writes**: sets `SongsPlayed` to 0 when `>= 2` |
| Poll interval | 30 s | 5 s |
| Logs | On change or when "invalid" (range 0–2 assumed valid; that range was an assumption) | Every change in `SongsPlayed`, plus `RESET #n` lines with before/after |
| Log file | `Documents\My Games\Fallout4\Logs\Script\User\F34_GNR_Guard.0.log` | same |
| Source/compiled | `F34GNRGuard.psc` -> `F34GNRGuard.pex` | same script name, so no quest change needed |

Shared design: quest `F34_GNR_Guard` (in `F34_GNR_Guard.esp`) runs script `F34GNRGuard extends Quest`; it finds the GNR quest with `Game.GetFormFromFile(0x00022486, "Fallout34.esm")`, casts to `F3:RadioGNRScript`, reads the properties `SongsPlayed`, `SongIntro`, `LastSongPlayed` to `LastSongPlayed4` with `GetPropertyValue`, and (v0.2 only) writes with `SetPropertyValue`. Registers `OnPlayerLoadGame` via remote event. If the quest or script is missing it logs once and does nothing. Compiler: Papyrus Compiler 2.8.0.4, run through `compile_guard.bat` (includes `Data\Scripts\Source\Base`, flags file `Institute_Papyrus_Flags.flg`).

**Not verified:** the `.esp` master list (assumed Fallout4.esm and Fallout34.esm; load order must put it after Fallout34.esm); whether `SetPropertyValue` writes always take effect (the tester log shows two cases where a read right after a write returned 1, see A5.3); the double "started" cause.

**MO2 packaging:** an installable archive needs `F34_GNR_Guard.esp` and `Scripts\F34GNRGuard.pex` at the top level (optionally `Scripts\Source\User\F34GNRGuard.psc`, plus `README.txt`); no `Data` folder inside. Check no other MO2 mod contains an older `F34GNRGuard.pex`. A profile-specific INI must carry the Papyrus logging lines if used.

## A5. Test results reported this session

### A5.1 User's own v0.1 log (user-supplied file)
```
guard v0.1 (monitor only) started          (twice, same second)
SongsPlayed=2 valid | SongIntro=1 | history=8,2,0,0   (one reading, 41 s later; no further lines)
```
Reading: value 2 with two recorded songs is a valid 0->1->2 state. "valid" in that log used the assistant's (unverified) 0–2 range, which happens to match the later audit.

### A5.2 User's v0.2 result
User reported: "F34_GNR_Guard.esp songs works." Save used, listening time, song count, and the v0.2 log were **not recorded/supplied**. Treat as a positive but uncontrolled report. It cannot distinguish "the guard fixed a bad state" from "forcing 0 avoids the unreachable state".

### A5.3 Tester log (guard v0.2, guard only; pre-existing save)
Source: `F34_GNR_Guard.0_1.log` (tester's, dates 11/18/2026 about 10:19–10:51 PM). Tester said: "only getting a couple songs so far; Easy Living has played about 4 times", about 20 minutes. Guard v0.2 was running, so this log is **not a pure observation**; it also contains the guard's own writes.

| Time (PM) | What the log shows | Reading |
|---|---|---|
| 10:19:02 | guard started (logged twice) | duplicate start again |
| 10:19:13 | `SongsPlayed=1596 | SongIntro=0 | history=9,9,9,9`; RESET #1 | counter far outside 0–2 at first poll after load; history is one song repeated |
| 10:20–10:43 | counter alternates 1,0,1,0; history 5,9,9,9 -> 1,5,9,9 -> 5,1,5,9 -> 1,5,1,5 -> 5,1,5,1; **no RESET lines** | only songs 1 and 5 alternate; four-slot "last played" exclusion is not stopping them. Guard did not act here, so it did not cause these repeats |
| 10:43:39 – 10:48:42 | readings every ~5 s: SongsPlayed 9, 12, 12, 13, 14, 8, 3, 12, ... with history 9,9,9,9; RESET #2–#35 | counter climbs again within seconds after each reset |
| 10:44:36 – 10:48:27 (interleaved) | other distinct states appear: 14,1,5,10 / 17,16,9,18 / 9,9,15,1 / 14,9,3,18 / 19,15,17,16 (SongIntro 11) / 5,1,5,1 / 9,1,5,8 / 9,15,1,5 | **values flip between several different states**; history 5,1,5,1 reappears at 10:46:08 exactly as it was at 10:40:03 |
| RESET #4 and #25 | "was 12, set to 0, now reads 1" | something else wrote the counter between the write and the read |
| 10:50:56 | `SongsPlayed=1 | SongIntro=0 | history=9,1,5,18` | last line |

**Hypotheses (inference only, none confirmed):**
- **H1 runaway loop:** a song-9 end-fragment (which adds 1 and writes song 9 into the history) fires repeatedly, e.g. a silent INFO with Start Scene on End restarting a scene (v3.1.1 hypothesis 4). Speed of about 2–3 increments per second would match the 0.75 s wait phases of the current scene build. Does not explain how the counter reached 1596 so fast, or why increments fire when the INFO conditions require 0 or 1.
- **H2 multiple state sources:** the flipping between distinct states suggests the guard may be reading more than one copy of the GNR variables (two instances of the quest script, or save-restored vs live values). Not checked.
- **H3 snapshot/restore interplay:** `F34_QRestore` re-applies a snapshotted nonzero value when the current value is 0; the guard writing 0 could interact with it. Caller not established (Part B 4E).
- **H4 history check failing:** the alternation 1,5,1,5 is consistent with the INFO/fragment mismatches listed in A8 (reset fragments that write song 1 while their conditions compare against song 2), but song numbers have not been mapped to "Easy Living" and the link is unverified.

**Tester answers:** save was **pre-existing** (which one: unknown, not stated to be Reliable 01); what they were doing at the odd times: **"standby"**; what they heard: **not remembered**. These do not identify what triggered the 10:43:39 change.

**Added in v4.1 — song identity of the repeats (record-derived, see A8c):** history value 5 is **Billie Holiday — "Easy Living"** and 1 is **Cole Porter — "Anything Goes"**. So the tester's "Easy Living about 4 times" is song 5, and the 25-minute `1,5,1,5` pattern is Anything Goes and Easy Living alternating. The counter pattern (5 raises it 0 -> 1; 1 returns it to 0) matches fragment behaviour: song 5 has increment fragments gated at 0 and 1, and song 1 has two **reset** fragments gated at 1 (`01074EF3`, `010A870A`, both flagged in the self-recovery audit as condition/fragment mismatches). This explains how the counter can flip between 1 and 0 without ever reaching 2, but **not** why song 5's own history check does not exclude it (unexplained). Song 9 (the one filling the history in the runaway episodes) is **Bob Crosby — "Way Back Home"**. No log line shows which song was audible; a song being recorded in the history does not prove it was heard.

### A5.4 Tester log on a **new save** (guard v0.2)
Source: `gistfile1.txt` in the tester's gist (full text in A16). Stamps 11/18/2026 PM.

| Time | Log | Reading |
|---|---|---|
| 11:18:20 | log opened; "guard v0.2 ... started" | |
| 11:18:33 | "guard v0.2 ... started" again, **13 s later** (earlier logs showed both lines in the same second) | two starts again; cause unknown |
| 11:18:45 | `SongsPlayed=0 | SongIntro=0 | history=0,0,0,0` | clean new-game state |
| 11:20:02 | `SongsPlayed=67 | history=9,9,9,9`; RESET #1 | **same runaway signature as the old save**: a net counter of 67 about 77 s after the clean 0 reading (roughly one count per 1.15 s if nothing reset it in between), with song 9 written into all four history slots |
| 11:22:24 | `1 | history=5,1,5,16` | songs 16, 5, 1, 5 recorded in sequence |
| 11:25:53 | `0 | history=1,5,1,5` | the 1 / 5 alternation again |
| 11:30:43 | `1 | history=9,1,5,1` | |
| 11:35:12 | `2 | history=19,9,1,5`; RESET #2 | counter reached **2, a valid state**; the guard reset it |
| 11:40:00 | `1 | history=13,19,9,1` | more variety |
| 11:44:21 | `2 | history=5,13,19,9`; RESET #3 | again the valid state 2 reset by the guard |

What it shows: the runaway also happens on a **new save** (so it is not only a damaged old save); later songs are more varied (5, 13, 19, 9, 1) than on the old save; the guard still acted on the valid value 2 (RESET #2 and #3), i.e. it changes the intended cycle. The tester's remark of "no 4 songs in a row" is only partly supported: `1,5,1,5` appears at 11:25:53 and `9,1,5,1` at 11:30:43. The log records the counter and history only when `SongsPlayed` changes, so history changes between lines are not all visible.

### A5.5 Tester gist file 2 (old save, reloaded; guard v0.2)
```
11:16:54 log opened | 11:16:54 save loaded | 11:16:59 SongsPlayed=1 history=9,1,5,18
11:17:41 SongsPlayed=2 history=9,9,1,5 -> RESET #36 | 11:18:07 Log closed
```
Readings: (a) `RESET #36` continues the count of the earlier old-save log (35), so the script's own variables **survived the save/load** and no new "started" line appears (no new `OnInit`); (b) the state at 11:16:59 (`1`, `9,1,5,18`) equals the last line of the earlier log (10:50:56), so the save restored the same state; (c) the guard reset a **valid** value 2 here too. The next log (new save) opens 13 s after this one closes, which suggests a new game was started right after (inference).

**Tester answers (earlier):** save was **pre-existing**; activity at the odd times **"standby"**; what they heard **not remembered**. For the new save: no extra details yet. **Not asked/unknown:** whether `F34_RadioFix.esp` or any other radio plugin was enabled; whether the new save is a new game from the start; their plugin list; what "changes topics halfway through the news" sounded like (does a different talk topic cut in, is a line cut off, how often).

## A6. Bytecode findings from the user's `.pex` files (assistant's own parser)

Tool: `pexdump.py` (Python, built this session for Fallout 4 PEX v3.9 little-endian: header, strings, debug info incl. property groups and struct orders, objects, variables with isConst byte, properties, states, functions, instructions with variadic call opcodes). It parsed `radiognrscript.pex` to the last byte (16,677 of 16,677) and the fragment files fully (897 of 897; 890 and 924 for others). Opcode argument counts were written from memory, **not validated against Champollion**; they cross-check with Part B 4E (QRestore, slot 18). The `.pex` files carry the header `Fix the translator, not this file` and were made by `f34.geck` / `papyrus.py` (user `f34`, compiled 1600000000).

**`F3:RadioGNRScript` (from `radiognrscript.pex`):**
- `SongsPlayed` is an auto property (flags 7) on a plain Int variable; no reset or cap in this script.
- `F34_Add_SongsPlayed(afDelta)` does `::SongsPlayed_var += afDelta` and returns it (uncapped).
- `F34_QRestore`: for each variable, if the snapshot value (`F34_qsN`) is nonzero and the current value is 0, assign the snapshot value; `SongsPlayed` is slot 18.
- `F34_GameModeTick` only handles MS08/Harkness; `F34_FragBegin` sets `F34_FragUntil = GetCurrentRealTime + 2.0`; `F34_FragEnd` sets it to 0.0.
- `OnQuestInit` starts timer 1 with `F34_TickDelay`; `OnTimer` runs the tick with real-time guards.

**Fragments read:**
- `01057B30` (records song 1) and `0105A55A` (records song 12): shift history, write the song ID, then `F34_Add_SongsPlayed(1)`. No reset.
- `01065757`: shifts history, records song 13, sets `SongsPlayed = 0` (does not touch SongIntro).
- `010A870B`: sets `SongIntro = 0` and `SongsPlayed = 0`, shifts history, records song 12.
- `010A8716`: shifts history, records song 1, sets `SongIntro = 0` and `SongsPlayed = 0`.
- Reset fragments therefore also update the history, so "set the counter to 0" alone is **not** equivalent to a normal reset.

**User's `findstr` results across the extracted fragments:** 52 fragments contain `propset SongsPlayed` (resets) and about 120 call `F34_Add_SongsPlayed(1)`; the counts match the 120 increment / 52 reset fragments in Part B Section 5 and in A8. Only three of the 52 reset fragments were opened in this session. The value assigned in the other 49 was not read.

Files: `RadioGNRScript_pex_dump.txt` (the full instruction dump) and `pexdump.py`.

## A7. `GNR_Everywhere_F34.esp` and `GNR_No_Static_F34.esp` (assistant's raw parse)

Parser: `espdump.py` (reads TES4 header, groups, zlib-compressed records, subrecords).
- **Everywhere:** masters Fallout4.esm, Fallout34.esm; records: WRLD `F3_Wasteland` (0170003C, flags 0, no change visible), CELL 01002DB4, REFR 01FDDC93 and REFR 01D7D651 (`F34_RadioTx_RadioGalaxyNews_0` and `_1`, base 0001FA5A, flags 0xC00 = Persistent + Initially Disabled). Each has `XRDO` = (99.3, 1,000,000.0, 1,200,000.0, 0.0). Description: raises the range of the two GNR transmitters in `F3_Wasteland`.
- **No Static:** same masters; records: WRLD, CELL, REFR 01022488 (`F3_RadioGalaxyNewsRef01`, base 01022487, flags 0x400 = Persistent) with **no radio data**; description "converted for Fallout34.esm by the Fallout 34 mod converter".
- **Neither contains** sound descriptors, quests, scenes, INFOs or scripts. **Neither changes song volume.** Neither touches the song counter. They do not interfere with the guard or the song conditions.
- Agreement with Part B 4D (Claude A's screenshots). The record flags are not the live state; the enabler of the transmitters is still unknown.
- Volume, if wanted, lives in the 20 song sound descriptors (Part B 4B); a separate descriptor patch would be needed and was not built.

## A8. Prior package: self-recovery handoff (supplied this turn; read, not re-verified)

Read from `GNR_Self_Recovery_Session_Memory_2026-11-19.md`, `GNR_Session_Handoff_2026-11-19.md` and its README. Only the Markdown summaries were opened; the CSV audits and exports in that package were **not** independently checked here. It was produced in a different assistant session.
- **Reliable 01 is Save 11**: `SongsPlayed = 5`, `SongIntro = 2`, history `11, 8, 5, 3`.
- Full export of live quest `F34_Radio_RadioGalaxyNews` (QUST 0AD0EE64): 164 DIAL topics (82 per scene), 1,732 unique INFOs, 505 phases/actions per scene. 172 counter-changing fragments (120 increments, 52 resets), each with exactly one INFO in scene A and one in B (344 INFOs: 240 increment, 104 reset). Gates: increments need 0 or 1 (120 each); 100 ordinary resets need 2; two exceptional reset fragments need 1 (4 INFOs). **No audited INFO accepts SongsPlayed = 5.**
- **Anomalies:** song 8 (fragments `01057B29`, `010752A7`) conditions omit `LastSongPlayed3`; reset fragments `01074EF3` and `010A870A` write `LastSongPlayed = 1` while their conditions compare all four slots against song 2.
- **New objective:** a general, narrow self-recovery mechanism (ESP + compiled script), diagnostic mode first; valid-state no-op (0, 1, 2 untouched); do not blindly zero the counter because normal resets also update history; no repair loops; log during testing; failure-safe if the quest cannot be resolved. A test matrix (-1, 0, 1, 2, 3, 5, large) is in that package.
- **Conflict with this session's v0.2:** v0.2 is exactly the "blind set to zero, including value 2" behaviour that package warns against.

## A8b. The dev's radio-fix archive (`radiofix.rar`) — assistant's own parse

**Provenance:** given to the user by a main F34 developer ("old radio fix"). Opened with libarchive (no unrar available) and the plugins parsed with `espdump.py`. Fallout34.esm itself was not available, so **what the original records contain was not compared**; only what the fix records contain is known.

**Contents (344,224,012 bytes uncompressed):**
- `F34_RadioFix.esp` (163,064 bytes) — Fallout 3 stations. `F34_RadioFixNV.esp` (51,990 bytes) — New Vegas stations.
- `Sound/Voice/Fallout34.esm/`: `F34R_RadioMusic` 225 `.fuz`; `F3_MaleUniqueThreeDog` 524; `F3_MaleUniquePresident` 140; `F3_UniqueRadioPlay` 89; `F3_MaleUniqueVault101PA` 14; `F3_MaleUniqueOverseer` 6; `F3_MaleUniqueAutumn` 4; `F3_RobotProtectron` 2.
- `Sound/Voice/FalloutNV34.esm/`: `F34R_RadioMusic` 88; `FNV_NVDLC01MaleUniqueElijah` 73; `FNV_NVDLC01MaleUniqueDean` 49; `FNV_RobotProtectron` 1.
- File names are INFO form IDs (for example `009021CB_1.fuz`). **Copyright note:** the plugins say the content is built "from your own ... install" by `tools/radiofix.py`; the archive therefore holds converted game audio. Do not redistribute it; ask the developer for the tool.

**`F34_RadioFix.esp`:** masters `Fallout4.esm`, `Fallout34.esm`; description "Fallout 34 radio fix (FO3): songs and missing DJ lines for the Capital Wasteland radio stations, from your own Fallout 3 install. Built by tools/radiofix.py."
- Records: **225 INFO**, 15 DIAL, 5 QUST, 1 VTYP (`F34R_RadioMusic`, 02000800), 1 NPC_ (`F34R_RadioMusicVoice`, 02000801). Quests: `F34_Radio_RadioEnclave` (01DE8CB7), `F34_Radio_RadioGalaxyNews` (01D0EE64), `F34_Radio_RadioVault101` (019715B9), `F34_Radio_MS17AgathasRadio` (01E7CBE2), `F34_Radio_HD00HouseRadio` (01B67042).
- **All 225 INFOs name speaker 02000801 and carry a Start-Scene-on-End target.** Their conditions use the same script variables as the originals: `SongsPlayed` (172 uses), `LastSongPlayed` 1–4 (170–178), `SongIntro` (36), plus other stations' variables (`AlreadyPlayed`, `LastSong`, `LastSong2`, `LastSong3`).
- **Overlap with the user's GNR exports:** all **48** INFOs in `SongInfoExport(for0AEAECDA).csv` (the scene-A song topic) are in the fix; **none** of the 48 in `SongInfoExport(for0AC92CD7).csv` (scene B's mirror topic) are. 177 of the 225 are other INFOs. Sample (INFO `0ADBA880` in the user's load order, local ID `DBA880`, phase S96): speaker 02000801, start-scene target `0193BF68` (= scene A, `F34_RadioScene_RadioGalaxyNews`), conditions on `SongsPlayed` and all four history slots, a fragment script, name `S96`.
- **Not known:** whether the developer deliberately skipped scene B's 48 INFOs; what the originals look like (speaker, response audio); whether the matching `.fuz` for each GNR INFO exists in the archive (not cross-checked); which of the 225 are GNR vs other stations beyond the 48.

**`F34_RadioFixNV.esp`:** masters `Fallout4.esm`, `FalloutNV34.esm`; 88 INFO, 9 DIAL, 7 QUST, the same VTYP/NPC pair; same speaker plus start-scene pattern; its NV INFO samples check three history slots (not four). Covers NV stations only (Black Mountain, Christine, New Vegas TA, Casino Tops, Gomorrah, Ultra-Luxe, Country, etc.). **Part B Section 8 says not to use New Vegas material as GNR evidence; this applies to the NV plugin.**

**What this means (labelled):**
- *Record finding:* the developer's fix really does implement "speaker + `.fuz`" for 48 GNR song INFOs, so that approach is not hypothetical.
- *Conflict still open:* the user's GNR scene exports show **113 "Play Sound" actions in each scene** that name the song sound descriptors (`F34_RadioSnd_MUSLicensed...`) directly, next to 135 Radio-type actions whose sound is null (topic-based). So the files contain two ways a song could reach the player: the scene's own sound action, and an INFO line. Which one produces audible music in the game is **not established**. A tester does hear Easy Living, so at least some songs are audible without the fix.
- *Not explained by the dev's hint:* the counter runaway (the fix keeps the same counter conditions), and the song 1 / song 5 alternation.
- *Lead for the DJ side:* the archive holds 524 Three Dog voice files for `Fallout34.esm`; the dev says many DJ lines were never converted properly. That may relate to the tester's "Three Dog changes topic halfway through the news", but nothing in the files shows it.

## A8c. Song ID map (record-derived by the assistant from the user's exports)

Method: the fragment sources (`1_Scripts/fragments_639/*.psc`) give `LastSongPlayed = N`; `SongInfoExport(for0AEAECDA).csv` gives each INFO's phase name and fragment; the scene export `F34_RadioScene_RadioGalaxyNews_0A93BF68.txt` (505 phases, 505 actions) gives the "Play Sound" descriptor started at that phase (or its `_GO` phase). It agrees with Part B 5 ("S61 maps to 12, S72 maps to 1"). Re-check a few rows in FO4Edit before relying on it.

| Song ID | Song (descriptor) | Phases in the main song topic |
|---|---|---|
| 1 | Cole Porter — Anything Goes (`...ColePorterAnythingGoes`) | S72, S84, S96 |
| 2 | Tex Beneke — Guy (`...TexBenekeGuy`) | S71, S83, S95 |
| 3 | Ella Fitzgerald — Into Each Life (`...EllaFitzgeraldIntoEachLife`) | S70, S82, S94 |
| 4 | Danny Kaye — Civilization (`...DannyKayeCivilization`) | S69, S81, S93 |
| 5 | Billie Holiday — Easy Living (`...BillieHolidayEasyLiving`) | S68, S80, S92 |
| 6 | Billie Holiday — Crazy He Calls Me (`...BillieHolidayCrazyHeCallsMe`) | S67, S79, S91 |
| 7 | Roy Brown — Mighty (`...RoyBrownMighty`) | S66, S78, S90 |
| 8 | Roy Brown — Butcher (`...RoyBrownButcher`) | S65, S77, S89 |
| 9 | Bob Crosby — Way Back Home (`...BobCrosbyWayBackHome`) | S64, S76, S88 |
| 10 | Bob Crosby — Happy Times (`...BobCrosbyHappyTimes`) | S63, S75, S87 |
| 11 | Ink Spots — Maybe (`...InkSpotsMaybe`) | S62, S74, S86 |
| 12 | Ink Spots — I Don't Want to Set the World on Fire (`...InkSpotsIDontWant`) | S61, S73, S85 |
| 13–20 | not mapped (the 8 other song IDs; their INFOs are in other topics) | — |

Counter behaviour per song from `GNR_SongsPlayed_172_Fragment_CrossReference_2.csv` (self-recovery package): each ID 1–12 has 9 fragments (2 increments gated at counter 0, 2 gated at 1, 2 "ungated" increments in other topics, and 3 resets); IDs 13–20 have 6 increments and 2 resets. **Song 1 differs:** two of its resets (`01074EF3`, `010A870A`) are gated at counter **1** and flagged as mismatches, one (`010A8716`) at 2. Song 5: increments `01057B20`, `01057B2C`, `0105A555`, `0105A561`, `010750E6`, `010752AA`; resets `01074EEB`, `010A8706`, `010A8712` (gate 2). Song 9: increments `01057B1C`, `01057B28`, `0105A551`, `0105A55D`, `01074F2A`, `01075256`; resets `01074EE6`, `010A8702`, `010A870E`. The same-ID-twice-in-the-INFO-list counts reflect scene A and B copies.

## A9. Evidence ledger additions

| Class | Statement | Confidence |
|---|---|---|
| Verified from bytecode (assistant parser) | `SongsPlayed` is a plain auto property; `F34_Add_SongsPlayed` is an uncapped add; `F34_QRestore` restores a nonzero snapshot when the current value is 0 (slot 18); reset fragments also shift the history | High for the files read; parser not validated against Champollion |
| Verified from file | Everywhere/No Static contain no sound, quest, scene, INFO or script records | High |
| Verified from file | Tester log (v0.2) shows: first poll 1596; history 1,5,1,5 for ~25 min without any RESET; 35 RESET lines in ~7 min; flipping between several state tuples; two "now reads 1" after a write | High as a log reading |
| User-reported | With v0.1: Three Dog "music time", then news after a few seconds; A2 or A3 enabled -> songs work | Moderate |
| User-reported | With v0.2: songs play | Moderate; no log or save details |
| Tester-reported | Few songs in ~20 min, Easy Living ~4 times; pre-existing save; "standby"; heard-detail not remembered | Low; details missing |
| Inferred | Counter runaway/loop, multiple state sources, QRestore interplay, history-check failure (H1–H4) | Hypotheses only |
| Unknown | What triggered the 10:43:39 change; which save the tester used; why "started" is logged twice | — |
| Verified from file | The dev's `F34_RadioFix.esp` overrides 225 INFOs, all with speaker `F34R_RadioMusicVoice` and start-scene-on-end; 48 are GNR scene-A song INFOs; 0 of scene B's 48 | High for the plugin; originals not compared |
| Verified from file | GNR scenes contain 113 direct "Play Sound" radio actions each, naming the song descriptors | High for the export; in-game effect not established |
| Record-derived (assistant) | Song 5 = Easy Living, 1 = Anything Goes, 9 = Way Back Home (and IDs 2–4, 6–8, 10–12) | Moderate–high; spot-check in FO4Edit |
| Verified from log | New-save tester log: 0 at 11:18:45, 67 at 11:20:02 with history 9,9,9,9; 1,5,1,5 at 11:25:53; two resets of the valid value 2 | High as a log reading |
| Verified from log | Reset counter continued across a save/load (#35 -> #36); no new "started" after the reload | High |
| Tester-reported | New save: no 4-in-a-row repeats; new songs continue; Three Dog changes topic halfway through the news | Low–moderate; partly contradicted by the log; no detail on the topic change |
| Dev-reported (via user) | Songs need a speaker and `.fuz`; FO3/FNV DJ lines never properly converted; two fixes needed | Unverified for GNR; consistent with the dev's own plugin |
| Inferred | The 5 / 1 alternation = song 5 (0->1) then a song-1 reset gated at 1 (1->0) | Plausible; why song 5 is not excluded by history is unexplained |

## A10. Unknowns added this session

1. Which save did the tester use, and is its counter state related to Reliable 01 (Save 11)?
2. What was the tester doing at 10:19 and 10:43:39, and what did they hear?
3. Is the quest in `F34_GNR_Guard.esp` carrying the script twice (double "started")?
4. What writes to `SongsPlayed` many times a second, and where does 1596 come from?
5. Do the flipping tuples come from several script instances, restore logic, or something else?
6. Which song ID is "Easy Living", and are songs 1 and 5 the ones the mismatched reset fragments involve?
7. What value do the 49 unread reset fragments assign? (Only 3 of 52 were read.)
8. Which save and duration were used when the user reported "songs works" with v0.2?
9. Do `SetPropertyValue` writes always persist? (Two reads-after-write showed 1.)
10. Is the user's own v0.2 log similar to the tester's?
11. What exactly is the "Three Dog changes topic halfway through the news" event (cut-off line, wrong topic cutting in, how often, with or without the guard)?
12. Was `F34_RadioFix.esp` (or any other radio plugin) enabled in any tester run? Has anyone tested GNR with it?
13. Why does the dev's fix cover scene A's 48 GNR song INFOs but not scene B's 48?
14. Is audio produced by the scene's direct "Play Sound" actions, by the song INFOs, or both? Does GNR need the speaker / `.fuz` approach at all?
15. What is the original content of the 48 INFOs (speaker, response audio) in `Fallout34.esm`? (The ESM was not available.)
16. Why is song 5 not excluded by its own history check on the old save (history `5,1,5,1`)?
17. What produces the early jump (1596 within ~11 s of the first start; 67 in ~77 s on the new save) — a runaway of song 9's fragments or something else?
18. Why do the two start lines appear 13 s apart on the new save but in the same second elsewhere?
19. Which of the tester's songs were actually audible during the 23:20:02 and 10:43:39 episodes?

## A11. Recommended next steps (in order)

1. **Stop distributing v0.2.** Tell testers it is an experiment that changes the counter and also resets the valid value 2.
2. **Fix the duplicate start.** Open `F34_GNR_Guard.esp` (FO4Edit or Creation Kit) and check how many `F34GNRGuard` entries the quest carries; keep one. Record the ESP's size/hash and masters (not yet inspected by the assistant).
3. **Build v0.3, monitor only (never writes).** Specification:
   - poll every 1 s; log a line **whenever any monitored field changes** (not only `SongsPlayed`): `SongsPlayed`, `SongIntro`, `LastSongPlayed`–`LastSongPlayed4`, `LastNews`, `LastGreeting`, `LastGreeting2`, `ThreeDogDead`;
   - log `GetQuestRunning`/`IsRunning` of the GNR quest, the player's worldspace and cell, and `Utility.GetCurrentRealTime()` on every line;
   - log the **increment per second** when `SongsPlayed` rises by more than 2 between polls (marks a runaway) and keep a running count;
   - log the object's own identity once at start (`Self`) and a counter of how many `OnInit` calls happened, to test the duplicate-script idea;
   - log `OnPlayerLoadGame` and fast-travel/cell changes;
   - no `SetPropertyValue`, no resets. Keep the 11/18-style timestamps. The assistant has not written or compiled this version.
4. **Controlled runs, one change at a time** (same load order, same listening time, log attached):
   a. new game, monitor-only, no radio plugins;
   b. the tester's pre-existing save, monitor-only, no radio plugins;
   c. Reliable 01 (Save 11) with and without A2 / A3 per the v3.1.1 matrix;
   d. new game with `F34_RadioFix.esp` + its `Sound` folder (obtained from the developer, not redistributed), monitor-only;
   e. the same pre-existing save with the fix.
   Record per run: songs heard by name, whether the radio ever went silent, whether Three Dog's news changed topic mid-line, and the log.
5. **Map the remaining data (assistant can do this when the files are in the folder):** run `song_fragment_map.py` over all fragment dumps (or use the song map in A8c) to name songs 13–20; read the 49 unread reset fragments; check whether the dev's `.fuz` set covers all 48 scene-A INFOs and whether the originals have a speaker.
6. **Ask the developer:** (a) does the speaker / `.fuz` requirement apply to GNR songs, given the scenes' direct sound actions; (b) why only scene A's song topic is overridden; (c) can the fix tool be run by users on their own install; (d) is the counter runaway known; (e) what does he see for the song 1 / song 5 alternation.
7. **Only then design repair:** act on values below 0 or above 2; keep history; recover with the narrowest write; test with the matrix in A8 on disposable saves. Consider whether a repair is needed at all once the loop cause is known.
8. **Optional later:** other radios (Enclave Radio is in the dev's `F34_RadioFix.esp`). Test first; run a monitor-only guard on that quest before any repair.

**v0.3 expectations (to judge it against):** if the runaway is a fragment loop, the log should show `SongsPlayed` rising about once per second together with history filling with one song ID; if something else writes the counter, rises may be irregular. If the two start lines mean two instances, the `OnInit` counter will read 2 on one run.

## A12. Cautions added

- Do not call 2 an invalid value. Do not reset on `>= 2`.
- Do not treat the guard run as a controlled test: it writes, so it perturbs what it observes. Use monitor-only builds for diagnosis.
- Do not infer a cause from the user's or the tester's "it works" without saved logs, save names and durations.
- Tester logs may use a different time zone/date from the user's logs.
- Never claim a file was read unless it was opened (in A8 only Markdown summaries were read).
- Do not treat the song-name map as final until a few rows are checked in FO4Edit; it depends on counting phase indices in a text export.
- The dev's hint and the user's tester reports are **reports**; the dev's plugin proves what the plugin contains, not that GNR needs it.
- The `radiofix.rar` audio is converted game content; do not repost it. Do not attach it to a public thread.
- A log that records only when one field changes hides other changes; do not read "no log line" as "nothing happened".

## A13. Files produced this session (outputs folder) and what exists elsewhere

**Produced here:** `F34GNRGuard.psc` (current: v0.2; v0.1 is described in A4, original text is in the user's upload), `HOWTO_v0.2.md`, `pexdump.py` (PEX reader), `RadioGNRScript_pex_dump.txt` (decoded main script), `espdump.py` (plugin reader), `song_fragment_map.py` (maps fragment dumps to song IDs and counter actions; tested only on five dumps), this file. `compile_guard.bat` and `HOWTO_compile_and_test.md` came from the user's earlier session. The decoded dumps of the two song-end fragments and three reset fragments exist only in this conversation.

**Supplied by the user, read in this session:** `F34GNRGuard.psc`, `compile_guard.bat`, `HOWTO_compile_and_test.md`, `CreationKit.ini` text, `creationkitcustom.ini`, `CreationKitPrefs.ini`, a Papyrus Manager screenshot, `radiognrscript.pex`, two fragment `.pex`, three fragment dump `.txt`, `GNR_Everywhere_F34.esp`, `GNR_No_Static_F34.esp`, `radiofix.rar`, the v3.1.1 master (Markdown and PDF), `Fallout34_GNR_Claude_B_Package_v3_1_1(.zip, and an identical `_1` copy)`, `GNR_Self_Recovery_Handoff_Package_2026-11-19(.zip, and an identical `_1` copy)`, the tester's gist (3 logs), the user's v0.1 log and the tester's v0.2 log.

**Not available to the assistant:** `Fallout34.esm` / `Fallout34old.esm`; `F34_GNR_Guard.esp` itself (so its masters and script count are unverified); the user's v0.2 log; the 9,301-script `scripts.zip`; Reliable 01 and any save; the tester's plugin list; the rest of the 639 fragments as `.pex` (the `.psc` copies are in the v3.1.1 package).

## A14. Test-log template additions (add to the Part B template)

```
Guard build (none/v0.1/v0.2/v0.3) and ESP size/hash:
Script count on the guard quest (should be 1):
Save used (exact filename; new game / pre-existing / Reliable 01):
What the player was doing at each log timestamp (idle/standby, fast travel, interior, loading a save):
What was heard at those times:
Attach the full F34_GNR_Guard.0.log:
```

Add to every test record: `Radio plugins enabled (F34_RadioFix.esp / NV / Everywhere / No Static / A-tests):`, `Songs heard by name (not just IDs):`, `Did Three Dog change topic mid-news? when, what changed:`, `Guard build and whether it writes (v0.3 must say "monitor only"):`.

## A15. How to start a follow-up session

1. Give the new assistant this file first, then (optionally) the v3.1.1 package and the self-recovery package (they are summarised in A8 and in Part B).
2. Require it to read A2 (corrections) before anything else, and to keep monitor-only diagnosis separate from repair.
3. Ask it to produce v0.3 (monitor only, specification in A11) and the plan in A11, and to say clearly what it has not compiled or run.
4. Tell it that `GNR_Master_Session_Memory_v4_0.md` is an earlier draft of this document and is superseded.

---

# PART B — Master v3.1.1 (carried forward unchanged)

# Fallout 34 – Galaxy News Radio (GNR)
## Master Session Memory and Project Notes — v3.1.1 (19 November 2026)

**Purpose:** The single handoff document for continuing the Fallout 34 Galaxy News Radio investigation. A new person or AI should be able to understand the project from this file alone, then open raw evidence only for the specific question at hand (see Section 11).

**What changed in v3.1.1:** fixes documentation errors found in the v3.1 pre-flight audit: package/manifest file counts, an outdated cross-reference in the console note, and an over-broad sentence implying every INFO condition is a simple AND. It also clarifies where the package root folder sits inside the ZIP and preserves the exact v3.1 master in `9_Archive_Superseded/`. The technical corrections introduced in v3.1 remain in place. Claude A's original PDF and searchable text are retained in `6_Session_Updates/`. Earlier v3.1, v3, v2 and v1 masters are preserved for history.

**Evidence rule:** Keep direct file findings, user-reported in-game results, independent-tester reports, logical deductions, and untested ideas separate. Do not describe a likely cause as a proven cause. The assistant has not run the game; in-game results are reports from the user or testers.

## Read this first — current position

- **Best current lead:** on `Reliable 01`, song playback correlated with whether the `SongsPlayed` condition was present. This is not yet a proven root cause because the runtime value was never measured and the fresh-reload procedure was not confirmed.
- **Important wording:** the Reliable 01 baseline was run with **no GNR diagnostic test ESP** (`TestA`, `TestB`, or `A0`–`A3`) enabled. The user explicitly confirmed that `GNR_Everywhere_F34.esp` and `GNR No Static_F34.esp` remained enabled throughout. Do **not** describe this as a test with every GNR-related ESP disabled.
- **Test naming:** use the canonical IDs and filenames A1, A2 and A3. The user colloquially called them “Test A01”, “Test A02” and “Test A03”; those are aliases, not separate plugins.
- **Missing evidence:** the separate `scripts.zip` mentioned in Claude A's transcript (9,301 compiled scripts) is not in this package. The original `Fallout34.esm` / `Fallout34old.esm` binaries are also not included.
- **Next technical gap:** the 1,786 `F34_QSnap` mentions in `scripts.zip` were not classified into definitions versus real calls. Do not treat 1,786 as a call count.

### Evidence labels used in this document

- **Record / bytecode finding:** derived from a plugin, export, or script listing; note the exact file and whether it was independently rechecked.
- **Screenshot finding:** read from a user's FO4Edit or Mod Organizer screenshot; it may apply only to the visible record or snapshot.
- **User-reported result:** something the user observed in-game; it is not a direct runtime measurement by the assistant.
- **Independent-tester report:** an observation from another person's game setup; keep it separate from the user's runs.
- **Inference / unknown:** a plausible interpretation or an unresolved question, never a confirmed fact.

## Contents
1. [Current project status](#1-start-here-current-project-status)
2. [How GNR works and the counter cycle](#2-plain-language-explanation-of-how-gnr-works)
3. [ESM versions](#3-esm-versions-and-what-changed)
4. [Test plugins and reported results](#4-test-plugins-and-reported-results)
   - [4A. Independent testers and plugin inventory](#4a-independent-testers-plugin-inventory-and-master-file-safety)
   - [4B. Earlier investigation notes](#4b-earlier-merged-notes-17-nov-2026-pdf-f34-gnr-newpdf)
   - [4C. Reliable 01 tests](#4c-reliable-01-tests-in-claude-a-18-19-nov-2026)
   - [4D. Screenshots and auxiliary plugins](#4d-screenshot-and-auxiliary-plugin-findings-from-claude-a)
   - [4E. Main-script functions and caller search](#4e-main-script-functions-and-the-unfinished-caller-search)
5. [Archive and script findings](#5-what-the-project-archive-contains-and-what-the-scripts-show)
6. [Unknowns](#6-what-is-still-unknown)
7. [Recommended next steps](#7-recommended-next-steps)
8. [Cautions and working rules](#8-important-cautions-and-working-rules)
9. [Glossary](#9-quick-glossary)
10. [Archive inventory](#10-archive-inventory-and-coverage)
11. [File map](#11-file-map-where-the-raw-evidence-lives)
12. [Test-log template](#12-test-log-template)
13. [Starting a follow-up AI session](#13-how-to-start-a-follow-up-ai-session)

---

## Evidence ledger at a glance

| Class | Statement | Confidence |
|---|---|---|
| Verified from records | Song INFOs are silent handoffs gated by `SongsPlayed`, `LastSongPlayed1-4`, `SongIntro`, quest-running and transmitter conditions | High (record/plugin inspection) |
| Verified from records | Current ESM has a 0 → 1 → 2 → reset-to-0 counter cycle; reset offers only at N5 and N66 | High on records; **not confirmed in-game** |
| Verified from Claude A's bytecode reading | `F34_QRestore` can restore a nonzero snapshotted `SongsPlayed` value when the current value is 0; `F34_FragBegin/End` only pause a periodic check briefly; `F34_GameModeTick` does not change the song counter | Reported as directly read from `radiognrscript.pas`; not independently re-parsed in this session |
| Reported by user | On `Reliable 01`, baseline with no diagnostic test ESP = talk only; A1 = talk only; A2 and A3 = songs + talk | The two auxiliary GNR ESPs stayed enabled; reload procedure not fully recorded; A1 listen was shorter |
| Reported by user | A2/A3 played for a good amount of time and did not cut song duration; exact minutes/song count not recorded | Moderate |
| Reported by user, later retracted | A newly created save appeared to play songs with all patches off, but later became messed up after a few songs | **Do not use as evidence that patches are unnecessary** |
| Reported by user | `Fallout4` automatically creates an `exitsave` on quitting; user disabled use of that save for later tests | High as user report; effect on prior test state remains unknown |
| Reported by independent testers | Test A alone and Test B alone made radio work on their systems; disabling them broke it again | Separate external observations; do not merge with user's tests |
| Inferred | The `SongsPlayed` condition is the main condition correlated with silence in the Reliable 01 tests | Working inference, not proof of the actual runtime value/cause |
| Unknown | Actual `SongsPlayed` value in Reliable 01 when song INFOs are evaluated | Never measured |
| Unknown | Which script or game mechanism enables at least one transmitter at runtime | Not identified |
| Unknown | Which compiled scripts call `F34_QSnap` / `F34_QRestore`, beyond the older README's report of 56 CG02/CG03 fragment callers | Claude A's broad search was unfinished; see Section 4E |

# 1. Start here: current project status

The project is troubleshooting **Galaxy News Radio (GNR)** in Fallout 34, the Fallout 3 / New Vegas content port to Fallout 4. Three Dog's dialogue can play while music does not. The goal is to find why some saves show talk-only radio, identify the exact condition or saved state responsible, and make a safe fix without changing unrelated parts of the mod.

## Current best user test: Reliable 01

`Reliable 01` is a pre-project save that the user describes as showing the common GNR problem. In the Capital Wasteland, connecting to GNR with no diagnostic test patch produced Three Dog's conversation but no songs; there were gaps while the radio failed to find a song and moved on to the next conversation.

The user then tested the diagnostic patches one at a time. The reported outcomes were:

| Setup on Reliable 01 | Reported result | Important limitation |
|---|---|---|
| Baseline: no diagnostic test ESP | Conversation only; no songs | `GNR_Everywhere_F34.esp` and `GNR No Static_F34.esp` were still enabled; exact listening time not recorded |
| `F34_GNR_TestA1_SongsPlayed.esp` (user called this A01) | Conversation only; no songs | User listened for less time than A2/A3 |
| `F34_GNR_TestA2_LastSongPlayed.esp` (user called this A02) | Songs + conversation | Played for a good amount of time; exact minutes/song count not recorded |
| `F34_GNR_TestA3_SongIntro.esp` (user called this A03) | Songs + conversation | Played for a good amount of time; exact minutes/song count not recorded |
| `F34_GNR_TestA0_AllThree_control.esp` | Earlier report said silent | Not a fully documented timed Reliable 01 run |

The user said the test plugins were loaded one at a time and the same plugin list was used. The user explicitly confirmed that both `GNR_Everywhere_F34.esp` and `GNR No Static_F34.esp` stayed enabled during every Reliable 01 run. Therefore, “baseline/no patch” in this section means **no diagnostic test ESP**, not that every GNR-related ESP was disabled. It was **not confirmed** whether the exact original `Reliable 01` save was freshly reloaded before every run, with no intervening save writes. Keep that as an open test-method detail.

## Corrected interpretation of the earlier "new save, no patches" result

An earlier experiment seemed to show that a new save played songs with all patches disabled. The user later corrected that conclusion: the radio played for several songs, then became messed up again. The user thinks the Fallout 4 automatic `exitsave` may have retained state after A2/A3 tests, but that explanation has **not been proven**. Fallout 4 creates an `exitsave` when the game is exited; the user disabled using that save for subsequent tests.

**Retract the earlier v2 claim that a new save works normally with all patches off.** It is not valid evidence that the patches are unnecessary. Do not use the earlier old-save/new-save comparison as a controlled result; the identity and history of those saves were not pinned down in Claude A.

## Best current lead

Claude A parsed the test plugins and found that the original INFOs and A1 retain `SongsPlayed` checks, while A2 and A3 do not. The user's Reliable 01 results follow the same pattern: silence when the `SongsPlayed` check is present, songs when it is removed. This makes `SongsPlayed` the strongest lead, but does not prove the runtime value, why the condition fails, or whether a save/scene-state issue is involved.

The current ESM includes a reset path for the counter (Section 2). The actual `SongsPlayed` value in Reliable 01 has not been measured, and the reset route has not been confirmed in-game.

# 2. Plain-language explanation of how GNR works

GNR is controlled by **radio scenes**. A scene is a sequence of steps that can wait, start dialogue, play a song, or hand control to another scene.

A song is selected through a silent dialogue record called an **INFO**. The INFO has no spoken line and no visible text; it checks conditions and starts the scene phase that plays a licensed song. If no song INFO's conditions pass, the scene moves on to another talk phase. That matches the symptom of hearing Three Dog without music.

The song INFOs check conditions involving:

- `SongsPlayed`, a counter stored on the GNR quest script;
- `LastSongPlayed1-4`, which prevent a recently played song from immediately repeating;
- `SongIntro`, used for the song-introduction sequence;
- whether the GNR quest is running; and
- whether one of the two transmitters is enabled.

An INFO's conditions must be satisfied according to their condition flags. Do not assume every row is combined as a simple AND: an `Or` flag can make a group of rows alternatives. For INFO `0AED5399`, Claude A's screenshot showed the two transmitter checks grouped as transmitter 0 **OR** transmitter 1; the other required checks, including `SongsPlayed == 0` on that INFO, still apply. Do not generalise this exact row layout to every song INFO without checking it.

## The counter cycle – important correction

A later direct inspection of the current ESM corrected the earlier simplified theory that only counter values 0 and 1 are used. The later finding is:

1. One group of songs is offered when `SongsPlayed == 0`; playing one adds 1.
2. Another group is offered when `SongsPlayed == 1`; playing one adds 1 again.
3. A third group is offered when `SongsPlayed == 2`; playing one resets the counter to 0.
4. The intended cycle is therefore **0 → 1 → 2 → reset to 0** (three songs per cycle), not just 0 → 1 → reset.

The reset songs are only offered at two talk points, **N5 and N66**. They are not offered at the normal song-offer phases in the N34–N69 scene range; N66 is a separate talk phase where a reset offer is expected. The current ESM contains 104 INFOs using reset fragments, and all were reported to be in topics called by the scenes. The S73–S84 song path takes the counter to 2 and then flows into N66, where a reset song should be offered.

This flow was confirmed from plugin records, but **has not been confirmed in-game**. It corrects the earlier README claim that no live reset path had been found / that any value above 1 blocks every song. Those statements were based on an incomplete view of where reset fragments were attached.

---

# 3. ESM versions and what changed

There are two distinct builds in the project:

- `Fallout34old.esm` – the older build.
- `Fallout34.esm` – the current build.

The uploaded `Fallout34_1.esm` is byte-for-byte identical to `Fallout34.esm`; it appears to be a duplicate created with a filename suffix. The two current copies have the same size (**363,354,547 bytes**) and the same SHA-256 hash:

`16F35D6C23B9BD82E3BE3C3E7CC791DF2FFFAA29D9FF31806E7186D2FFECF7E9`

The old build's reported hash begins `53e89bfbc7df6d17323f`. The old and current files are different; the old build has about 9,000 fewer records.

## Old build

- Has one radio scene, scene A, with 435 phases.
- Its song INFOs start scene A itself, the scene that is already running.

## Current build

- Has two mirrored radio scenes, A and B.
- Adds 70 short wait phases (`N#_W`), each about 0.75 seconds, before talk phases.
- Scene A and scene B hand off to each other: song INFOs in one scene start the other scene rather than restarting the same scene.
- Retargets 172 INFOs and changes some existing ones; 468 of the 640 GNR INFOs shared between the builds were reported byte-identical.
- The current build contains a restructuring of the same radio flow area where the song failure was observed.

The conversation also reported that the old scene A has 435 phases, while the current scenes A and B each have 505 phases. The quests were reported identical between the two builds. Other non-GNR changes exist in the ESM diff but were not investigated in detail.

**What this proves:** the current ESM has a changed A/B radio-scene flow.

**What it does not prove:** who made that change, why it was made, or whether it was intended as the fix for the original problem. The old build's real-world radio behavior was not tested as part of the file comparison.

---

# 4. Test plugins and reported results

The diagnostic plugins changed conditions on the 96 song INFOs. The test variants were described as:

- **A0:** all three variable-check groups (`SongsPlayed`, `LastSongPlayed`, and `SongIntro`) added/retained (control).
- **A1:** adds the `SongsPlayed` variable-check group only; the base transmitter and quest-running checks remain.
- **A2:** adds the `LastSongPlayed` variable-check group only; the base transmitter and quest-running checks remain.
- **A3:** adds the `SongIntro` variable-check group only; the base transmitter and quest-running checks remain.
- **Test A:** base transmitter + quest-running checks.
- **Test B:** transmitter checks only; removes the quest-running check.

The reliable, latest user test is now the `Reliable 01` matrix in Section 1 and Section 4C. The earlier apparent new-save/no-patch success is retracted because the radio later became messed up after several songs and the save may have been affected by earlier test activity. Do not claim that the issue has been proven to follow save state based on that experiment.

The strongest current correlation is that the original INFOs and A1 keep the `SongsPlayed` condition and are silent, while A2/A3 remove that condition and play songs. That is a strong lead, not proof of the live variable value or root cause.

Do not repeat A0–A3 indiscriminately. First record the unanswered reload detail. If a repeat is needed, use the same original `Reliable 01` source save for every test, freshly reload it each time, keep the rest of the load order unchanged, run each variant for the same timed duration, and record songs heard.

---

# 4A. Independent testers, plugin inventory, and master-file safety
*(Added in v2 from `Fallout34_GNR_Session_Memory_2026-11-18_Continued.pdf`, which v1 did not include.)*

## Independent tester results (reported, not verified by the assistant)

| Environment | Configuration reported | Observed result |
|---|---|---|
| Independent testers | Test A alone, then Test B alone; no other archive patches | Radio worked with either; disabling the patch broke it again |
| User's own system | Earlier claim that radio worked with archive patches disabled | **Retracted by user**; see Section 1 and 4C |

Keep these as **separate observations**. Do not average them into one conclusion. The independent results strengthen the case that the Test A / Test B condition changes matter on those setups; they do not prove why the user's system differed, and they do not prove `GetQuestRunning` is the root cause.

**How this relates to Section 1:** Claude A's later clarification retracts the earlier "new save works with patches off" conclusion. The Reliable 01 results are now the main user-side test record. The independent tester results remain separate and are not explained by the user's later correction.

**Note discrepancy to keep visible:** one earlier note said both Test A and Test B played songs; another said no test result had been reported yet and defined Test B as Test A minus `GetQuestRunning`. Timing and context of those notes are uncertain.

## Diagnostic plugin inventory (structural counts from binary inspection, not runtime tests)

All six diagnostic variants reportedly override the same 96 song INFOs. Added variable checks use CTDA function ID 629 with CIS2 metadata such as `::SongsPlayed_var` and `::LastSongPlayed*_var`.

| Plugin | Structure | CTDA count |
|---|---|---:|
| `F34_GNR_TestA.esp` | Two transmitter checks + `GetQuestRunning` on the 96 INFOs | 288 |
| `F34_GNR_TestB.esp` | Two transmitter checks only (removes `GetQuestRunning`) | 192 |
| `F34_GNR_TestA0_AllThree_control.esp` | Base + `SongsPlayed` + `LastSongPlayed` + `SongIntro` groups | 814 |
| `F34_GNR_TestA1_SongsPlayed.esp` | Adds `SongsPlayed` checks (96) | 384 |
| `F34_GNR_TestA2_LastSongPlayed.esp` | Adds `LastSongPlayed` checks (382: 94 INFOs × 4, 2 INFOs × 3) | 670 |
| `F34_GNR_TestA3_SongIntro.esp` | Adds `SongIntro` to 48 INFOs | 336 |
| `GNR_Everywhere_F34.esp` | Description: increases range of two GNR transmitters in `F3_Wasteland`; effect not independently verified | — |
| `GNR No Static_F34.esp` | Overrides `F3_RadioGalaxyNewsRef01`; effect versus masters not independently verified | — |

A0 contains all three added groups (526 additional conditions). The bundle's `Patches/` folder holds all eight files (`GNR No Static_F34.esp` has a space in its name, which breaks some command-line tools).

## Master-file safety

The inspected ESPs do not rewrite `Fallout34.esm` on disk. They supply overrides while enabled; disabling one removes its override unless another plugin wins the same record. A running game can still write quest and scene state into a save, which is separate from editing a master. This statement covers the inspected ESPs only, not unrelated external tools, scripts, or manual edits.
---

# 4B. Earlier merged notes (17 Nov 2026 PDF `F34 GNR NEW.pdf`)
*(Added in v2. This PDF predates the counter-cycle correction in Section 2, so its "only 0 or 1 pass" statements are **superseded**. Items below are the parts that add something.)*

**Setup facts recorded:** FO4Edit 4.1.5f; Fallout 4 at `C:\Games\Fallout 4`; GNR scripts are in `Fallout34_2 - Main.ba2`. xEdit shows `Fallout34.esm` at index `0A` while dumps and logs show `01`; compare only the last six digits. The Papyrus log has no GNR lines; `F34MUSIC` logs a music-stack clear on every load.

**Live vs shell topics:** the live set is quest `F34_Radio_RadioGalaxyNews` (`0AD0EE64`). The 78 `F3_RadioGNR...` topics under `F34_DialogueShared` are empty shells, not the live radio.

**Ruled out on paper (as of 17 Nov):**

| Suspect | Evidence | Status |
|---|---|---|
| Missing scripts / loose override / missing variables | `radiognrscript`, `radiostation`, `radiogate` and 639 fragments in the archive; variable names match the conditions; no GNR errors in log | Cleared |
| Missing song files | All 20 `.wav` files exist under `sound\f3\songs\radio\licensed\`; every descriptor matches one | Cleared |
| Sound settings | All 20 descriptors: `AudioCategoryRadio`, `SOMStereo`, 12.78 attenuation, no looping; loudness of the `.wav` files unchecked | Cleared on paper |
| Transmitter state | 17 Nov note said both were enabled; Claude A later inspected screenshots showing both are Persistent + Initially Disabled in the master. Successful A2/A3 runs imply at least one satisfied the transmitter condition. | **Not fully resolved**; actual runtime state and enabling source unknown (Section 4D) |
| Scene phase missing or silent | B has S73 (Ink Spots), A has S96 (Cole Porter) | Cleared |
| Voice files for song INFOs | Not needed; "0 voice files" lines concern Radio New Vegas | Not a problem |
| Modder's `.fuz` / speaker theory | Contradicts how songs are built | Unsupported |
| Wrong worldspace | Still failed in the Capital Wasteland | Weakened |

**Console dead end:** the console cannot read the counter (`GetVMQuestVariable` reports "Param type 74 unimplemented"). A console read of `SongsPlayed` has already been tried and failed; do not suggest it as an untried way to measure the value. The unresolved counter-value question is in Section 6, and the remaining measurement options are discussed in Section 7.

**Other observations:** 12 of the 20 song descriptors are also referenced by the House radio scenes (`HD00HouseRadio`); the other 8 ("Generic") are GNR-only. Scene A calls song topic `0AEAECDA` at 11 points (action indexes 146, 149, 154, 156, 247, 249, 260, 264, 268, 272, 276); scene B mirrors it with `0AC92CD7`. About 34 talk segments come before the first of the 11 offer points. INFO `0AED5399` has flags Start Scene on End, Random, Random End, End Running Scene, an empty text, and a null sound file; its single fragment is named `Fragment_End` but flagged OnBegin. Claude A later inspected one FO4Edit screenshot for INFO `0AED5399`: conditions #4–#7 are "Not equal to 1" on that INFO. Do not generalise this screenshot alone to every INFO; see Section 4D. A third party's `F34_RadioFix` log (779 DJ lines, 225 song INFOs fixed across several stations) suggests radio problems beyond GNR, but none of its 87 unmatched songs is one of the 96 triggers and the log is truncated, so it proves little. Only scene A has "Begin on Quest Start".

**Earlier hypothesis list (17 Nov, in its own order):** counter stuck or reset by `F34_QSnap`/`F34_QRestore`; variables not resolving at runtime; song topics rarely reached; silent-line problem (empty-text INFO with Start Scene on End never "ending"); runtime quest/transmitter checks failing despite looking fine. Section 5 has since weakened the `F34_QSnap`/timer ideas.

**Test-outcome decision table (from that plan):**

| Result | Meaning / next step |
|---|---|
| Test A plays songs | Audio, scenes, INFOs fine; a variable condition blocks. Re-add condition groups to find which |
| A silent, B plays | The quest-running check is the blocker |
| Both silent | Song topics probably never reached: read the N34 talk INFOs (topic `0AB326D6`) and topics `0AE97EDA`, `0AD68B0C` |
| Song starts, no sound | Audio side: check the Papyrus log and descriptor paths, then test one song as a `.fuz` |

**Tools mentioned** (not in the bundle unless listed in `5_Tools/`): `ExportRecordList.pas`, `ExportSongInfos.pas`, an ExportFullInfo script, `ba2_gnr_check.py`, `ba2_extract_script.py`, `ba2_extract_gnr_script.py`, `MakeTestA.pas`, `MakeTestB.pas`. The test ESPs are diagnostics, not release patches, and would overwrite another F34 version of those INFOs. Use several fresh loads per test because the INFO is picked at random.

# 4C. Reliable 01 tests in Claude A (18–19 Nov 2026)

This section records the updated user account from Claude A's 21-page transcript. It supersedes the earlier ambiguous "old save vs new save" summary.

- `Reliable 01` is a pre-project save the user describes as a common/baseline GNR no-song save.
- With no diagnostic test patch, Three Dog's conversation played but no music was selected; there were gaps before the next conversation.
- A1 (user alias “Test A01”; file `F34_GNR_TestA1_SongsPlayed.esp`) produced conversation only.
- A2 (user alias “Test A02”; file `F34_GNR_TestA2_LastSongPlayed.esp`) and A3 (user alias “Test A03”; file `F34_GNR_TestA3_SongIntro.esp`) produced songs + conversation. The user said the songs played for a good amount of time and were not cut short. Exact minutes and song counts were not recorded.
- A1 was listened to for less time than A2/A3. A timed A1 comparison is still desirable.
- The user said patches were loaded one at a time and the same plugin list was used. Whether `Reliable 01` was freshly reloaded from the original source before every run remains unanswered.
- Both `GNR_Everywhere_F34.esp` and `GNR No Static_F34.esp` were explicitly confirmed enabled during all these tests. The test ESPs were at the bottom of the Mod Organizer list; only the selected test variant was enabled for an individual run, according to the user's description.
- `Fallout34.esm` was enabled in the shown load-order snapshot; `Fallout34old.esm` was not listed. The user's `Fallout34.esm` was reported as **363,354,547 bytes** (about 346 MB), matching the previously recorded current-build size. This confirms size only, **not SHA-256 identity**. The user's phrase “all master files were enabled” was not a complete list of every active master; the visible snapshot confirms `Fallout34.esm` enabled and `Fallout34old.esm` absent.
- The user's earlier "new save + all patches off = radio works" conclusion is withdrawn: it initially played songs but became messed up after several songs. The user suspects an `exitsave` may have retained test-related state, but no causal link was proven.

**Interpretation:** Among the tested Reliable 01 configurations, the condition that is present when songs fail and absent when songs play is `SongsPlayed`. That is the strongest current lead. The actual counter value was not read, and the unequal A1 listen time / unconfirmed fresh-reload procedure limit the strength of the comparison.

Source: Claude A transcript, especially pages 6–10 and 17. The full PDF and searchable text are in `6_Session_Updates/`.

---


# 4D. Screenshot and auxiliary-plugin findings from Claude A

## INFO `0AED5399` screenshot

Claude A inspected the user's FO4Edit screenshots and compared the shown INFO with the existing export. The transcript records the following for **this one INFO only**:

- Conditions #4–#7 compare the four `LastSongPlayed` variables as **Not equal to 1**.
- The two transmitter conditions use an `Equal to / Or` relationship for transmitter 0 and `Equal to` for transmitter 1. Claude A described the intended logical grouping as transmitter 0 **or** transmitter 1 enabled, plus the other required conditions.
- `SongsPlayed` on this INFO is **Equal to 0**.
- For this INFO's export flags only, Claude A decoded `10000000` as Equal to, `00000000` as Not equal to, and `10010000` as Equal to / Or.

Do not treat a single INFO screenshot as proof that every one of the 96 INFOs has identical comparison operators. The two song CSVs and test plugins are the broader evidence sources.

## `GNR_Everywhere_F34.esp` vs `GNR No Static_F34.esp`

Claude A inspected both plugins and compared them with the user's screenshots:

| Detail | `GNR_Everywhere_F34.esp` | `GNR No Static_F34.esp` |
|---|---|---|
| Author/description | "Fallout 34 GNR everywhere"; says it raises the range of two GNR transmitters in `F3_Wasteland` | "Fallout 34 mod converter"; description says converted for `Fallout34.esm` |
| References overridden | Two transmitter references: `0AFDDC93` and `0AD7D651` | One reference: `F3_RadioGalaxyNewsRef01` (`022488`) |
| Data observed | Frequency 99.3; modifies transmitter radio range values | No radio or static field was found; only position and a persistent flag were visible |
| What remains unknown | Whether each of the four changed values is specifically a range value, and whether the original mod description accurately describes the in-game effect | Whether the original FO3 mod removed static and whether that effect survived conversion |

The two plugins touch different references and do not directly override one another. Neither contains quest, scene, dialogue INFO, or script records, so neither directly changes the GNR song INFO conditions.

**Range values transcribed from Claude A's screenshots (recheck before relying on them):** transmitter 0 was read as changing from `48,000 / 80,000` to `1,000,000 / 1,200,000`; transmitter 1 was read as changing from `0 / 0` with “Ignores Distance Checks” to `1,000,000 / 1,200,000` without that flag. Claude A specifically said the transmitter 0 numbers were worth a second look. The plugin description says it raises range, but the exact semantics of all four values were not independently confirmed.

## Transmitter flags and runtime state

- In `Fallout34.esm`, both transmitter references `0AFDDC93` and `0AD7D651` are marked **Persistent, Initially Disabled**. `GNR_Everywhere_F34.esp` has the same flags; it did not introduce them. Neither record has an Enable Parent.
- `GNR_Everywhere_F34.esp` changes radio range data, but that is not the same as enabling a transmitter.
- A2 and A3 retained the transmitter `GetDisabled` checks and still played songs. Therefore at least one transmitter satisfied the plugin condition during those runs; Claude A interpreted this as at least one transmitter being enabled/usable at runtime. This is an inference from the successful test and condition structure, not a direct live-state read. Claude A searched the main GNR script and the 639 GNR fragments and did not find the enabling action. The actual enabler and which transmitter satisfied the condition remain unknown.
- The 17 Nov note saying both transmitters were simply "enabled" should not be treated as verified runtime state. The screenshots show their record flags, not their live state in the game.

Source: Claude A transcript pages 11–13 and 16–18. One transmitter 0 range value was read from a screenshot and Claude A explicitly recommended a second look.

---


# 4E. Main-script functions and the unfinished caller search

Claude A reports directly reading these functions from the complete bytecode listing `1_Scripts/main_script/radiognrscript.pas`. They are functions inside the main script `F3:RadioGNRScript`, **not five separate `.pex` files**. This explains why searching the BA2 archive for files named `F34_QSnap`, `F34_QRestore`, etc. returned no results.

| Function | Claude A's bytecode finding | Relevance |
|---|---|---|
| `F34_QSnap` | Before the quest starts, copies quest variables into a snapshot array; `SongsPlayed` is in slot 18 | Can preserve a nonzero counter value in a snapshot |
| `F34_QRestore` | After the quest starts, if the snapshotted `SongsPlayed` is nonzero and the current value is 0, restores the saved value; same pattern applies to other variables | Could reintroduce a nonzero value, **if it runs for the GNR quest in the failing save**; that has not been shown |
| `F34_FragBegin` | Sets a timer to current time + 2 seconds, pausing the periodic check for that short interval | Not a permanent counter lock |
| `F34_FragEnd` | Clears that timer to 0 | Not a counter reset |
| `F34_GameModeTick` | Runs the unrelated Harkness/MS08 exploit logic; does not touch `SongsPlayed` | Not the cause of a counter value by itself |

The 172 fragments that use `F34_FragBegin` call `F34_FragEnd` at the end. The pause expires by itself after about two seconds. This does not support the earlier idea that a fragment could freeze the periodic tick indefinitely or that the tick itself holds the song counter.

## Important caller-search status

The nested README already preserved in `9_Archive_Superseded/README_F34_GNR__nested_revised.md` reports **56 callers** in CG02/CG03 fragments, operating on their own quests, and says no GNR fragment calls the functions. Claude A independently found no calls in the main GNR script or the 639 GNR fragments. Those statements are not necessarily contradictory: the 56 older callers are outside the GNR fragment set.

Claude A later searched a separate `scripts.zip` reportedly containing **9,301 compiled scripts** and found **1,786 files mentioning `F34_QSnap`**. That is a raw mention count, not a confirmed count of actual call sites. Claude A had started separating function definitions from real references but the session expired before results were produced.

**Important availability note:** that separate `scripts.zip` is referenced as an attachment in the Claude A transcript, but it is **not included** in the current v3.1 Claude B package or in the files supplied to this session. Do not pretend its contents are available. To finish this branch, Claude B will need that archive (or a fresh equivalent extraction of compiled scripts) and must distinguish definitions, references, and actual call sites. The current conclusion about whether `F34_QRestore` affects GNR runtime remains unresolved.

Source: Claude A transcript pages 18–20; existing nested README for the 56 CG02/CG03 callers.

---

# 5. What the project archive contains and what the scripts show

The original upload was `Fallout34_GNR_Actual_Project.rar` (a RAR archive, not a ZIP). The current working evidence library is the `Fallout34_GNR_Lean/` folder inside `Fallout34_GNR_Claude_B_Package_v3.1.1.zip`. The current package also includes Claude A's transcript and addendum under `6_Session_Updates/`. The original project archive contained two nested ZIP files under `Papyrus_Source/`:

- `gnr_psc.zip` – 639 GNR topic-info fragment source files (`.psc`).
- `upload_me.zip` – decompilation reports and main-script diagnostic outputs, including a README.

The RAR also contains expanded copies of some project material. The two README Markdown versions are preserved verbatim in `9_Archive_Superseded/`.

## The 639 GNR fragments

The fragments are named `tif_f3_radiogalaxynewsquest_<hex>.psc`. Each is a small script attached to a GNR dialogue INFO. The hex in the filename is the original Fallout 3 INFO FormID with load-order byte `01`, not the F34 FormID. To map a fragment to the F34 INFO, open the INFO in FO4Edit and inspect its Papyrus Fragments tab.

The archive README's searches reported:

| Fragment type | Count | Behaviour |
|---|---:|---|
| Song-play increments | 120 | Calls `F34_Add_SongsPlayed(1)`; shifts `LastSongPlayed1-4` and sets `LastSongPlayed` to a song number 1–20 |
| Song-play resets | 52 | Sets `SongsPlayed = 0`; also updates last-song bookkeeping |
| Intro fragments | 52 | The README's count needs correction; see below |
| Other fragments | Remaining files | Do not change `SongsPlayed` |

All 120 increments add exactly 1; all 52 reset fragments set exactly 0. The `F34_Add_SongsPlayed` helper is uncapped. The 104 reset INFOs found in the current ESM correspond to the reset logic being present in the two-scene radio flow. This distinguishes the number of fragment scripts from the number of INFO records that attach/use them.

### Corrections to the archive README

The conversation found these mistakes or clarifications:

- **Intro fragments:** the README says 52 fragments set values 1–12. The corrected breakdown is 12 set values 1–12, 36 set the value to 0, and 4 set it to −1.
- **`Fragment_End`:** seven fragments (`01057B11`–`01057B17`) use `Fragment_Begin` and only touch `DadStoryVar`. They are not song-related. Therefore, the README claim that every fragment uses `Fragment_End` is wrong.
- **Song CSV duplicates:** both song CSVs are exactly duplicated 2×, with 407 unique rows each. The reason for the duplication is unknown.
- **Intro/song number mapping:** S61 maps to `LastSongPlayed` / `SongIntro` 12 and S72 maps to 1, in all three groups. Whether that matches Three Dog's spoken intro lines was not verified.

## Main script: `F3:RadioGNRScript`

The main source script `radiognrscript.psc` is truncated because Champollion crashes while decompiling it. The latest project README says the `.pas` file is a complete bytecode listing (60,094 bytes), and the strings extraction contains 275 identifiers. The earlier root README incorrectly treated the `.pas` output as uncertain / possibly invalid; the nested README is a revised note that corrects this point.

The useful findings from the complete bytecode listing, as described in the nested README, are:

- `SongsPlayed` is a conditional variable with initial value 0, so it starts at 0 and is visible to dialogue conditions.
- The helper-function details from Claude A's later direct bytecode reading are in Section 4E. The functions are inside `F3:RadioGNRScript`, not standalone script files.
- `F34_FragBegin` / `F34_FragEnd` only pause a periodic check briefly (about two seconds); they do not directly write the song counter or hold the timer indefinitely.
- `F34_GameModeTick` handles the unrelated Fallout 3 MS08 / Harkness logic and does not change `SongsPlayed`, `SongIntro`, or `LastSongPlayed`.
- The nested README reports 56 `F34_QSnap` / `F34_QRestore` callers in CG02/CG03 fragments, working on their own quests, and no calls in the 639 GNR fragments. Claude A's later search across a separate 9,301-script archive was incomplete; see Section 4E.

The main script's timer helpers are not the leading explanation for silence. The possible relevance of `F34_QRestore` depends on whether it can be invoked for the GNR quest in the user's runtime; that remains unproven.

---

# 6. What is still unknown

1. What exact value does `SongsPlayed` have in `Reliable 01` when the next song INFO is evaluated?
2. Is the Reliable 01 source save freshly reloaded before each A1/A2/A3 run, with no save writes between runs?
3. What were the exact listening durations and song counts for the baseline, A1, A2 and A3 runs? A1 was shorter; exact times were not recorded.
4. What code or game mechanism enables either transmitter at runtime? The records show both are Initially Disabled, while successful A2/A3 runs imply at least one transmitter satisfied the INFO condition.
5. Does `F34_QRestore` ever run against the GNR quest in the user's game? The older README reports 56 CG02/CG03 callers operating on their own quests; Claude A's broader 9,301-script scan was unfinished.
6. Where is the `scripts.zip` mentioned in Claude A's session, and can the 1,786 `F34_QSnap` mentions be separated into definitions, references and actual call sites? That ZIP is not inside the current v3.1.1 Claude B package.
7. Does Reliable 01 reach the N5 and N66 reset-song offers in-game as expected?
8. Do House radio songs play? They share 12 of the 20 sound descriptors.
9. Do silent song INFOs with the “Start Scene on End” flag behave as intended in Fallout 4? A vanilla radio INFO could be compared.
10. Do the Three Dog intro lines match the S61/S72 song-number mapping?
11. Which 12 files made up the Gist that earlier sessions referred to? The former `Source_Exports/` folder reportedly held 13 files; the mapping was not reconciled. The large exports have not all been read end-to-end in the earlier v2 pass.
12. The current ESM size matches the known current build, but was its SHA-256 hash ever checked against the exact file used in the Reliable 01 tests? Not in Claude A's session.

**Current working inference:** `SongsPlayed` is the condition that best correlates with the Reliable 01 failure. A nonzero snapshotted value could potentially be restored by `F34_QRestore`, but neither the runtime value nor a GNR call to that function has been established. Do not elevate this to a proven cause.

# 7. Recommended next steps

1. **Preserve the source save.** Keep `Reliable 01` untouched. Continue disabling/avoiding the automatically generated `exitsave` during controlled tests, as the user chose, and record exactly which save file is loaded.
2. **Resolve the test-method gap before drawing a stronger conclusion.** Confirm whether each Reliable 01 test was loaded fresh from the original source save. If not, repeat only the necessary A1/A2/A3/baseline comparison, one variant at a time, with the same load order and a matched listening duration. Record exact minutes and song counts. Do not use a save created by a previous test as the next test's baseline.
3. **Continue the compiled-script caller search.** Obtain the `scripts.zip` that Claude A used (reportedly 9,301 PEX files), or regenerate an equivalent set. Separate definitions from actual call sites for `F34_QSnap` / `F34_QRestore`; reconcile with the older README's 56 CG02/CG03 callers. Do not search for these five functions as separate filenames; they are functions inside `F3:RadioGNRScript`.
4. **Find the transmitter enabler.** Search relevant scripts and load-order plugins for actions that enable references `0AFDDC93` and `0AD7D651`. The two reference records being Initially Disabled does not explain which one becomes enabled at runtime.
5. **Measure or isolate `SongsPlayed`.** The console read already failed (`GetVMQuestVariable`: "Param type 74 unimplemented"). Use a safe diagnostic/probe approach only after reviewing the existing evidence and defining what the test proves. Do not change the counter or build another ESP yet.
6. **Check the reset route in-game.** If the test setup allows, record whether the N5/N66 reset offers are reached after the 0 → 1 → 2 → reset-to-0 cycle.
7. **Only consider a script change after confirming the failure mode.** If the counter is proven to be stuck or restored, then a targeted fix may be designed. Recompilation requires a Papyrus compiler; its availability must be confirmed before proposing a source edit.
8. **Do not rebuild or reconvert a clean Fallout 4 installation yet.** The current evidence can still be narrowed on the existing build with controlled tests and script-call inspection.

# 8. Important cautions and working rules

- An ESP patch does not permanently rewrite the ESM file on disk. Disabling a patch removes its overrides; it does not reset variables already stored in a save.
- A save can retain quest-variable values and running-scene state.
- The earlier "new save + all patches off = radio works normally" result was retracted by the user because the radio became messed up after several songs. Do not use it as evidence that patches are unnecessary.
- Do not assume `SongsPlayed` is definitely the cause until it is measured or isolated on Reliable 01.
- Do not claim the same Reliable 01 save was freshly reloaded for every test; that detail remains unanswered.
- Do not claim both transmitters are simply enabled. Their plugin records show Persistent + Initially Disabled; at least one became usable during A2/A3 runs, but the enabler is unknown.
- The Claude A `scripts.zip` is not included in the current package; the 1,786 QSnap mentions have not been classified into actual callers.
- The current ESM's reset path is present in live topics according to direct record inspection; do not repeat the earlier claim that no reset INFOs are attached to live topics.
- Do not use New Vegas-specific INFOs or New Vegas-specific radio records as evidence for the Fallout 34 GNR implementation.
- Keep original ZIPs and ESM files unchanged. Work on copies and keep tests reproducible.

---

- **Standing rules from the user's earlier sessions (added in v2):** do not guess; ask when a missing detail changes the conclusion; never say a file was read unless it was retrieved and checked to its end; do not treat filenames, summaries, or snippets as substitutes for source files; do not create or edit another diagnostic ESP until the original implementation and evidence are understood; change one variable at a time; keep a ledger of verified-from-source / reported / inferred / unknown; distinguish record overrides, master-file edits, save-state changes, and runtime behaviour.
- **Scope rule:** `ba2_radio_report.txt`, `ba2_voice_report.txt` and `radio_dump.txt` are New Vegas material. `fo4_radio_lookup.txt` and `gistfile1.txt` are Fallout 4 comparison material. None is evidence for how `Fallout34.esm` configures GNR.

# 9. Quick glossary

- **ESM:** the main plugin file that contains the mod's records.
- **ESP:** a patch plugin that overrides or changes records while enabled; it does not rewrite the ESM on disk.
- **Save state:** game values and running-game state stored in a save file.
- **Scene:** the ordered steps that control when the radio waits, talks, plays a song, or starts another scene.
- **INFO:** a dialogue record. Song INFOs are silent records that check conditions and start song phases.
- **TIF / fragment:** a small Papyrus script attached to a topic INFO.
- **Papyrus:** Fallout's scripting language.
- **PEX:** compiled Papyrus script; **PSC** is source text; **PAS** here is the bytecode listing created by the decompiler's assembly mode.
- **FO4Edit / xEdit:** a tool for inspecting and editing Fallout 4 plugin records.
- **`SongsPlayed`:** the counter used by GNR song INFO conditions.
- **`LastSongPlayed1-4`:** history values used to avoid repeating recent songs.
- **`SongIntro`:** a variable used by the intro/song sequence.

---
# 10. Archive inventory and coverage

**Original supply.** `/mnt/data/Fallout34_GNR_Actual_Project.rar` (RAR v5, 695 entries) contained two nested ZIPs and expanded copies. A later supplied `Fallout34_GNR_Actual_Project.zip` (685 files) holds the same project plus a `Reference/` folder with three notes files: the 17 Nov session memory (`.md`, identical in substance to v1's former Appendix C), the 17 Nov "merged investigation notes" PDF (`F34 GNR NEW.pdf`), and the 18 Nov continuation PDF.

- `Papyrus_Source/gnr_psc.zip`: 639 `.psc` fragment scripts. Byte-identical to the extracted `gnr_psc/` folder.
- `Papyrus_Source/upload_me.zip`: 12 files (README, two `.psc`, one `.pas`, CSV, logs). Byte-identical to the extracted `upload_me/upload_me/` folder.
- Root `radiognrscript.psc` and `.pas` are byte-identical to `psc_main/radiognrscript.psc` and `asm/radiognrscript.pas`.

**Correction to v1:** v1 stated that no PDF was present. That was true of the RAR as inspected then, but the bundle now supplied contains two PDFs. Their content is incorporated in Sections 4A and 4B, and their full text is kept in `9_Archive_Superseded/`.

**Two README versions** exist (`README_F34_GNR.md`, archive root, 10,328 bytes, SHA-256 `56be3799201e872f905f5412d5972527eae9cd3322a7a662920a9b357fb25c0e`; nested copy, 9,494 bytes, SHA-256 `f100956b39ff49b6925aa7242a5939766a6a6aaae67bb1ae4025ea3cdd3a2df6`). The nested one is the more complete revision for main-script analysis; the later findings in this master further correct the counter/reset interpretation. Both are kept verbatim in `9_Archive_Superseded/`.

**Current v3.1.1 package check:** the ZIP contains **696 files** under `Fallout34_GNR_Lean/`. `MANIFEST_SHA256.txt` contains **695 SHA-256 entries**, covering every other file; the manifest does not list its own hash. All 695 entries were checked against the files in this v3.1.1 package and matched. The original ESM binaries and Claude A's separate 9,301-script `scripts.zip` are not included.

---

# 11. File map: where the raw evidence lives
(Full per-file table with sizes: `01_FILE_INDEX.md`.)

| Question | Open this |
|---|---|
| What does a fragment script do? | `1_Scripts/fragments_639/tif_f3_radiogalaxynewsquest_<hex>.psc` (hex = FO3 INFO FormID with `01` prefix) |
| Main script logic | `1_Scripts/main_script/radiognrscript.pas` (complete bytecode); `.psc` is truncated by a decompiler crash |
| Decompile run evidence | `1_Scripts/decompile_run/` (`report.txt`, `summary.csv`, logs) |
| Scene phases and handoffs | `3_Exports_F34/F34_RadioScene_RadioGalaxyNews_0A93BF68.txt` and `..._B_0AC0FA30.txt` |
| Song INFO conditions | `3_Exports_F34/SongInfoExport(for0AC92CD7).csv`, `...(for0AEAECDA).csv`, `FullInfo_Export.txt`, `NoEditorID_0AED5399.txt` |
| Test plugins | `2_Patches/` |
| Claude A's Reliable 01 test report, FO4Edit screenshot findings, and function review | `6_Session_Updates/Claude_A_Session_Addendum_2026-11-19.md` and the source PDF beside it |
| Compiled-script caller search | The `scripts.zip` mentioned in the transcript; **not present in this package** |
| Comparison only, never F34 evidence | `4_Reference_Only/` |
| Claude A findings and original transcript | `6_Session_Updates/` |
| Older notes, READMEs, PDFs, v1/v2/v3/v3.1 masters and tree listing | `9_Archive_Superseded/` |

---

# 12. Test-log template
Copy one block per run. Record every field; write "not recorded" rather than guessing.

```
Date/time:
Save used (exact filename; e.g. Reliable 01):
Was the original source save freshly loaded for this run? (yes/no/not recorded):
ESM used (name + file size + SHA-256 if available):
Enabled diagnostic test ESP (exact filename; none/A0/A1/A2/A3/TestA/TestB):
Other enabled patches and relevant load-order entries:
Were GNR_Everywhere_F34.esp and GNR No Static_F34.esp enabled? (yes/no):
Was exitsave disabled/avoided? (yes/no):
Time listened (minutes):
Songs heard (count):
Three Dog dialogue continued? (yes/no):
Did music stop or the radio become abnormal later? (describe/time/song count):
Did the result repeat on a second fresh load? (yes/no/not tested):
Notes:
```

---

# 13. How to start a follow-up AI session

1. Give the new AI this `00_START_HERE.md` first. It is the current v3.1.1 master. The downloadable external copy is `GNR_Master_Session_Memory_v3.1.1.md`; it must match the copy inside the ZIP.
2. The ZIP has one top-level folder, `Fallout34_GNR_Lean/`. Extract it or make that folder's contents available as project knowledge/file library. If the AI can see only the ZIP filename but cannot open its internal files, it must say so and ask for the archive to be extracted; it must not claim to have read the contents. Do **not** ask the AI to ingest every raw file at once. Have it read `01_FILE_INDEX.md` and open only the specific source files needed for the current question.
3. The Claude A source transcript is `6_Session_Updates/Claude_A_Session_2026-11-18_to_19.pdf`; the searchable text and concise addendum are beside it.
4. The next unfinished technical branch is the caller search for `F34_QSnap` / `F34_QRestore`. The separate `scripts.zip` mentioned in Claude A's transcript is not in this package; the AI must request it or an equivalent compiled-script extraction before claiming that search is complete.
5. Require the AI to separate verified record/bytecode facts, user-reported game results, inference, and unknowns. Do not let it edit plugins or propose a patch before it has explained what the current evidence proves and what it does not.

A ready-to-paste starter message is in `CLAUDE_B_START_PROMPT.md` (external download: `GNR_Claude_B_Start_Prompt_v3.1.1.md`).
