# F34: Galaxy News Radio plays no songs - decompiled scripts and findings

This README explains two zip files, `gnr_psc.zip` and `upload_me.zip`, so that anyone can read them without the conversation they came from. Put this README in both zips.

## 1. The problem

F34 (`Fallout34.esm`) ports Fallout 3 / New Vegas content to Fallout 4. In F34, **Galaxy News Radio (GNR) plays Three Dog's talking back to back and never plays a song.**

What has been established so far:

- The radio quest, its script and the DJ dialogue all run. The failure is the step from talk to song.
- All 20 song `.wav` files exist and every sound descriptor points to one of them.
- Both transmitters are enabled.
- The Papyrus log has no GNR errors.
- It still fails in the Capital Wasteland.

How a song is reached: a song is a silent dialogue line (an INFO record, with empty text and no sound file) that hands control to a scene phase. It plays only if **all** of its conditions pass. If none passes, the scene moves on to the next talk phase, which matches the symptom.

Two song topics hold 48 INFOs each (96 in total):

- `0AEAECDA`, called by scene `0A93BF68` ("A")
- `0AC92CD7`, called by scene `0AC0FA30` ("B")

Every song INFO has a condition on a counter, `SongsPlayed`, which lives in script `F3:RadioGNRScript` on quest `F3_RadioGalaxyNewsQuest` (`0A022486`). The four groups of INFOs accept only these counter values:

| Phases | `SongsPlayed` must be | Also needs |
|---|---|---|
| S85-S96 | 0 | `LastSongPlayed1-4` not this song |
| S73-S84 (plain) | 1 | same |
| S61-S72 | 0 | `SongIntro` = N |
| S73-S84 (intro) | 1 | `SongIntro` = N |

All groups also need transmitter 0 OR transmitter 1 enabled, and the quest running. **Any counter value other than 0 or 1 blocks every song.**

## 2. The tools used

- `Fallout34_2 - Main.ba2` was extracted, giving 9,299 `.pex` files. All have Fallout 4 headers (`DE C0 57 FA`).
- **Champollion V1.0.6** was used to decompile them. A `.pex` is a compiled Papyrus script and a `.psc` is its decompiled source.
- `Decompile-F34.ps1` ran each file separately and checked each result. It is a PowerShell 5.1 script that does not change any game files.

## 3. `gnr_psc.zip`: the 639 GNR fragment scripts

- **Contents:** 639 files named `tif_f3_radiogalaxynewsquest_<hex>.psc`. Each is the small script attached to one GNR dialogue line. In Fallout 4 these are called topic-info fragments (TIF). All 639 `.pex` files from `scripts\fragments\topicinfos` that match that name were decompiled with no errors and no crashes.
- **Naming:** the hex part is the original Fallout 3 INFO FormID with load-order byte `01`. It is not the F34 FormID. To map a fragment to an F34 INFO, open the INFO in FO4Edit and read its Papyrus Fragments tab.
- **How to read one:** every fragment is a `Fragment_End` function that calls `F34_FragBegin()` ... `F34_FragEnd()` around its work.

**Findings from searching all 639:**

| Kind | Count | What it does |
|---|---|---|
| Song-play fragments with "+1" | 120 | `F34_Add_SongsPlayed(1)`; also shifts `LastSongPlayed1-4` and sets `LastSongPlayed` to a song number 1-20 |
| Song-play fragments with "=0" | 52 | `SongsPlayed = 0`; same `LastSongPlayed` bookkeeping |
| Intro fragments | 52 | set `SongIntro` to 1-12 |
| All other fragments | the rest | no change to `SongsPlayed` |

Counts are per song: 6 "+1" fragments for each of the 20 songs, 3 "=0" fragments for songs 1-12 and 2 for songs 13-20. Every fragment that writes `SongsPlayed` is a song-play fragment, and no other fragment and no other script writes it. The only place `SongsPlayed` goes back to 0 is a "=0" song fragment.

**What follows from this, and what is unverified:**

- If a "+1" fragment ever fires while the counter is 1, the counter becomes 2. After that no song INFO can pass, and the INFOs that would reset it are themselves song INFOs and cannot be picked. The counter would be locked.
- The natural design is that INFOs gated on `SongsPlayed = 0` use "+1" fragments and INFOs gated on `SongsPlayed = 1` use "=0" fragments, so the counter toggles 0, 1, 0, 1. **This pairing has not been checked.** To check it, open INFO `0A9C065F` (gated on `= 1`) and INFO `0AED5399` (gated on `= 0`) in FO4Edit, read the fragment script named on each, and compare it with the matching `.psc` in this zip.
- A locked counter alone cannot explain silence from a fresh game. At counter 0, the 12 plain S85-S96 INFOs need nothing else, so the first offer should play a song. A fresh-start failure points to a nonzero starting counter, song topics that are never reached, or another failing condition.

## 4. `upload_me.zip`: run report and the one script that did not decompile

| File | What it is |
|---|---|
| `report.txt` | The checked run log: what was verified and what failed |
| `summary.csv` | One line per file: 639 `OK`, 1 `INCOMPLETE` |
| `psc_main\radiognrscript.psc` | Decompile of `F3:RadioGNRScript`, **truncated** (see below) |
| `psc_main_comment\radiognrscript.psc` | Second decompile attempt (`-c`); crashed too, cut off at 45,056 bytes |
| `asm\radiognrscript.pas` | **Complete bytecode listing of the whole script (60,094 bytes).** Champollion's assembly mode does not crash, so every function can be read from it |
| `strings\radiognrscript.strings.txt` | All 275 identifiers read straight from the `.pex` |
| `logs\` | Champollion help text and console output |

**The 1 failure in `report.txt` is only the main script. It is not the fragments.**

- Champollion exited with code `-1073741819`, which is `0xC0000005`, a Windows access violation. Champollion **crashed**.
- Its output stops after 12,685 bytes, in the middle of the line `float F34_qs39 = F34_qa[3` inside `F34_QRestore`. The `.pex` is 16,677 bytes.
- The same cutoff appeared on every run, so it is repeatable and not an upload problem.

**What is visible in the part that decompiled:**

- Roughly 54 auto-properties, among them `SongsPlayed`, `SongIntro`, `LastSongPlayed1-4`, `MS01Clear` ... `MS06Clear`, news and PSA counters. Each has an `F34_Add_<name>(delta)` helper that adds with no cap.
- `F34_QSnap` / `F34_QRestore` copy all the variables and restore any value that went back to 0. They never set `SongsPlayed` to 0, so they cannot be the thing that resets the counter.
- `OnQuestInit` starts a 5-second timer. `OnTimer` re-arms itself and calls `F34_GameModeTick()` only if `F34_InOwnWorld()` is true.

**Read from `radiognrscript.pas` (the functions the decompile could not reach):**

- **`F34_GameModeTick`** only runs the Fallout 3 "MS08" (Harkness) logic: when stage 200 is done and Harkness is disabled, it sets `MS08Clear` and `ExploitReady`. It never touches `SongsPlayed`, `SongIntro` or `LastSongPlayed`.
- **`F34_FragBegin`** sets `F34_FragUntil` to now + 2 seconds. **`F34_FragEnd`** sets it to 0. `OnTimer` skips a tick only while the current time is inside the 5 seconds before `F34_FragUntil`, and otherwise resets it to 0. It cannot get stuck, and it only affects that timer tick, never the song counter.
- **`F34_InOwnWorld`** returns whether the player's worldspace (outside) or cell (inside) comes from the same plugin as this quest, by comparing the top byte of the FormIDs; an unknown location counts as yes. It only decides whether `OnTimer` runs the tick.
- **`SongsPlayed`** is a conditional variable with initial value 0, so it starts at 0 and is visible to dialogue conditions.
- **`F34_QSnap` / `F34_QRestore`** include `SongsPlayed` in their snapshot, and restore it only if the snapshot value is nonzero and the current value is 0. None of the 639 GNR fragments calls either function. The only callers found are 56 fragments of the CG02 and CG03 quests, which call them on their own quests. No caller on the GNR quest was found.

**Conclusion so far: nothing in `F3:RadioGNRScript` explains the silence.** The script initialises the counter to 0, only changes it through the song fragments, and its timer and fragment helpers do not touch it. That leaves the INFO conditions and the scene flow (see section 5).

## 5. Open questions

1. Which counter value does each song INFO leave behind? Check the pairing described in section 3.
2. ~~What do `F34_FragBegin`, `F34_FragEnd` and `F34_GameModeTick` do?~~ Answered above: they cannot cause the symptom.
3. What is the counter's value at the first song offer in a fresh game? It cannot be read from the console. The call `cqf F3_RadioGalaxyNewsQuest F34_Add_SongsPlayed 0` returns the current value, but it is untested.
4. Do House radio songs play? They share 12 of the 20 sound descriptors.
5. Do song INFOs with empty text and the flag "Start Scene on End" ever finish in Fallout 4? Compare a vanilla radio INFO.

## 6. Caveats

- Everything above comes from decompiled text and string searches. Nothing has been confirmed in game.
- Counts come from regex searches over the 639 `.psc` files.
- "Test A" and "Test B" diagnostic plugins exist (they remove the `SongsPlayed`, `SongIntro` and `LastSongPlayed` conditions, and Test B also removes the quest-running check). **No results have been reported yet.** Their results would show whether a variable condition blocks the songs.

## 7. To reproduce

```
powershell -ExecutionPolicy Bypass -File .\Decompile-F34.ps1 `
    -Champollion "C:\path\to\Champollion.exe" `
    -Root "C:\path\to\extracted\archive"
```

`-Root` is the folder that contains `scripts\`. Each run writes to a new `decomp_runs\run_<date_time>` folder and builds both zips.
