unit GNR_Full_Live_Quest_INFO_Export_v2;

// Read-only FO4Edit/xEdit export for the live GNR quest.
// Apply to QUST: F34_Radio_RadioGalaxyNews (0AD0EE64).
// Collects DIALs linked directly to the quest and DIALs used by quest-linked
// SCEN dialogue actions. Exports INFO children, Conditions, VMAD, Responses,
// and complete SCEN phase/action data. Does not modify plugin records.

var
  slOut: TStringList;
  lstDials: TStringList;
  lstInfos: TStringList;
  lstScenes: TStringList;
  OutputFile: string;
  ProcessedQuest: Boolean;

procedure Out(const s: string);
begin
  slOut.Add(s);
end;

function FormIDString(e: IInterface): string;
begin
  if not Assigned(e) then begin
    Result := '<none>';
    Exit;
  end;
  Result := IntToHex(GetLoadOrderFormID(e), 8);
end;

procedure AddUniqueRecord(lst: TStringList; e: IInterface);
var
  key: string;
begin
  if not Assigned(e) then Exit;
  key := FormIDString(e);
  if lst.IndexOf(key) < 0 then
    lst.AddObject(key, e);
end;

// Iterative tree walk: JvInterpreter can reject Pascal forward declarations,
// so this deliberately avoids a recursive procedure.
procedure DumpTree(e: IInterface; depth: Integer);
var
  i: Integer;
  idx: Integer;
  currentDepth: Integer;
  child: IInterface;
  stack: TStringList;
  line: string;
  value: string;
begin
  if not Assigned(e) then Exit;
  stack := TStringList.Create;
  try
    if ElementCount(e) > 0 then
      for i := Pred(ElementCount(e)) downto 0 do
        stack.AddObject(IntToStr(depth), ElementByIndex(e, i));

    while stack.Count > 0 do begin
      idx := stack.Count - 1;
      currentDepth := StrToInt(stack[idx]);
      child := ObjectToElement(stack.Objects[idx]);
      stack.Delete(idx);
      if not Assigned(child) then Continue;

      line := StringOfChar(' ', currentDepth) + Name(child);
      value := GetEditValue(child);
      if value <> '' then
        line := line + ' = ' + value;
      Out(line);

      if ElementCount(child) > 0 then
        for i := Pred(ElementCount(child)) downto 0 do
          stack.AddObject(IntToStr(currentDepth + 2), ElementByIndex(child, i));
    end;
  finally
    stack.Free;
  end;
end;

procedure AddInfosFromDial(Dialogue: IInterface);
var
  i: Integer;
  InfoGroup: IInterface;
  Info: IInterface;
begin
  if not Assigned(Dialogue) then Exit;
  InfoGroup := ChildGroup(Dialogue);
  if not Assigned(InfoGroup) then Exit;
  if ElementCount(InfoGroup) > 0 then
    for i := 0 to Pred(ElementCount(InfoGroup)) do begin
      Info := ElementByIndex(InfoGroup, i);
      if Assigned(Info) then
        if Signature(Info) = 'INFO' then
          AddUniqueRecord(lstInfos, Info);
    end;
end;

// Scene dialogue actions link to DIAL topics through DATA - Topic.
procedure AddDialsFromSceneVersion(SceneVersion: IInterface);
var
  i: Integer;
  Actions: IInterface;
  Action: IInterface;
  TopicElement: IInterface;
  TopicRecord: IInterface;
begin
  if not Assigned(SceneVersion) then Exit;
  Actions := ElementByName(SceneVersion, 'Actions');
  if not Assigned(Actions) then Exit;
  if ElementCount(Actions) = 0 then Exit;

  for i := 0 to Pred(ElementCount(Actions)) do begin
    Action := ElementByIndex(Actions, i);
    if not Assigned(Action) then Continue;
    TopicElement := ElementByName(Action, 'DATA - Topic');
    if not Assigned(TopicElement) then Continue;
    TopicRecord := LinksTo(TopicElement);
    if not Assigned(TopicRecord) then Continue;
    if Signature(TopicRecord) = 'DIAL' then
      AddUniqueRecord(lstDials, MasterOrSelf(TopicRecord));
  end;
end;

procedure AddDialsFromScene(Scene: IInterface);
var
  i: Integer;
  SceneOverride: IInterface;
begin
  if not Assigned(Scene) then Exit;
  for i := Pred(OverrideCount(Scene)) downto 0 do begin
    SceneOverride := OverrideByIndex(Scene, i);
    AddDialsFromSceneVersion(SceneOverride);
  end;
  AddDialsFromSceneVersion(Scene);
end;

procedure DumpInfo(Info: IInterface);
var
  e: IInterface;
begin
  Out('');
  Out('================================================================');
  Out('INFO: ' + FormIDString(Info) + ' | file FormID ' + IntToHex(FormID(Info), 8));
  Out('File: ' + GetFileName(GetFile(Info)));
  Out('Name: ' + Name(Info));
  Out('EditorID: ' + EditorID(Info));

  e := ElementByName(Info, 'Topic');
  if Assigned(e) then
    Out('Topic link: ' + GetEditValue(e));

  e := ElementByName(Info, 'Conditions');
  Out('-- CONDITIONS --');
  if Assigned(e) then
    DumpTree(e, 2)
  else
    Out('  [No Conditions element]');

  e := ElementByPath(Info, 'VMAD');
  Out('-- VMAD / PAPYRUS FRAGMENT DATA --');
  if Assigned(e) then
    DumpTree(e, 2)
  else
    Out('  [No VMAD element]');

  e := ElementByName(Info, 'Responses');
  Out('-- RESPONSES --');
  if Assigned(e) then
    DumpTree(e, 2)
  else
    Out('  [No Responses element]');
end;

procedure DumpDialogue(Dialogue: IInterface);
var
  j: Integer;
  DialogueOverride: IInterface;
begin
  Out('');
  Out('################################################################');
  Out('DIAL TOPIC: ' + FormIDString(Dialogue) + ' | file FormID ' + IntToHex(FormID(Dialogue), 8));
  Out('File: ' + GetFileName(GetFile(Dialogue)));
  Out('Name: ' + Name(Dialogue));
  Out('EditorID: ' + EditorID(Dialogue));
  Out('Quest link (if present): ' + GetElementEditValues(Dialogue, 'QNAM - Quest'));

  // Include INFO children from each loaded override, then the base topic.
  for j := Pred(OverrideCount(Dialogue)) downto 0 do begin
    DialogueOverride := OverrideByIndex(Dialogue, j);
    AddInfosFromDial(DialogueOverride);
  end;
  AddInfosFromDial(Dialogue);
  Out('INFO children collected; full INFO data appears in the INFO section.');
end;

procedure DumpScene(Scene: IInterface);
begin
  Out('');
  Out('################################################################');
  Out('SCEN: ' + FormIDString(Scene) + ' | file FormID ' + IntToHex(FormID(Scene), 8));
  Out('File: ' + GetFileName(GetFile(Scene)));
  Out('Name: ' + Name(Scene));
  Out('EditorID: ' + EditorID(Scene));
  Out('-- COMPLETE SCENE TREE (includes phases and actions) --');
  DumpTree(Scene, 2);
end;

procedure ExportQuest(Quest: IInterface);
var
  i: Integer;
  j: Integer;
  Ref: IInterface;
  Dialogue: IInterface;
  Info: IInterface;
  Scene: IInterface;
  SceneOverride: IInterface;
  DialogueOverride: IInterface;
begin
  Out('GNR LIVE QUEST FULL INFO EXPORT v2');
  Out('Read-only export. No plugin records are modified.');
  Out('Quest: ' + FormIDString(Quest) + ' | ' + Name(Quest));
  Out('EditorID: ' + EditorID(Quest));
  Out('Plugin: ' + GetFileName(GetFile(Quest)));
  Out('');

  // Collect records that directly reference the quest.
  for i := 0 to Pred(ReferencedByCount(Quest)) do begin
    Ref := ReferencedByIndex(Quest, i);
    if not Assigned(Ref) then Continue;
    if Signature(Ref) = 'DIAL' then
      AddUniqueRecord(lstDials, MasterOrSelf(Ref))
    else if Signature(Ref) = 'SCEN' then
      AddUniqueRecord(lstScenes, MasterOrSelf(Ref));
  end;

  // Dialogue topics used by scene actions may not directly reference the quest.
  for i := 0 to Pred(lstScenes.Count) do begin
    Scene := ObjectToElement(lstScenes.Objects[i]);
    AddDialsFromScene(Scene);
  end;

  Out('DIAL topics found (direct quest links + scene dialogue actions): ' + IntToStr(lstDials.Count));
  Out('SCEN records found through quest references: ' + IntToStr(lstScenes.Count));
  Out('');

  for i := 0 to Pred(lstDials.Count) do begin
    Dialogue := ObjectToElement(lstDials.Objects[i]);
    DumpDialogue(Dialogue);
  end;

  Out('');
  Out('################################################################');
  Out('ALL COLLECTED INFO RECORDS');
  Out('Unique INFO count: ' + IntToStr(lstInfos.Count));
  for i := 0 to Pred(lstInfos.Count) do begin
    Info := ObjectToElement(lstInfos.Objects[i]);
    DumpInfo(Info);
  end;

  Out('');
  Out('################################################################');
  Out('QUEST-LINKED SCENES AND OVERRIDES');
  for i := 0 to Pred(lstScenes.Count) do begin
    Scene := ObjectToElement(lstScenes.Objects[i]);
    DumpScene(Scene);
    for j := Pred(OverrideCount(Scene)) downto 0 do begin
      SceneOverride := OverrideByIndex(Scene, j);
      DumpScene(SceneOverride);
    end;
  end;

  Out('');
  Out('EXPORT SUMMARY');
  Out('DIAL topics: ' + IntToStr(lstDials.Count));
  Out('Unique INFO records: ' + IntToStr(lstInfos.Count));
  Out('SCEN records: ' + IntToStr(lstScenes.Count));
  Out('End of export.');
end;

function Initialize: Integer;
begin
  slOut := TStringList.Create;
  lstDials := TStringList.Create;
  lstInfos := TStringList.Create;
  lstScenes := TStringList.Create;
  lstDials.Sorted := True;
  lstInfos.Sorted := True;
  lstScenes.Sorted := True;
  lstDials.Duplicates := dupIgnore;
  lstInfos.Duplicates := dupIgnore;
  lstScenes.Duplicates := dupIgnore;
  ProcessedQuest := False;
  OutputFile := ScriptsPath + 'GNR_Full_Live_Quest_INFO_Export_v2.txt';
end;

function Process(e: IInterface): Integer;
begin
  if Signature(e) <> 'QUST' then Exit;
  if EditorID(e) <> 'F34_Radio_RadioGalaxyNews' then begin
    AddMessage('Wrong quest selected. Select F34_Radio_RadioGalaxyNews [QUST:0AD0EE64].');
    Exit;
  end;
  if ProcessedQuest then Exit;
  if (ContainerStates(GetFile(e)) and (1 shl csRefsBuild)) = 0 then begin
    AddMessage('Reference information is not built for ' + GetFileName(GetFile(e)) + '.');
    AddMessage('Right-click Fallout34.esm > Other > Build Reference Info, then run again.');
    Exit;
  end;
  ProcessedQuest := True;
  ExportQuest(MasterOrSelf(e));
end;

function Finalize: Integer;
begin
  try
    if ProcessedQuest then begin
      slOut.SaveToFile(OutputFile);
      AddMessage('GNR export saved to: ' + OutputFile);
      AddMessage('DIAL topics: ' + IntToStr(lstDials.Count));
      AddMessage('Unique INFO records: ' + IntToStr(lstInfos.Count));
      AddMessage('SCEN records: ' + IntToStr(lstScenes.Count));
    end else
      AddMessage('No QUST record was processed. Select F34_Radio_RadioGalaxyNews and run this script on that record.');
  finally
    slOut.Free;
    lstDials.Free;
    lstInfos.Free;
    lstScenes.Free;
  end;
end;

end.
