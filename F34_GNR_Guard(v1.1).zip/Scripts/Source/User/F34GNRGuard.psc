Scriptname F34GNRGuard extends Quest
{F34 GNR Guard v1.1 (candidate). Keeps Galaxy News Radio's SongsPlayed counter inside its valid 0-1-2 cycle.
0 and 1 are never touched. A value below 0 or above 2 is set to RecoveryValue at once; a 2 that stays unchanged for StuckSeconds is treated as stuck.
If the counter keeps going invalid (a runaway loop), the guard stops writing and only logs.
Never edits Fallout34.esm. Log: Documents\My Games\Fallout4\Logs\Script\User\F34_GNR_Guard.0.log}

String Property LogName = "F34_GNR_Guard" AutoReadOnly Hidden
Float Property PollSeconds = 3.0 AutoReadOnly Hidden
Int Property TimerID = 1 AutoReadOnly Hidden
Int Property MaxValid = 2 AutoReadOnly Hidden
Int Property RecoveryValue = 0 AutoReadOnly Hidden
Int Property MaxResetsPerSession = 10 AutoReadOnly Hidden
Int Property MaxLogLines = 300 AutoReadOnly Hidden
Float Property StuckSeconds = 30.0 AutoReadOnly Hidden ; a 2 that does not change for this long is treated as stuck

ScriptObject gnr
Float stuckSince = -1.0
Int lastSeen = -999
Int resetsThisSession = 0
Int logLines = 0
Int initCalls = 0
Bool backedOff = False
Bool missingLogged = False

Event OnInit()
	initCalls += 1
	StartGuard("OnInit #" + initCalls)
EndEvent

Event Actor.OnPlayerLoadGame(Actor akSender)
	StartGuard("load game")
EndEvent

Function StartGuard(String reason)
	; Safe to call more than once: cancels the old timer before starting a new one.
	CancelTimer(TimerID)
	Debug.OpenUserLog(LogName)
	gnr = None
	lastSeen = -999
	resetsThisSession = 0
	backedOff = False
	missingLogged = False
	RegisterForRemoteEvent(Game.GetPlayer(), "OnPlayerLoadGame")
	Log("started (" + reason + ")")
	StartTimer(PollSeconds, TimerID)
EndFunction

Event OnTimer(Int aiTimerID)
	If aiTimerID == TimerID
		Check()
		StartTimer(PollSeconds, TimerID)
	EndIf
EndEvent

Bool Function Resolve()
	If gnr
		Return True
	EndIf
	Quest q = Game.GetFormFromFile(0x00022486, "Fallout34.esm") as Quest
	If q == None
		Return False
	EndIf
	gnr = q.CastAs("F3:RadioGNRScript")
	Return gnr != None
EndFunction

Function Check()
	If !Resolve()
		If !missingLogged
			Log("GNR quest or F3:RadioGNRScript not found - doing nothing")
			missingLogged = True
		EndIf
		Return
	EndIf
	missingLogged = False

	Int played = gnr.GetPropertyValue("SongsPlayed") as Int
	If played != lastSeen
		Log("SongsPlayed=" + played + " (was " + lastSeen + ")")
		lastSeen = played
		stuckSince = -1.0
	EndIf

	If played >= 0 && played < MaxValid
		stuckSince = -1.0
		Return ; 0 and 1: never touch
	EndIf

	If played == MaxValid
		; 2 is normal for a moment (the next talk step resets it), but no song accepts 2.
		; Only recover if it stays at 2.
		Float now = Utility.GetCurrentRealTime()
		If stuckSince < 0.0
			stuckSince = now
		EndIf
		If now - stuckSince < StuckSeconds
			Return
		EndIf
		Log("SongsPlayed has stayed at 2 for " + StuckSeconds + "s - treating as stuck")
	EndIf

	If backedOff
		Return ; runaway suspected earlier: monitor only
	EndIf

	If resetsThisSession >= MaxResetsPerSession
		backedOff = True
		Log("BACKOFF: " + resetsThisSession + " recoveries this session and the counter keeps leaving 0-" + MaxValid + ". No more writes (monitor only). Something is rewriting it.")
		Return
	EndIf

	gnr.SetPropertyValue("SongsPlayed", RecoveryValue)
	resetsThisSession += 1
	Int after = gnr.GetPropertyValue("SongsPlayed") as Int
	Log("RECOVERY #" + resetsThisSession + ": SongsPlayed " + played + " -> " + RecoveryValue + " (reads back " + after + ")")
	lastSeen = after
EndFunction

Function Log(String msg)
	logLines += 1
	If logLines <= MaxLogLines
		Debug.TraceUser(LogName, msg)
	ElseIf logLines == MaxLogLines + 1
		Debug.TraceUser(LogName, "log line limit reached, further lines suppressed")
	EndIf
EndFunction
