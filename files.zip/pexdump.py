import struct,sys
d=open(sys.argv[1],'rb').read()
p=0
def u8():
    global p; v=d[p]; p+=1; return v
def u16():
    global p; v=struct.unpack_from('<H',d,p)[0]; p+=2; return v
def u32():
    global p; v=struct.unpack_from('<I',d,p)[0]; p+=4; return v
def i32():
    global p; v=struct.unpack_from('<i',d,p)[0]; p+=4; return v
def f32():
    global p; v=struct.unpack_from('<f',d,p)[0]; p+=4; return v
def u64():
    global p; v=struct.unpack_from('<Q',d,p)[0]; p+=8; return v
def wstr():
    global p; n=u16(); s=d[p:p+n].decode('latin1'); p+=n; return s
assert u32()==0xFA57C0DE
print('ver',u8(),u8(),'game',u16(),'time',u64())
print('src',wstr(),'user',wstr(),'comp',wstr())
S=[wstr() for _ in range(u16())]
def s(i): return S[i]
if u8():
    u64()
    for _ in range(u16()):
        u16();u16();u16();u8()
        for _ in range(u16()): u16()
    for _ in range(u16()):
        u16();u16();u16();u32()
        for _ in range(u16()): u16()
    for _ in range(u16()):
        u16();u16()
        for _ in range(u16()): u16()
for _ in range(u16()):
    u16();u8()
def val():
    t=u8()
    if t==0: return 'None'
    if t==1: return s(u16())
    if t==2: return '"%s"'%s(u16())
    if t==3: return str(i32())
    if t==4: return str(f32())
    if t==5: return str(bool(u8()))
    raise Exception('bad variant %d at %d'%(t,p))
FIX={1:3,2:3,3:3,4:3,5:3,6:3,7:3,8:3,9:3,0xA:2,0xB:2,0xC:2,0xD:2,0xE:2,0xF:3,0x10:3,0x11:3,0x12:3,0x13:3,0x14:1,0x15:2,0x16:2,0x1A:1,0x1B:3,0x1C:3,0x1D:3,0x1E:2,0x1F:2,0x20:3,0x21:3,0x22:4,0x23:4,0x24:3,0x25:1,0x26:3,0x27:3,0x28:5,0x29:5,0x2A:3,0x2B:3,0x2C:1,0x2D:3,0x2E:1,0x2F:4}
VAR={0x17:3,0x18:2,0x19:3}
NAMES={1:'iadd',2:'fadd',3:'isub',4:'fsub',5:'imul',6:'fmul',7:'idiv',8:'fdiv',9:'imod',0xA:'not',0xB:'ineg',0xC:'fneg',0xD:'assign',0xE:'cast',0xF:'cmpeq',0x10:'cmplt',0x11:'cmple',0x12:'cmpgt',0x13:'cmpge',0x14:'jmp',0x15:'jmpt',0x16:'jmpf',0x17:'callmethod',0x18:'callparent',0x19:'callstatic',0x1A:'return',0x1B:'strcat',0x1C:'propget',0x1D:'propset',0x1E:'arrcreate',0x1F:'arrlen',0x20:'arrget',0x21:'arrset',0x22:'arrfind',0x23:'arrrfind',0x24:'is',0x25:'structcreate',0x26:'structget',0x27:'structset',0x28:'arrfindstruct',0x29:'arrrfindstruct',0x2A:'arradd',0x2B:'arrins',0x2C:'arrremlast',0x2D:'arrrem',0x2E:'arrclear'}
def func(name):
    ret=s(u16());u16();u32();fl=u8()
    params=[(s(u16()),s(u16())) for _ in range(u16())]
    locs=[(s(u16()),s(u16())) for _ in range(u16())]
    print('\n  FUNC %s -> %s  flags=%d params=%s'%(name,ret,fl,params))
    print('    locals:',locs)
    for i in range(u16()):
        op=u8(); a=[]
        if op==0: print('   %3d nop'%i); continue
        for _ in range(FIX.get(op,VAR.get(op,0))): a.append(val())
        if op in VAR:
            n=int(val())
            extra=[val() for _ in range(n)]
            a.append('('+', '.join(extra)+')')
        print('   %3d %-10s %s'%(i,NAMES.get(op,hex(op)),' '.join(a)))
for _ in range(u16()):
    print('OBJECT',s(u16()));u32();print(' parent',s(u16()));u16();u8();u32();print(' autostate',s(u16()))
    for _ in range(u16()):
        print(' struct',s(u16()))
        for _ in range(u16()):
            u16();u16();u32();val();u8();u16()
    for _ in range(u16()):
        n=s(u16());t=s(u16());u32();v=val();u8();print(' VAR',n,t,'=',v)
    for _ in range(u16()):
        n=s(u16());t=s(u16());u16();u32();fl=u8()
        print(' PROP',n,t,'flags',fl)
        if fl&4: print('   auto var',s(u16()))
        else:
            if fl&1: func(n+'.get')
            if fl&2: func(n+'.set')
    for _ in range(u16()):
        sn=s(u16());print(' STATE',repr(sn))
        for _ in range(u16()):
            func(s(u16()))
print('\nended at',p,'of',len(d))
